package com.kisanmitra.app;

import android.content.Context;
import android.content.res.AssetManager;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;

public class LocalServer extends Thread {
    private final Context context;
    private ServerSocket serverSocket;
    private int port = 8989;
    private volatile boolean running = true;
    private volatile boolean isBound = false;

    public LocalServer(Context context, int preferredPort) {
        this.context = context;
        this.port = preferredPort;
    }

    public int getPort() {
        return port;
    }

    public boolean isBound() {
        return isBound;
    }

    @Override
    public void run() {
        try {
            try {
                serverSocket = new ServerSocket(port, 50, InetAddress.getByName("127.0.0.1"));
            } catch (Exception e) {
                serverSocket = new ServerSocket(0, 50, InetAddress.getByName("127.0.0.1"));
                port = serverSocket.getLocalPort();
            }
            isBound = true;

            while (running) {
                try {
                    Socket client = serverSocket.accept();
                    handleClient(client);
                } catch (Exception e) {
                    if (!running) break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void handleClient(final Socket socket) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    InputStream in = socket.getInputStream();
                    OutputStream out = socket.getOutputStream();

                    byte[] buffer = new byte[2048];
                    int read = in.read(buffer);
                    if (read <= 0) {
                        socket.close();
                        return;
                    }

                    String req = new String(buffer, 0, read);
                    String[] lines = req.split("\r\n");
                    if (lines.length == 0) {
                        socket.close();
                        return;
                    }

                    String[] parts = lines[0].split(" ");
                    if (parts.length < 2) {
                        socket.close();
                        return;
                    }

                    String path = parts[1];
                    int qIdx = path.indexOf('?');
                    if (qIdx != -1) path = path.substring(0, qIdx);
                    if (path.equals("/") || path.isEmpty()) path = "/index.html";

                    // Handle API calls offline
                    if (path.startsWith("/api/")) {
                        String json = "{\"status\":\"ok\",\"reply\":\"शेतकरी मित्र: आपले स्वागत आहे! खत व्यवस्थापन, हवामान आणि बाजारभाव माहितीसाठी वरील पर्याय निवडा. हेल्पलाइन: १८००-१८०-१५५१\",\"diseaseName\":\"पानावरील करपा\",\"confidence\":\"85%\"}";
                        byte[] jsonBytes = json.getBytes("UTF-8");
                        String header = "HTTP/1.1 200 OK\r\n"
                                + "Content-Type: application/json; charset=utf-8\r\n"
                                + "Content-Length: " + jsonBytes.length + "\r\n"
                                + "Access-Control-Allow-Origin: *\r\n"
                                + "Connection: close\r\n\r\n";
                        out.write(header.getBytes("UTF-8"));
                        out.write(jsonBytes);
                        out.flush();
                        socket.close();
                        return;
                    }

                    String assetPath = "www" + path;
                    AssetManager am = context.getAssets();
                    InputStream assetIn = null;
                    try {
                        assetIn = am.open(assetPath);
                    } catch (Exception notFound) {
                        try {
                            assetIn = am.open("www/index.html");
                            path = "/index.html";
                        } catch (Exception e2) {
                            assetIn = null;
                        }
                    }

                    if (assetIn == null) {
                        String response = "HTTP/1.1 404 Not Found\r\nContent-Length: 0\r\n\r\n";
                        out.write(response.getBytes("UTF-8"));
                        out.flush();
                        socket.close();
                        return;
                    }

                    ByteArrayOutputStream baos = new ByteArrayOutputStream();
                    byte[] chunk = new byte[8192];
                    int n;
                    while ((n = assetIn.read(chunk)) != -1) {
                        baos.write(chunk, 0, n);
                    }
                    assetIn.close();
                    byte[] body = baos.toByteArray();

                    String mime = "application/octet-stream";
                    if (path.endsWith(".html")) mime = "text/html; charset=utf-8";
                    else if (path.endsWith(".js")) mime = "application/javascript; charset=utf-8";
                    else if (path.endsWith(".css")) mime = "text/css; charset=utf-8";
                    else if (path.endsWith(".svg")) mime = "image/svg+xml";
                    else if (path.endsWith(".png")) mime = "image/png";
                    else if (path.endsWith(".jpg") || path.endsWith(".jpeg")) mime = "image/jpeg";
                    else if (path.endsWith(".json")) mime = "application/json; charset=utf-8";
                    else if (path.endsWith(".ico")) mime = "image/x-icon";
                    else if (path.endsWith(".woff2")) mime = "font/woff2";
                    else if (path.endsWith(".woff")) mime = "font/woff";
                    else if (path.endsWith(".ttf")) mime = "font/ttf";

                    String header = "HTTP/1.1 200 OK\r\n"
                            + "Content-Type: " + mime + "\r\n"
                            + "Content-Length: " + body.length + "\r\n"
                            + "Access-Control-Allow-Origin: *\r\n"
                            + "Cache-Control: no-cache\r\n"
                            + "Connection: close\r\n\r\n";

                    out.write(header.getBytes("UTF-8"));
                    out.write(body);
                    out.flush();
                    socket.close();
                } catch (Exception e) {
                    try { socket.close(); } catch (Exception ignored) {}
                }
            }
        }).start();
    }

    public void stopServer() {
        running = false;
        try {
            if (serverSocket != null) serverSocket.close();
        } catch (Exception ignored) {}
    }
}
