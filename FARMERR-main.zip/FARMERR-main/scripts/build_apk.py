import os
import sys
import glob
import shutil
import subprocess
import zlib
import struct

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BUILD_DIR = "/tmp/apk-build"
PUBLIC_DIR = os.path.join(ROOT_DIR, "public")
DOWNLOADS_DIR = os.path.join(PUBLIC_DIR, "downloads")
ANDROID_JAR = "/usr/lib/android-sdk/platforms/android-23/android.jar"
TEMPLATE_DIR = os.path.join(ROOT_DIR, "android-template")

print(f"ROOT_DIR: {ROOT_DIR}")
print(f"BUILD_DIR: {BUILD_DIR}")

# 1. Run Vite build
print("=== 1. Building Vite Production Bundle ===")
subprocess.check_call(["npm", "run", "build"], cwd=ROOT_DIR)

# 2. Setup Directories
print("=== 2. Setting up APK build directories ===")
if os.path.exists(BUILD_DIR):
    shutil.rmtree(BUILD_DIR)

src_dir = os.path.join(BUILD_DIR, "src", "com", "kisanmitra", "app")
res_values_dir = os.path.join(BUILD_DIR, "res", "values")
assets_www_dir = os.path.join(BUILD_DIR, "assets", "www")

os.makedirs(src_dir, exist_ok=True)
os.makedirs(res_values_dir, exist_ok=True)
os.makedirs(assets_www_dir, exist_ok=True)
os.makedirs(DOWNLOADS_DIR, exist_ok=True)

for dpi in ["mdpi", "hdpi", "xhdpi", "xxhdpi"]:
    os.makedirs(os.path.join(BUILD_DIR, "res", f"mipmap-{dpi}"), exist_ok=True)

# 3. Copy web app dist to APK assets/www
print("=== 3. Copying Web App Dist to APK Assets ===")
dist_dir = os.path.join(ROOT_DIR, "dist")
for item in os.listdir(dist_dir):
    s = os.path.join(dist_dir, item)
    d = os.path.join(assets_www_dir, item)
    if item.endswith(".apk"):
        continue
    if os.path.isdir(s):
        shutil.copytree(s, d)
    else:
        shutil.copy2(s, d)

# Remove any APK inside assets/www
for bad in ["KisanMitra.apk", "downloads"]:
    p = os.path.join(assets_www_dir, bad)
    if os.path.exists(p):
        if os.path.isdir(p):
            shutil.rmtree(p)
        else:
            os.remove(p)

# 4. Generate Launcher Icons
print("=== 4. Generating App Launcher Icon ===")
def make_png(width, height, rgb_func):
    raw_data = bytearray()
    for y in range(height):
        raw_data.append(0)
        for x in range(width):
            r, g, b, a = rgb_func(x, y, width, height)
            raw_data.extend((r, g, b, a))
    def chunk(tag, data):
        return struct.pack('>I', len(data)) + tag + data + struct.pack('>I', zlib.crc32(tag + data) & 0xffffffff)
    png = b'\x89PNG\r\n\x1a\n'
    png += chunk(b'IHDR', struct.pack('>IIBBBBB', width, height, 8, 6, 0, 0, 0))
    png += chunk(b'IDAT', zlib.compress(bytes(raw_data)))
    png += chunk(b'IEND', b'')
    return png

def pixel(x, y, w, h):
    cx, cy = w / 2.0, h / 2.0
    dist = ((x - cx)**2 + (y - cy)**2)**0.5
    if dist > w * 0.47:
        return (0, 0, 0, 0)
    factor = (y / float(h))
    r = int(10 + factor * 25)
    g = int(140 + factor * 60)
    b = int(60 + factor * 20)
    if dist < w * 0.22:
        return (245, 190, 30, 255)
    return (r, min(255, g), b, 255)

for size, folder in [(48, 'mipmap-mdpi'), (72, 'mipmap-hdpi'), (96, 'mipmap-xhdpi'), (144, 'mipmap-xxhdpi')]:
    data = make_png(size, size, pixel)
    with open(os.path.join(BUILD_DIR, "res", folder, "ic_launcher.png"), "wb") as f:
        f.write(data)

# 5. Write AndroidManifest.xml and strings.xml
print("=== 5. Writing AndroidManifest.xml and Resources ===")
manifest_content = """<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.kisanmitra.app"
    android:versionCode="2"
    android:versionName="1.1.0">

    <uses-sdk android:minSdkVersion="21" android:targetSdkVersion="33" />

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
    <uses-permission android:name="android.permission.CAMERA" />

    <application
        android:label="@string/app_name"
        android:icon="@mipmap/ic_launcher"
        android:usesCleartextTraffic="true"
        android:hardwareAccelerated="true">
        <activity
            android:name="com.kisanmitra.app.MainActivity"
            android:exported="true"
            android:theme="@android:style/Theme.NoTitleBar"
            android:configChanges="orientation|screenSize|keyboardHidden">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
"""
with open(os.path.join(BUILD_DIR, "AndroidManifest.xml"), "w", encoding="utf-8") as f:
    f.write(manifest_content)

strings_content = """<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">शेतकरी मित्र</string>
</resources>
"""
with open(os.path.join(res_values_dir, "strings.xml"), "w", encoding="utf-8") as f:
    f.write(strings_content)

# 6. Copy Java Sources from template
print("=== 6. Copying Java Source Files from Template ===")
tmpl_src = os.path.join(TEMPLATE_DIR, "src", "com", "kisanmitra", "app")
for jf in ["LocalServer.java", "MainActivity.java"]:
    shutil.copy2(os.path.join(tmpl_src, jf), os.path.join(src_dir, jf))

# 7. Compile Java
print("=== 7. Compiling Java Source Files ===")
subprocess.check_call([
    "javac", "-source", "8", "-target", "8",
    "-cp", ANDROID_JAR,
    os.path.join(src_dir, "LocalServer.java"),
    os.path.join(src_dir, "MainActivity.java")
])

# 8. DEX
print("=== 8. Converting to Dalvik Executable (DEX) ===")
classes_dir = os.path.join(BUILD_DIR, "src")
class_files = [os.path.relpath(p, classes_dir) for p in glob.glob(os.path.join(classes_dir, "com", "kisanmitra", "app", "*.class"))]
subprocess.check_call([
    "dalvik-exchange", "--dex",
    f"--output={os.path.join(BUILD_DIR, 'classes.dex')}"
] + class_files, cwd=classes_dir)

# 9. Package base APK with AAPT including assets
print("=== 9. Packaging APK with AAPT (Including Assets) ===")
subprocess.check_call([
    "aapt", "package", "-f",
    "-M", os.path.join(BUILD_DIR, "AndroidManifest.xml"),
    "-S", os.path.join(BUILD_DIR, "res"),
    "-A", os.path.join(BUILD_DIR, "assets"),
    "-I", ANDROID_JAR,
    "-F", os.path.join(BUILD_DIR, "kisan-base.apk")
])

# 10. Add classes.dex
print("=== 10. Adding DEX to APK ===")
subprocess.check_call([
    "aapt", "add", "kisan-base.apk", "classes.dex"
], cwd=BUILD_DIR)

# 11. Sign APK
print("=== 11. Creating Keystore and Signing APK ===")
keystore_path = os.path.join(BUILD_DIR, "kisan.keystore")
if not os.path.exists(keystore_path):
    subprocess.check_call([
        "keytool", "-genkey", "-v", "-keystore", keystore_path,
        "-alias", "kisanmitra", "-keyalg", "RSA", "-keysize", "2048", "-validity", "10000",
        "-storepass", "kisan123", "-keypass", "kisan123",
        "-dname", "CN=KisanMitra, OU=Farmer, O=Krushi, L=Pune, ST=Maharashtra, C=IN"
    ])

aligned_apk = os.path.join(BUILD_DIR, "kisan-aligned.apk")
final_apk = os.path.join(BUILD_DIR, "KisanMitra.apk")
subprocess.check_call(["zipalign", "-v", "-p", "4", os.path.join(BUILD_DIR, "kisan-base.apk"), aligned_apk])
subprocess.check_call([
    "apksigner", "sign",
    "--ks", keystore_path,
    "--ks-pass", "pass:kisan123",
    "--key-pass", "pass:kisan123",
    "--out", final_apk,
    aligned_apk
])

subprocess.check_call(["apksigner", "verify", "--verbose", final_apk])

# 12. Copy to public directory
print("=== 12. Copying APK to Web Public Directory ===")
shutil.copy2(final_apk, os.path.join(PUBLIC_DIR, "KisanMitra.apk"))
shutil.copy2(final_apk, os.path.join(DOWNLOADS_DIR, "KisanMitra.apk"))

apk_size = os.path.getsize(os.path.join(PUBLIC_DIR, "KisanMitra.apk"))
print(f"SUCCESS: KisanMitra.apk generated! Size: {apk_size} bytes ({apk_size / 1024:.1f} KB)")
