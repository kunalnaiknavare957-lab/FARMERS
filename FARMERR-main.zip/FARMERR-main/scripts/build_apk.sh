#!/bin/bash
set -e

DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" >/dev/null 2>&1 && pwd )"
ROOT_DIR="$(dirname "$DIR")"
BUILD_DIR="/tmp/apk-build"

echo "=== 1. Building Vite Production Bundle ==="
cd "$ROOT_DIR"
npm run build

echo "=== 2. Setting up APK build directories ==="
rm -rf "$BUILD_DIR"
mkdir -p "$BUILD_DIR/src/com/kisanmitra/app" \
         "$BUILD_DIR/res/values" \
         "$BUILD_DIR/res/mipmap-hdpi" \
         "$BUILD_DIR/res/mipmap-mdpi" \
         "$BUILD_DIR/res/mipmap-xhdpi" \
         "$BUILD_DIR/res/mipmap-xxhdpi" \
         "$BUILD_DIR/assets/www" \
         "$ROOT_DIR/public/downloads"

echo "=== 3. Copying Web App Dist to APK Assets ==="
cp -r "$ROOT_DIR/dist/"* "$BUILD_DIR/assets/www/"
# Remove any existing APK inside assets if present
rm -f "$BUILD_DIR/assets/www/KisanMitra.apk" "$BUILD_DIR/assets/www/downloads/KisanMitra.apk" 2>/dev/null || true

echo "=== 4. Generating App Launcher Icon ==="
python3 -c "
import zlib, struct

def make_png(width, height, rgb_func):
    raw_data = bytearray()
    for y in range(height):
        raw_data.append(0)
        for x in range(width):
            r, g, b, a = rgb_func(x, y, width, height)
            raw_data.extend((r, g, b, a))
    def chunk(tag, data):
        return struct.pack('>I', len(data)) + tag + data + struct.pack('>I', zlib.crc32(tag + data) & 0xffffffff)
    png = b'\x89PNG\r\n\x1a\n'
    png += chunk(b'IHDR', struct.pack('>IIBBBBB', width, height, 8, 6, 0, 0, 0))
    png += chunk(b'IDAT', zlib.compress(bytes(raw_data)))
    png += chunk(b'IEND', b'')
    return png

def pixel(x, y, w, h):
    cx, cy = w / 2.0, h / 2.0
    dist = ((x - cx)**2 + (y - cy)**2)**0.5
    # Rounded badge icon
    if dist > w * 0.47:
        return (0, 0, 0, 0)
    # Emerald green gradient with golden center
    factor = (y / float(h))
    r = int(10 + factor * 25)
    g = int(140 + factor * 60)
    b = int(60 + factor * 20)
    # Yellow wheat glow in center
    if dist < w * 0.22:
        return (245, 190, 30, 255)
    return (r, min(255, g), b, 255)

for size, folder in [(72, 'mipmap-hdpi'), (48, 'mipmap-mdpi'), (96, 'mipmap-xhdpi'), (144, 'mipmap-xxhdpi')]:
    data = make_png(size, size, pixel)
    with open(f'$BUILD_DIR/res/{folder}/ic_launcher.png', 'wb') as f:
        f.write(data)
"

echo "=== 5. Writing AndroidManifest.xml and Resources ==="
cat << 'EOF' > "$BUILD_DIR/AndroidManifest.xml"
<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="com.kisanmitra.app"
    android:versionCode="2"
    android:versionName="1.1.0">

    <uses-sdk android:minSdkVersion="21" android:targetSdkVersion="33" />

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
    <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" />
    <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" />
    <uses-permission android:name="android.permission.CAMERA" />

    <application
        android:label="@string/app_name"
        android:icon="@mipmap/ic_launcher"
        android:usesCleartextTraffic="true"
        android:hardwareAccelerated="true">
        <activity
            android:name="com.kisanmitra.app.MainActivity"
            android:exported="true"
            android:theme="@android:style/Theme.NoTitleBar"
            android:configChanges="orientation|screenSize|keyboardHidden">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>
