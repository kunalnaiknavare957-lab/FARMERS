import zipfile
import os

zip_path = '/tmp/kisan-mitra-portal.zip'
exclude = {'node_modules', '.git', 'dist', '__pycache__', '.aistudio'}

with zipfile.ZipFile(zip_path, 'w', zipfile.ZIP_DEFLATED) as zf:
    for root, dirs, files in os.walk('.'):
        dirs[:] = [d for d in dirs if d not in exclude]
        for f in files:
            p = os.path.join(root, f)
            zf.write(p, os.path.relpath(p, '.'))

print(f"Zip created successfully at {zip_path}")
