import express from 'express';
import dotenv from 'dotenv';
import path from 'path';
import fs from 'fs';
import { execSync } from 'child_process';
import { fileURLToPath } from 'url';
import { GoogleGenAI } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;
const isProd = process.env.NODE_ENV === 'production';

app.use(express.json({ limit: '25mb' }));

// Initialize Google GenAI client if GEMINI_API_KEY is present
let ai: GoogleGenAI | null = null;
if (process.env.GEMINI_API_KEY) {
  ai = new GoogleGenAI({
    apiKey: process.env.GEMINI_API_KEY,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Fallback response generator if API key is not present or rate limited
function getFallbackAdvice(query: string, lang: 'hi' | 'mr' | 'en'): string {
  const q = query.toLowerCase();
  if (lang === 'mr') {
    if (q.includes('केळी') || q.includes('banana')) {
      return `केळी पीक सल्ला:\n1. सिगाटोका करप्यासाठी प्रोपिकोनाझोल २५% EC (१ मिली/लिटर) + खनिज तेल (१० मिली) किंवा नॅटिव्हो (०.८ ग्रॅम/लिटर) फवारा.\n2. कंदकिड्यासाठी क्लोरपायरीफॉस २.५ मिली/लिटर मुळाशी आळवणी करा.\n3. घड निसवल्यानंतर नरफूल (कमळ) तोडून निळी स्कर्टिंग बॅग लावा.`;
    }
    if (q.includes('पपई') || q.includes('papaya')) {
      return `पपई पीक सल्ला:\n1. रिंग स्पॉट व्हायरस रोखण्यासाठी पांढरी माशी व मावा नियंत्रणासाठी कॉन्फिडोर (०.५ मिली/लिटर) किंवा नीम तेल फवारा.\n2. खोडकूज (Collar Rot) रोखण्यासाठी झाडाच्या खोडाला १% बोर्डो पेस्ट लावा व रिडोमिल गोल्ड २.५ ग्रॅम/लिटर आळवणी करा.\n3. पपई उंच गादीवाफ्यावर लावा, खोडाला पाणी साचू देऊ नका.`;
    }
    if (q.includes('टोमॅटो') || q.includes('tomato')) {
      return `टोमॅटो पीक सल्ला:\n1. करपा व फळसड रोखण्यासाठी एमिसार टॉप (१ मिली/लिटर) किंवा साफ (२ ग्रॅम/लिटर) फवारा.\n2. फळपोखरणारी अळीसाठी प्रोक्लेम (०.५ ग्रॅम/लिटर) किंवा कोराजन (०.३ मिली/लिटर) फवारा.\n3. फुलगळ थांबवण्यासाठी प्लानोफिक्स ४ मिली प्रति १५ लिटर पंपाला द्या.`;
    }
    if (q.includes('सोयाबीन') || q.includes('soybean')) {
      return `सोयाबीन सल्ला:\n1. पेरणीनंतर 20-25 दिवसांनी आंतरमशागत करा.\n2. खोडमाशी व चक्रीभुंग्यासाठी क्लोरँट्रानिलीप्रोल (0.3 मिली/लिटर) फवारणी करा.\n3. फुलोरा अवस्थेत 12:61:00 (5 ग्रॅम/लिटर) व शेंगा भरताना 00:00:50 फवारा.`;
    }
    if (q.includes('कांदा') || q.includes('onion') || q.includes('थ्रिप्स')) {
      return `कांदा सल्ला:\n1. थ्रिप्स (फुलकिडे) नियंत्रणासाठी फिप्रोनिल 5% SC (1.5 मिली/लिटर) किंवा लॅम्बडा सायहॅलोथ्रीन फवारा.\n2. करपा रोगासाठी मॅन्कोझेब 75% WP (2.5 ग्रॅम/लिटर) मिसळा.\n3. नेहमी स्टिकर (स्प्रेडर) वापरा.`;
    }
    if (q.includes('पीएम किसान') || q.includes('pm kisan') || q.includes('हप्ता')) {
      return `पीएम किसान माहिती:\n1. आपला 18वा/19वा हप्ता बँक खात्यात येण्यासाठी e-KYC आणि NPCI आधार लिंक असणे बंधनकारक आहे.\n2. pmkisan.gov.in वर जाऊन 'Know Your Status' तपासा.\n3. काही अडचण असल्यास टोल-फ्री क्रमांक 155261 वर संपर्क साधा.`;
    }
    return `शेतकरी मित्र, तुमच्या प्रश्नाचे कृषी सल्ला:\n- पिकाची योग्य वाढ होण्यासाठी सेंद्रिय खते (शेणखत/गांडूळ खत) व योग्य वेळी NPK द्या.\n- किडीचा प्रादुर्भाव दिसताच तात्काळ निंबोळी अर्क (5%) किंवा योग्य कीटकनाशकाची फवारणी करा.\n- अधिक माहितीसाठी किसान कॉल सेंटर 1800-180-1551 वर कॉल करा.`;
  } else if (lang === 'hi') {
    if (q.includes('केला') || q.includes('banana')) {
      return `केला फसल सलाह:\n1. सिगाटोका पत्ती धब्बा रोग के लिए प्रोपिकोनाजोल 25% EC (1ml/L) अथवा एमिस्टार टॉप (1ml/L) का छिड़काव करें।\n2. कंद घुन व दीमक के लिए जड़ों में क्लोरोपायरीफॉस 20% EC (2.5 ml/L) का घोल डालें।\n3. घार पूरा निकलने पर निचला नर फूल तोड़ें और नीली पॉलिथीन थैली से ढकें।`;
    }
    if (q.includes('पपीता') || q.includes('papaya')) {
      return `पपीता फसल सलाह:\n1. रिंग स्पॉट वायरस से बचाव के लिए सफेद मक्खी व माहू पर कॉन्फिडोर 0.5ml/लीटर या नीम तेल 10000 ppm (3ml/L) का नियमित स्प्रे करें।\n2. कॉलर रॉट (तना गलन) से बचाव हेतु तने पर 1% बोर्डो पेस्ट का लेप लगाएं व रिडोमिल गोल्ड 2.5g/L से ड्रेन्चिंग करें।\n3. पपीते को हमेशा 1.5 फीट ऊंचे गादी वाफे (मेड़) पर ही लगाएं।`;
    }
    if (q.includes('टमाटर') || q.includes('tomato')) {
      return `टमाटर फसल सलाह:\n1. झुलसा व पत्ती धब्बा के लिए साफ (2g/L) या एमिस्टार टॉप (1ml/L) का छिड़काव करें।\n2. फल छेदक इल्ली के लिए प्रोक्लेम (0.5g/L) या कोराजन (0.3ml/L) का छिड़काव करें।\n3. फूल झड़ने से रोकने हेतु प्लानोफिक्स केवल 4ml प्रति 15 लीटर पंप में मिलाकर छिड़कें।`;
    }
    if (q.includes('गेहूं') || q.includes('wheat') || q.includes('पानी')) {
      return `गेहूं फसल सलाह:\n1. पहली सिंचाई (CRI स्टेज) बुआई के 20-25 दिन बाद अवश्य करें, यह सबसे महत्वपूर्ण समय है।\n2. पहली सिंचाई के बाद प्रति एकड़ 30-35 किलो यूरिया का बुरकाव करें।\n3. खरपतवार नियंत्रण के लिए 30-35 दिन पर सल्फोसल्फ्यूरॉन का छिड़काव करें।`;
    }
    if (q.includes('कपास') || q.includes('cotton') || q.includes('गुलाबी सुंडी') || q.includes('इल्ली')) {
      return `कपास कीट नियंत्रण:\n1. गुलाबी सुंडी (Pink Bollworm) के लिए खेत में प्रति एकड़ 4-5 फेरोमोन ट्रैप लगाएं।\n2. प्रारंभिक अवस्था में नीम का तेल (1500 ppm) 5ml/लीटर का छिड़काव करें।\n3. अधिक प्रकोप पर प्रोफेनोफॉस 50% EC (2ml/लीटर) का छिड़काव करें।`;
    }
    if (q.includes('पीएम किसान') || q.includes('pm kisan') || q.includes('किस्त')) {
      return `पीएम-किसान योजना जानकारी:\n1. किस्त प्राप्त करने के लिए आधार सीडिंग व ई-केवाईसी (e-KYC) अनिवार्य है।\n2. pmkisan.gov.in पर जाकर 'Beneficiary Status' में अपना मोबाइल नंबर या आधार नंबर दर्ज कर स्थिति देखें।\n3. हेल्पलाइन: 1800-180-1551 या 155261।`;
    }
    return `किसान भाई, आपकी फसल के लिए उत्तम सलाह:\n- मिट्टी परीक्षण अनुसार ही रासायनिक खाद का प्रयोग करें।\n- खेत में जलभराव न होने दें, संतुलित सिंचाई करें।\n- किसी भी बीमारी के लक्षण दिखने पर तुरंत लक्षण पहचान कर जैविक या अनुशंसित दवा का प्रयोग करें।\n- टोल फ्री किसान कॉल सेंटर 1800-180-1551 पर सुबह 6 से रात 10 बजे तक मुफ्त सलाह लें।`;
  } else {
    return `Farmer Advisory:\n1. Banana: Spray Propiconazole 1ml/L + mineral oil for Sigatoka; denavel male bud after bunch emergence.\n2. Papaya: Plant on raised beds to prevent collar rot; spray Imidacloprid 0.5ml/L for virus aphid vectors.\n3. Tomato: Use Planofix @ 4ml/15L pump for flower drop; spray Emamectin Benzoate 0.5g/L for fruit borer.\n4. Call Kisan Call Centre free at 1800-180-1551.`;
  }
}

// API: AI Farming Assistant (Chat)
app.post('/api/gemini/chat', async (req, res) => {
  try {
    const { message, lang = 'hi', history = [] } = req.body;
    if (!message) {
      return res.status(400).json({ error: 'Message is required' });
    }

    if (!ai) {
      const fallback = getFallbackAdvice(message, lang);
      return res.json({ reply: fallback, source: 'offline_knowledge' });
    }

    const languagePrompt =
      lang === 'mr'
        ? 'मराठी भाषेत अगदी सोप्या, स्पष्ट आणि ग्रामीण शेतकऱ्याला समजेल अशा भाषेत उत्तर द्या. बुलेट पॉइंट्स आणि उपाय (रासायनिक + सेंद्रिय दोन्ही) सांगा.'
        : lang === 'hi'
        ? 'सरल, शुद्ध और स्पष्ट हिंदी में उत्तर दें जो भारत के ग्रामीण किसान को आसानी से समझ आए। बुलेट पॉइंट्स, खाद की सही मात्रा और देसी/जैविक उपाय भी शामिल करें।'
        : 'Answer in clear, practical English suitable for an Indian farmer with bullet points, chemical & organic solutions, and dosage.';

    const systemInstruction = `You are "Kisan Mitra AI" (किसान मित्र), an expert agricultural scientist and agronomist in India.
Your mission is to help Indian farmers with practical, low-cost, effective, and safe agricultural advice.
Guidelines:
- Language: ${languagePrompt}
- Always specify realistic dosages (e.g. ml or gram per liter of water, or bags per acre).
- Include both organic/desi treatments (Neem oil, Jeevamrit, Trichoderma) and government-approved chemical treatments.
- Advise safety precautions while spraying pesticides.
- Keep answers concise, highly readable, without complicated jargon.`;

    const promptText = `Farmer asks: "${message}"\nProvide the best farming advisory.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: promptText,
      config: {
        systemInstruction,
        temperature: 0.7,
      },
    });

    const reply = response.text || getFallbackAdvice(message, lang);
    return res.json({ reply, source: 'gemini' });
  } catch (error: any) {
    console.error('Error in /api/gemini/chat:', error);
    const fallback = getFallbackAdvice(req.body.message || '', req.body.lang || 'hi');
    return res.json({ reply: fallback, source: 'fallback_error', error: error?.message });
  }
});

// API: AI Crop Disease Diagnosis from Image
app.post('/api/gemini/diagnose-crop', async (req, res) => {
  try {
    const { imageBase64, mimeType = 'image/jpeg', cropName = '', lang = 'hi' } = req.body;

    if (!imageBase64) {
      return res.status(400).json({ error: 'Crop image is required' });
    }

    if (!ai) {
      // Offline / fallback response based on crop
      return res.json({
        diseaseName: lang === 'mr' ? 'पानावरील करपा व रसशोषक किडीचा प्रादुर्भाव' : lang === 'hi' ? 'पत्ती धब्बा रोग एवं कीट प्रकोप' : 'Leaf Blight & Sucking Pest Attack',
        confidence: '85%',
        symptoms: lang === 'mr' 
          ? ['पानांवर पिवळे व तपकिरी ठिपके', 'पानांच्या कडा वाळणे', 'झाडाची वाढ खुंटणे']
          : ['पत्तियों पर भूरे व पीले धब्बे', 'किनारों से पत्तियों का मुड़ना व सूखना', 'पौधे की बढ़वार रुकना'],
        organicTreatment: lang === 'mr'
          ? ['५% निंबोळी अर्क (५० मिली/१० लिटर पाणी) फवारा', 'ताक आणि हिंग यांचे द्रावण वापरणे', 'ट्रायकोडर्मा विरिडी ५ ग्रॅम/लिटर']
          : ['5% नीम तेल (50ml प्रति 10 लीटर पानी) का छिड़काव करें', 'खट्टी छाछ व हींग का घोल छिड़कें', 'ट्राइकोडर्मा विरिडी 5 ग्राम/लीटर पानी में मिलाकर डालें'],
        chemicalTreatment: lang === 'mr'
          ? ['मँकोझेब ७५% WP (२.५ ग्रॅम/लिटर पाणी) बुरशीनाशक', 'किडीसाठी इमिडाक्लोप्रिड १७.८% SL (०.५ मिली/लिटर)']
          : ['मैंकोजेब 75% WP (2.5 ग्राम प्रति लीटर पानी) फफूंदनाशक', 'रस चूसक कीटों के लिए इमिडाक्लोप्रिड 17.8% SL (0.5 मिली/लीटर)'],
        preventiveTips: lang === 'mr'
          ? ['शेतात जास्त पाणी साचू देऊ नका', 'रोगट पाने खुडून नष्ट करा', 'बीजप्रक्रिया केल्याशिवाय पेरणी करू नका']
          : ['खेत में पानी का ठहराव न होने दें', 'संक्रमित पत्तियों को तोड़कर नष्ट करें', 'बुआई से पहले बीज शोधन अवश्य करें'],
        isFallback: true
      });
    }

    const cleanBase64 = imageBase64.replace(/^data:image\/[a-zA-Z+]+;base64,/, '');

    const langInstruction = lang === 'mr' ? 'मराठी' : lang === 'hi' ? 'हिंदी' : 'English';

    const promptText = `Analyze this crop leaf / plant photo.
Crop name provided by farmer: ${cropName || 'Not specified'}.
Target language for all text values: ${langInstruction}.

Diagnose the crop disease, pest, or deficiency accurately.
Provide response in strict JSON format matching this schema:
{
  "diseaseName": "Name of the disease or pest in ${langInstruction}",
  "confidence": "e.g. 92%",
  "symptoms": ["Symptom 1", "Symptom 2", "Symptom 3"],
  "organicTreatment": ["Desi/Organic remedy 1 with dosage", "Organic remedy 2"],
  "chemicalTreatment": ["Chemical pesticide/fungicide 1 with exact ml/g per liter", "Chemical treatment 2"],
  "preventiveTips": ["Prevention tip 1", "Prevention tip 2"]
}`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: {
        parts: [
          {
            inlineData: {
              data: cleanBase64,
              mimeType: mimeType || 'image/jpeg',
            },
          },
          {
            text: promptText,
          },
        ],
      },
      config: {
        responseMimeType: 'application/json',
      },
    });

    let resultJson;
    try {
      resultJson = JSON.parse(response.text || '{}');
    } catch {
      resultJson = {
        diseaseName: 'Crop Condition Analyzed',
        confidence: '80%',
        symptoms: ['Signs of stress or fungal infection detected'],
        organicTreatment: ['Spray Neem Oil 5ml/Litre water'],
        chemicalTreatment: ['Spray Mancozeb 75 WP at 2.5g/Litre water'],
        preventiveTips: ['Avoid over-irrigation and remove diseased foliage'],
      };
    }

    return res.json(resultJson);
  } catch (error: any) {
    console.error('Error in /api/gemini/diagnose-crop:', error);
    return res.status(500).json({
      error: 'Failed to analyze crop image',
      details: error?.message,
    });
  }
});

// API: Download complete project source code ZIP
app.get('/api/download-project-zip', (_req, res) => {
  try {
    const scriptPath = path.join(__dirname, 'scripts', 'zip_project.py');
    const zipPath = path.resolve('/tmp', 'kisan-mitra-portal.zip');
    execSync(`python3 "${scriptPath}"`, { cwd: __dirname });
    res.download(zipPath, 'kisan-mitra-portal.zip');
  } catch (err: any) {
    console.error('Error generating project zip:', err);
    res.status(500).json({ error: 'Failed to create zip', details: err?.message });
  }
});

// API: Download Android APK file directly
app.get(['/api/download-apk', '/KisanMitra.apk', '/download/kisan-mitra.apk'], (_req, res) => {
  const apkPath = path.resolve(__dirname, 'public', 'KisanMitra.apk');
  if (fs.existsSync(apkPath)) {
    res.setHeader('Content-Type', 'application/vnd.android.package-archive');
    return res.download(apkPath, 'KisanMitra.apk');
  }
  try {
    const buildScript = path.resolve(__dirname, 'scripts', 'build_apk.sh');
    if (fs.existsSync(buildScript)) {
      execSync(`bash "${buildScript}"`, { cwd: __dirname });
      res.setHeader('Content-Type', 'application/vnd.android.package-archive');
      return res.download(apkPath, 'KisanMitra.apk');
    }
  } catch (err: any) {
    console.error('Error auto-generating APK:', err);
  }
  return res.status(404).json({ error: 'APK file not found' });
});

// Vite middleware in dev or static files in production
async function startServer() {
  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);

    app.use('*', async (req, res, next) => {
      const url = req.originalUrl;
      try {
        let template = fs.readFileSync(path.resolve(__dirname, 'index.html'), 'utf-8');
        template = await vite.transformIndexHtml(url, template);
        res.status(200).set({ 'Content-Type': 'text/html' }).end(template);
      } catch (e: any) {
        vite.ssrFixStacktrace(e);
        next(e);
      }
    });
  } else {
    app.use(express.static(path.join(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.join(__dirname, 'dist', 'index.html'));
    });
  }

  const portNum = Number(PORT) || 3000;
  app.listen(portNum, '0.0.0.0', () => {
    console.log(`Kisan Mitra Server running on http://localhost:${portNum}`);
  });
}

startServer();
