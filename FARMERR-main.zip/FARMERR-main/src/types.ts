export type Language = 'hi' | 'mr' | 'en';

export interface MandiItem {
  id: string;
  crop: {
    hi: string;
    mr: string;
    en: string;
  };
  cropCategory: 'grains' | 'pulses' | 'oilseeds' | 'vegetables' | 'fruits' | 'commercial';
  market: string;
  district: string;
  state: string;
  minPrice: number;
  maxPrice: number;
  modalPrice: number; // typical / model price
  change: number; // positive or negative
  arrival: string; // e.g. "450 क्विंटल"
  date: string;
}

export interface WeatherData {
  city: string;
  district: string;
  state: string;
  temp: number;
  condition: string;
  conditionKey: 'sunny' | 'partly_cloudy' | 'cloudy' | 'rainy' | 'thunderstorm';
  rainProb: number;
  humidity: number;
  windSpeed: number;
  advisory: {
    hi: string;
    mr: string;
    en: string;
  };
  sprayAlert: {
    status: 'good' | 'caution' | 'danger';
    hi: string;
    mr: string;
    en: string;
  };
  forecast: Array<{
    day: {
      hi: string;
      mr: string;
      en: string;
    };
    date: string;
    tempMax: number;
    tempMin: number;
    rainProb: number;
    conditionKey: 'sunny' | 'partly_cloudy' | 'cloudy' | 'rainy' | 'thunderstorm';
  }>;
}

export interface SchemeItem {
  id: string;
  title: {
    hi: string;
    mr: string;
    en: string;
  };
  category: 'central' | 'state' | 'insurance' | 'subsidy' | 'loan';
  benefit: {
    hi: string;
    mr: string;
    en: string;
  };
  eligibility: {
    hi: string[];
    mr: string[];
    en: string[];
  };
  documents: {
    hi: string[];
    mr: string[];
    en: string[];
  };
  howToApply: {
    hi: string[];
    mr: string[];
    en: string[];
  };
  portalUrl: string;
  helpline: string;
  badge: {
    hi: string;
    mr: string;
    en: string;
  };
}

export interface CropGuide {
  id: string;
  name: {
    hi: string;
    mr: string;
    en: string;
  };
  season: 'kharif' | 'rabi' | 'zaid';
  sowingMonths: {
    hi: string;
    mr: string;
    en: string;
  };
  seedRate: {
    hi: string;
    mr: string;
    en: string;
  };
  seedTreatment: {
    hi: string;
    mr: string;
    en: string;
  };
  fertilizerDose: {
    hi: string;
    mr: string;
    en: string;
  };
  irrigationSchedule: {
    hi: string[];
    mr: string[];
    en: string[];
  };
  expectedYield: {
    hi: string;
    mr: string;
    en: string;
  };
  topTip: {
    hi: string;
    mr: string;
    en: string;
  };
}

export interface DiseaseItem {
  id: string;
  crop: {
    hi: string;
    mr: string;
    en: string;
  };
  name: {
    hi: string;
    mr: string;
    en: string;
  };
  sampleImage: string;
  symptoms: {
    hi: string[];
    mr: string[];
    en: string[];
  };
  organicTreatment: {
    hi: string[];
    mr: string[];
    en: string[];
  };
  chemicalTreatment: {
    hi: string[];
    mr: string[];
    en: string[];
  };
  prevention: {
    hi: string[];
    mr: string[];
    en: string[];
  };
}

export interface MarketListing {
  id: string;
  title: string;
  category: 'seeds' | 'fertilizer' | 'equipment' | 'crops' | 'cattle';
  price: number;
  unit: string;
  quantity: string;
  sellerName: string;
  phone: string;
  village: string;
  district: string;
  state: string;
  date: string;
  description: string;
  isUserAdded?: boolean;
}

export interface HelplineContact {
  id: string;
  name: {
    hi: string;
    mr: string;
    en: string;
  };
  number: string;
  timing: {
    hi: string;
    mr: string;
    en: string;
  };
  description: {
    hi: string;
    mr: string;
    en: string;
  };
  type: 'free' | 'dept' | 'emergency';
}

export interface CropGrowthGuide {
  id: string;
  cropName: {
    hi: string;
    mr: string;
    en: string;
  };
  category: 'fruits' | 'vegetables' | 'grains' | 'cash';
  durationDays: string;
  idealSoil: {
    hi: string;
    mr: string;
    en: string;
  };
  landPreparation: {
    hi: string[];
    mr: string[];
    en: string[];
  };
  seedTreatmentAndSpacing: {
    hi: string;
    mr: string;
    en: string;
  };
  irrigationTimetable: Array<{
    stage: {
      hi: string;
      mr: string;
      en: string;
    };
    daysAfterSowing: string;
    waterRequirement: {
      hi: string;
      mr: string;
      en: string;
    };
    importance: {
      hi: string;
      mr: string;
      en: string;
    };
  }>;
  fertilizerSchedule: Array<{
    timing: {
      hi: string;
      mr: string;
      en: string;
    };
    fertilizerDose: {
      hi: string;
      mr: string;
      en: string;
    };
    howToApply: {
      hi: string;
      mr: string;
      en: string;
    };
  }>;
  sprayTimetable: Array<{
    timing: {
      hi: string;
      mr: string;
      en: string;
    };
    targetDiseasePest: {
      hi: string;
      mr: string;
      en: string;
    };
    medicineAndDose: {
      hi: string;
      mr: string;
      en: string;
    };
  }>;
  yieldMaximizingTips: {
    hi: string[];
    mr: string[];
    en: string[];
  };
  expectedHarvestYield: {
    hi: string;
    mr: string;
    en: string;
  };
}
