import { SchemeItem } from '../types';

export const SCHEMES_DATA: SchemeItem[] = [
  {
    id: 'pm-kisan',
    title: {
      hi: 'प्रधानमंत्री किसान सम्मान निधि (PM-KISAN)',
      mr: 'पंतप्रधान किसान सन्मान निधी (PM-KISAN)',
      en: 'PM-Kisan Samman Nidhi Yojana',
    },
    category: 'central',
    badge: {
      hi: '₹6,000 प्रति वर्ष',
      mr: '₹६,००० प्रति वर्ष',
      en: '₹6,000 / Year',
    },
    benefit: {
      hi: 'पात्र किसानों को हर 4 महीने में ₹2,000 की 3 समान किस्तों में कुल ₹6,000 सीधे बैंक खाते में (DBT) दिए जाते हैं।',
      mr: 'पात्र शेतकऱ्यांना दर ४ महिन्यांनी ₹२,००० याप्रमाणे वर्षाला एकूण ₹६,००० थेट बँक खात्यात (DBT) मिळतात.',
      en: 'Direct transfer of ₹6,000 annually into bank account in 3 equal instalments of ₹2,000 every 4 months.',
    },
    eligibility: {
      hi: [
        'सभी भूमिधारक किसान परिवार जिनके नाम पर खेती योग्य जमीन दर्ज है',
        'संस्थागत भूमिधारक, संवैधानिक पदधारक या ₹10,000+ पेंशन पाने वाले पात्र नहीं हैं',
        'बैंक खाता आधार और एनपीसीआई (NPCI) से लिंक होना अनिवार्य है',
        'e-KYC प्रक्रिया पूर्ण होना आवश्यक है',
      ],
      mr: [
        'ज्या शेतकऱ्यांच्या नावावर शेतजमीन (७/१२) नोंद आहे ते सर्व कुटुंब',
        'संस्थात्मक जमीनधारक, सरकारी नोकरदार किंवा आयकर भरणारे अपात्र आहेत',
        'बँक खाते आधार व NPCI शी जोडलेले असणे अनिवार्य आहे',
        'बायोमेट्रिक किंवा ओटीपी द्वारे e-KYC पूर्ण असणे गरजेचे',
      ],
      en: [
        'All landholding farmer families with cultivable land in their name',
        'Institutional landholders and income tax payers are excluded',
        'Bank account must be Aadhaar and NPCI seeded',
        'Mandatory e-KYC via OTP or biometric',
      ],
    },
    documents: {
      hi: [
        'आधार कार्ड (Aadhaar Card)',
        'जमीन की खतौनी / जमाबंदी (7/12 उतारा / Land Record)',
        'बैंक पासबुक (Bank Passbook with IFSC)',
        'आधार से जुड़ा मोबाइल नंबर (Mobile linked with Aadhaar)',
      ],
      mr: [
        'आधार कार्ड (Aadhaar Card)',
        'जमिनीचा ७/१२ व ८-अ उतारा (Land Record)',
        'बँक पासबुक झेरॉक्स (IFSC कोडसह)',
        'आधार लिंक असलेला मोबाईल नंबर',
      ],
      en: [
        'Aadhaar Card',
        'Land Record (7/12 extract / Khatauni)',
        'Bank Account Passbook (IFSC code)',
        'Aadhaar-linked Mobile Number',
      ],
    },
    howToApply: {
      hi: [
        '1. आधिकारिक पोर्टल pmkisan.gov.in पर जाएं या नजदीकी CSC केंद्र पर जाएं।',
        '2. "Farmers Corner" में "New Farmer Registration" पर क्लिक करें।',
        '3. अपना आधार नंबर और राज्य चुनें, फिर ओटीपी दर्ज करें।',
        '4. जमीन का खाता/खसरा नंबर और बैंक खाता विवरण भरकर सबमिट करें।',
        '5. स्थिति देखने के लिए "Know Your Status" विकल्प का प्रयोग करें।',
      ],
      mr: [
        '१. pmkisan.gov.in पोर्टल उघडा किंवा जवळच्या महा-ई-सेवा केंद्रात जा.',
        '२. "Farmers Corner" मध्ये "New Farmer Registration" पर्यायावर क्लिक करा.',
        '३. आधार क्रमांक व मोबाईल क्रमांक टाकून OTP तपासा.',
        '४. शेतीचा ७/१२ खाते क्रमांक व बँक माहिती भरून फॉर्म सबमिट करा.',
        '५. हप्ता तपासण्यासाठी "Know Your Status" वर आधार नंबर टाका.',
      ],
      en: [
        '1. Visit official website pmkisan.gov.in or visit common service center (CSC).',
        '2. Click on "New Farmer Registration" under Farmers Corner.',
        '3. Enter Aadhaar number, state, mobile and verify via OTP.',
        '4. Fill in land ownership survey numbers and bank IFSC details.',
        '5. Use "Know Your Status" tab anytime to track payment releases.',
      ],
    },
    portalUrl: 'https://pmkisan.gov.in',
    helpline: '155261 / 1800-115-526',
  },
  {
    id: 'pmfby',
    title: {
      hi: 'प्रधानमंत्री फसल बीमा योजना (PMFBY)',
      mr: 'पंतप्रधान पीक विमा योजना (PMFBY)',
      en: 'Pradhan Mantri Fasal Bima Yojana (PMFBY)',
    },
    category: 'insurance',
    badge: {
      hi: 'फसल नुकसान पर भरपाई',
      mr: 'नुकसान भरपाई संरक्षण',
      en: 'Crop Loss Compensation',
    },
    benefit: {
      hi: 'बाढ़, सूखा, बेमौसम बारिश, कीट प्रकोप या ओलावृष्टि से फसल खराब होने पर बीमित राशि का पूरा क्लेम मिलता है। किसान को केवल 1.5% से 2% प्रीमियम देना होता है (महाराष्ट्र में केवल ₹1)।',
      mr: 'अतिवृष्टी, दुष्काळ, अवकाळी पाऊस किंवा कीड रोगामुळे पिकांचे नुकसान झाल्यास विम्याची भरपाई मिळते. महाराष्ट्रात शेतकऱ्यांना अवघ्या ₹१ मध्ये पीक विमा मिळतो.',
      en: 'Full insurance claim coverage against natural calamities, pests, droughts, and unseasonal rains at minimal premium (just ₹1 in Maharashtra).',
    },
    eligibility: {
      hi: [
        'अधिसूचित क्षेत्र में अधिसूचित फसलें उगाने वाले सभी किसान (बटाईदार भी)',
        'ऋणी (KCC धारक) और गैर-ऋणी दोनों प्रकार के किसान पात्र हैं',
        'फसल नुकसान होने के 72 घंटे के भीतर सूचना देना अनिवार्य है',
      ],
      mr: [
        'अधिसूचित भागात अधिसूचित पिके घेणारे सर्व शेतकरी (भाडेतत्त्वावरील शेतकरीही)',
        'नुकसान झाल्यापासून ७२ तासांच्या आत विमा कंपनीला पूर्वसूचना देणे बंधनकारक',
        'Crop Insurance ॲप किंवा टोल-फ्री क्रमांकावर क्लेम नोंदवता येतो',
      ],
      en: [
        'All farmers growing notified crops in notified areas',
        'Both loanee (KCC) and non-loanee farmers eligible',
        'Mandatory intimation within 72 hours of localized crop calamity',
      ],
    },
    documents: {
      hi: [
        'आधार कार्ड',
        '7/12 उतारा एवं फसल बुआई घोषणा पत्र (Pik Perani)',
        'बैंक खाता पासबुक',
        'किरायेदार होने पर बटाईदार शपथ पत्र',
      ],
      mr: [
        'आधार कार्ड',
        '७/१२ व पीक पाहणी (ई-पीक पाहणी नोंद)',
        'बँक पासबुक झेरॉक्स',
        'भाडेपट्टा करार (असेल तर)',
      ],
      en: [
        'Aadhaar Card',
        'Land Record (7/12) with crop sowing declaration (E-Pik Pahani)',
        'Bank Passbook photocopy',
        'Self-declaration / Tenant agreement if applicable',
      ],
    },
    howToApply: {
      hi: [
        '1. pmfby.gov.in पर जाएं या "Crop Insurance" मोबाइल ऐप डाउनलोड करें।',
        '2. बुआई के अंतिम तिथि से पहले अपनी फसल का चयन कर प्रीमियम भरें।',
        '3. फसल नष्ट होने पर ऐप में "Report Crop Loss" पर जाकर 72 घंटे में फोटो अपलोड करें।',
        '4. सर्वेक्षण के बाद सीधे बैंक खाते में बीमा दावा जमा होगा।',
      ],
      mr: [
        '१. pmfby.gov.in पोर्टल किंवा महाडीबीटी/CSC केंद्रावर अर्ज करा.',
        '२. ई-पीक पाहणीनुसार पिकांची माहिती नोंदवून विम्याचा हप्ता भरा.',
        '३. नुकसान झाल्यास ७२ तासांच्या आत ॲपमध्ये किंवा 1800-180-2117 वर कॉल करून तक्रार नोंदवा.',
        '४. पंचनाम्यानंतर मंजूर रक्कम थेट खात्यात वर्ग होते.',
      ],
      en: [
        '1. Apply on pmfby.gov.in or download the official Crop Insurance App.',
        '2. Select crop, area, bank details and complete registration before cut-off date.',
        '3. If damage occurs, register intimation within 72 hrs via toll-free or app with photo.',
        '4. Post-survey verification, claim is transferred directly to bank account.',
      ],
    },
    portalUrl: 'https://pmfby.gov.in',
    helpline: '1800-180-2117 (टोल फ्री)',
  },
  {
    id: 'pm-kusum',
    title: {
      hi: 'पीएम कुसुम सोलर पंप योजना (PM-KUSUM)',
      mr: 'पीएम कुसुम सौर कृषी पंप योजना (KUSUM)',
      en: 'PM KUSUM Solar Agriculture Pump',
    },
    category: 'subsidy',
    badge: {
      hi: '60% से 90% सब्सिडी',
      mr: '६०% ते ९०% अनुदान',
      en: 'Up to 90% Subsidy',
    },
    benefit: {
      hi: 'किसानों को 3HP, 5HP और 7.5HP का सोलर पंप लगाने के लिए 90% तक की भारी सरकारी सब्सिडी। दिन में मुफ्त बिजली से सिंचाई की सुविधा।',
      mr: 'शेतकऱ्यांना ३, ५ आणि ७.५ अश्वशक्ती (HP) चे सौर कृषी पंप बसवण्यासाठी ९०% पर्यंत भरीव सरकारी अनुदान. दिवसा मोफत वीज मिळून सिंचनाची हमी.',
      en: 'Up to 90% subsidy for installing 3HP, 5HP & 7.5HP solar pumps, providing dependable daytime irrigation.',
    },
    eligibility: {
      hi: [
        'जिनके खेत में पहले से पारंपरिक बिजली कनेक्शन नहीं है, उन्हें प्राथमिकता',
        'खेत में बोरवेल, कुआं या पानी का स्थाई स्रोत होना आवश्यक',
        'जमीन के रकबे के आधार पर पंप क्षमता (2 एकड़ तक 3HP, 2-5 एकड़ 5HP, 5+ एकड़ 7.5HP)',
      ],
      mr: [
        'पारंपरिक वीज जोडणी नसलेल्या शेतकऱ्यांना प्राधान्य',
        'शेतात विहीर, बोरवेल किंवा पाण्याचा शाश्वत स्त्रोत असणे आवश्यक',
        'जमिनीनुसार: २.५ एकरापर्यंत ३ HP, ५ एकरापर्यंत ५ HP, ५ एकरापेक्षा जास्त ७.५ HP',
      ],
      en: [
        'Farmers without conventional grid electricity connection get first priority',
        'Water source (well, borewell, canal, farm pond) must be available',
        'Pump capacity based on land size: 3HP (<2.5 acres), 5HP (2.5-5 acres), 7.5HP (>5 acres)',
      ],
    },
    documents: {
      hi: [
        'आधार कार्ड एवं जाति प्रमाण पत्र (यदि लागू हो)',
        '7/12 खसरा खतौनी एवं 8-अ उतारा',
        'पानी के स्रोत का स्व-घोषणा पत्र / फोटो',
        'बैंक खाता पासबुक एवं पासपोर्ट फोटो',
      ],
      mr: [
        'आधार कार्ड',
        '७/१२ व ८-अ उतारा (जमीन उतारा)',
        'विहीर/बोरवेल पाणी स्त्रोत असल्याचे प्रमाणपत्र/स्वघोषणा',
        'बँक पासबुक व पासपोर्ट साईझ फोटो',
      ],
      en: [
        'Aadhaar card and caste certificate (if applicable)',
        '7/12 Land ownership records and 8-A',
        'Water source proof / self-declaration',
        'Bank passbook and photograph',
      ],
    },
    howToApply: {
      hi: [
        '1. राज्य ऊर्जा विकास एजेंसी (जैसे महाऊर्जा MEDA / pmkusum.mnre.gov.in) पर जाएं।',
        '2. ऑनलाइन आवेदन फॉर्म में किसान व जमीन का विवरण दर्ज करें।',
        '3. 10% किसान अंशदान (Share) ऑनलाइन जमा करें।',
        '4. एजेंसी द्वारा सर्वे के बाद खेत में सोलर पैनल व मोटर पंप लगाया जाएगा।',
      ],
      mr: [
        '१. महाऊर्जा (MEDA) पोर्टल किंवा कुसुम योजनेच्या अधिकृत संकेतस्थळावर नोंदणी करा.',
        '२. ऑनलाईन अर्जात शेताचा ७/१२ आणि आवश्यक कागदपत्रे अपलोड करा.',
        '३. मंजुरी मिळाल्यानंतर १०% शेतकरी हिस्सा जमा करा.',
        '४. अधिकृत कंपनीचे तंत्रज्ञ शेतात येऊन सोलर पंप बसवून देतील.',
      ],
      en: [
        '1. Register on your state renewable portal (e.g., MEDA Mahaurja or pmkusum.mnre.gov.in).',
        '2. Upload land records and water source availability.',
        '3. Pay the nominal 10% farmer share after application approval.',
        '4. Certified technicians inspect and install the solar pump kit on your field.',
      ],
    },
    portalUrl: 'https://pmkusum.mnre.gov.in',
    helpline: '1800-180-3333',
  },
  {
    id: 'kcc',
    title: {
      hi: 'किसान क्रेडिट कार्ड (KCC Loan)',
      mr: 'किसान क्रेडिट कार्ड (KCC कर्ज योजना)',
      en: 'Kisan Credit Card (KCC Loan)',
    },
    category: 'loan',
    badge: {
      hi: '4% सस्ती ब्याज दर',
      mr: '४% सवलतीचे व्याजदर',
      en: '4% Low Interest Loan',
    },
    benefit: {
      hi: 'बीज, खाद, कीटनाशक और मजदूरी के लिए ₹3,00,000 तक का फसली ऋण केवल 4% ब्याज पर (समय पर चुकाने पर 3% छूट मिलती है)। कोई गारंटी नहीं चाहिए ₹1.6 लाख तक।',
      mr: 'बियाणे, खते व मजुरीसाठी ₹३ लाख पर्यंतचे पीक कर्ज अवघ्या ४% सवलतीच्या व्याजाने (वेळेत फेड केल्यास ३% अनुदान). ₹१.६० लाखापर्यंत तारणमुक्त कर्ज.',
      en: 'Crop cultivation loan up to ₹3,00,000 at an effective interest rate of just 4% upon timely repayment. Collateral-free up to ₹1.60 Lakh.',
    },
    eligibility: {
      hi: [
        'सभी किसान (व्यक्तिगत या संयुक्त रूप से खेती करने वाले)',
        'पशुपालक और मत्स्य पालक किसान भी ₹2 लाख तक KCC के पात्र हैं',
        'उम्र 18 से 75 वर्ष के बीच होनी चाहिए',
      ],
      mr: [
        'सर्व खातेदार शेतकरी किंवा कुळ शेतकरी',
        'दुग्धव्यवसाय, शेळीपालन व मत्स्यपालन करणारे शेतकरीही ₹२ लाखापर्यंत पात्र',
        'वय १८ ते ७५ वर्षांच्या दरम्यान असावे',
      ],
      en: [
        'All individual or joint borrower farmers and tenant cultivators',
        'Dairy, animal husbandry and fisheries farmers eligible up to ₹2 Lakh',
        'Age between 18 and 75 years',
      ],
    },
    documents: {
      hi: [
        'भरा हुआ KCC आवेदन फॉर्म (1 पेज का सरल फॉर्म)',
        'पहचान व निवास प्रमाण (आधार कार्ड, वोटर आईडी)',
        'जमीन की ताजा खतौनी (7/12, 8-A उतारा)',
        'फसल बुआई का विवरण (Pik Perani)',
      ],
      mr: [
        'केसीसी १-पानी साधा अर्ज',
        'आधार कार्ड व पॅन कार्ड',
        'चालू वर्षाचा ७/१२ व ८-अ उतारा',
        'पीक पाहणी नोंद (ई-पीक पाहणी)',
      ],
      en: [
        'Simplified 1-page KCC application form',
        'Identity & Address Proof (Aadhaar)',
        'Latest Land Record documents (7/12, 8-A)',
        'Sown crop verification details',
      ],
    },
    howToApply: {
      hi: [
        '1. अपनी नजदीकी बैंक शाखा (ग्रामीण बैंक, SBI, या जिला सहकारी बैंक) में जाएं।',
        '2. एक पेज का सरल KCC फॉर्म भरें और 7/12 व आधार संलग्न करें।',
        '3. बैंक 14 दिनों के भीतर कार्ड व क्रेडिट लिमिट जारी करता है।',
        '4. एटीएम रूपे कार्ड से खाद की दुकान पर या बैंक से कभी भी नकद निकालें।',
      ],
      mr: [
        '१. आपल्या गावातील बँक शाखा किंवा जिल्हा मध्यवर्ती सहकारी बँकेत जा.',
        '२. KCC चा १ पानी फॉर्म भरून त्याला ७/१२ व आधार जोडा.',
        '३. बँक १४ दिवसांत कर्ज मंजूर करून RuPay KCC कार्ड देते.',
        '४. एटीएम किंवा दुकानावर स्वाईप करून आवश्यकतेनुसार पैसे काढा.',
      ],
      en: [
        '1. Visit your local bank branch (SBI, Grameen Bank, DCC Bank).',
        '2. Submit the 1-page KCC form with 7/12 and Aadhaar.',
        '3. Banks are mandated to issue the card within 14 days.',
        '4. Withdraw cash via RuPay card or swipe directly at fertilizer/seed shops.',
      ],
    },
    portalUrl: 'https://myscheme.gov.in/schemes/kcc',
    helpline: '1800-11-2211 (SBI)',
  },
  {
    id: 'drip-subsidy',
    title: {
      hi: 'प्रधानमंत्री कृषि सिंचाई योजना (ड्रिप व स्प्रिंकलर सब्सिडी)',
      mr: 'सूक्ष्म सिंचन योजना (ठिबक व तुषार सिंचन ५५% ते ८०% अनुदान)',
      en: 'Micro Irrigation Drip & Sprinkler Subsidy (PMKSY)',
    },
    category: 'subsidy',
    badge: {
      hi: '55% से 80% सब्सिडी',
      mr: '५५% ते ८०% अनुदान',
      en: '55% to 80% Subsidy',
    },
    benefit: {
      hi: 'खेत में ड्रिप (टपक) या स्प्रिंकलर (फव्वारा) सिंचाई लगाने पर छोटे व सीमांत किसानों को 80% तथा अन्य किसानों को 55% सीधी सब्सिडी मिलती है। 50% पानी की बचत और 30% अधिक उपज।',
      mr: 'ठिबक किंवा तुषार सिंचन संच बसवण्यासाठी अल्प व अत्यल्प भूधारक शेतकऱ्यांना ८०% आणि इतर शेतकऱ्यांना ५५% शासकीय अनुदान मिळते. पाण्याची ५०% बचत आणि उत्पादनात वाढ.',
      en: 'Direct subsidy of 55% to 80% for drip irrigation and sprinkler systems. Saves 50% water and boosts yields by 30%.',
    },
    eligibility: {
      hi: [
        'किसान के पास स्वयं की जमीन और सुनिश्चित पानी का स्रोत होना चाहिए',
        'अधिकतम 5 हेक्टेयर तक सब्सिडी का लाभ मिलता है',
        'पहले 7 वर्षों में उसी जमीन पर दोबारा सब्सिडी नहीं ली हो',
      ],
      mr: [
        'शेतकऱ्याकडे स्वतःची शेतजमीन आणि विहीर/कूपनलिका असणे आवश्यक',
        'जास्तीत जास्त ५ हेक्टर क्षेत्रापर्यंत अनुदानाचा लाभ',
        'मागील ७ वर्षांत त्या क्षेत्रावर ठिबकचे अनुदान घेतलेले नसावे',
      ],
      en: [
        'Farmer must possess land title and functional water source',
        'Subsidy available up to maximum of 5 hectares per beneficiary',
        'Should not have availed micro-irrigation subsidy on same plot in past 7 years',
      ],
    },
    documents: {
      hi: [
        '7/12 खतौनी और 8-A उतारा',
        'आधार कार्ड और बैंक पासबुक',
        'अधिकृत विक्रेता का कोटेशन / बिल (GST Quotation)',
        'पानी व बिजली कनेक्शन बिल (यदि हो)',
      ],
      mr: [
        '७/१२ व ८-अ उतारा',
        'आधार कार्ड आणि बँक पासबुक झेरॉक्स',
        'मान्यताप्राप्त कंपनीचे दरपत्रक (Quotation)',
        'विद्युत जोडणी किंवा सौर पंपाचा पुरावा',
      ],
      en: [
        '7/12 Land ownership and 8-A documents',
        'Aadhaar card and bank account details',
        'Registered dealer quotation with GST bill',
        'Electricity/pump certificate',
      ],
    },
    howToApply: {
      hi: [
        '1. राज्य कृषि पोर्टल (जैसे महाराष्ट्र में mahadbt.maharashtra.gov.in) पर आवेदन करें।',
        '2. "सिंचाई साधन" विकल्प चुनकर ड्रिप या स्प्रिंकलर चुनें।',
        '3. लॉटरी में नाम आने पर पूर्व-सहमति (Pre-sanction) पत्र प्राप्त होगा।',
        '4. अधिकृत डीलर से सामान खरीदकर बिल अपलोड करें, सब्सिडी खाते में आएगी।',
      ],
      mr: [
        '१. महाडीबीटी शेतकरी पोर्टल (mahadbt.maharashtra.gov.in) वर अर्ज करा.',
        '२. "सिंचन साधने" मध्ये ठिबक किंवा तुषार सिंचन पर्याय निवडा.',
        '३. सोडतीत (लॉटरी) निवड झाल्यावर पूर्वसंमती पत्र मिळते.',
        '४. संच बसवून GST बिल व जिओ-टॅग फोटो अपलोड करा, अनुदान थेट खात्यात जमा होते.',
      ],
      en: [
        '1. Apply online on state agriculture portal (e.g., MahaDBT in Maharashtra).',
        '2. Select "Irrigation Tools" and choose Drip or Sprinkler.',
        '3. Once selected via lottery, receive Pre-sanction approval letter.',
        '4. Purchase from authorized dealer, submit invoice and geo-tagged photo for direct credit.',
      ],
    },
    portalUrl: 'https://mahadbt.maharashtra.gov.in',
    helpline: '1800-120-8040 (MahaDBT)',
  },
];
