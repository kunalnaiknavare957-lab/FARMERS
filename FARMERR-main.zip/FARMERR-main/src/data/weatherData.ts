import { WeatherData } from '../types';

export interface VillageInfo {
  id: string;
  name: {
    hi: string;
    mr: string;
    en: string;
  };
  lat: number;
  lon: number;
}

export interface TalukaInfo {
  id: string;
  name: {
    hi: string;
    mr: string;
    en: string;
  };
  villages: VillageInfo[];
}

export interface DistrictInfo {
  id: string;
  name: {
    hi: string;
    mr: string;
    en: string;
  };
  division: 'Nashik' | 'Pune' | 'Marathwada' | 'Vidarbha' | 'Konkan' | 'Other';
  state: string;
  defaultLat: number;
  defaultLon: number;
  talukas: TalukaInfo[];
}

// Complete dataset of all 36 Districts of Maharashtra + Subdivisions/Talukas + Agricultural Villages
export const MAHARASHTRA_DISTRICTS: DistrictInfo[] = [
  // ================= NASHIK DIVISION =================
  {
    id: 'nashik',
    name: { hi: 'नाशिक (Nashik)', mr: 'नाशिक (Nashik)', en: 'Nashik' },
    division: 'Nashik',
    state: 'Maharashtra',
    defaultLat: 19.9975,
    defaultLon: 73.7898,
    talukas: [
      {
        id: 'niphad',
        name: { hi: 'निफाड (Niphad)', mr: 'निफाड (Niphad)', en: 'Niphad' },
        villages: [
          { id: 'lasalgaon', name: { hi: 'लासलगांव (Lasalgaon)', mr: 'लासलगाव (Lasalgaon)', en: 'Lasalgaon' }, lat: 20.1472, lon: 74.2281 },
          { id: 'pimpalgaon_b', name: { hi: 'पिंपळगांव बसवंत (Pimpalgaon Baswant)', mr: 'पिंपळगाव बसवंत (Pimpalgaon Baswant)', en: 'Pimpalgaon Baswant' }, lat: 20.1742, lon: 73.9872 },
          { id: 'ozar', name: { hi: 'ओझर (Ozar)', mr: 'ओझर (Ozar)', en: 'Ozar' }, lat: 20.0945, lon: 73.9248 },
          { id: 'vinchur', name: { hi: 'विंचूर (Vinchur)', mr: 'विंचूर (Vinchur)', en: 'Vinchur' }, lat: 20.1118, lon: 74.2372 },
          { id: 'saikheda', name: { hi: 'सायखेडा (Saikheda)', mr: 'सायखेडा (Saikheda)', en: 'Saikheda' }, lat: 20.0521, lon: 74.0245 },
          { id: 'ranwad', name: { hi: 'रानवड (Ranwad)', mr: 'रानवड (Ranwad)', en: 'Ranwad' }, lat: 20.1245, lon: 74.1522 },
        ],
      },
      {
        id: 'yeola',
        name: { hi: 'येवला (Yeola)', mr: 'येवला (Yeola)', en: 'Yeola' },
        villages: [
          { id: 'yeola_city', name: { hi: 'येवला ग्रामीण (Yeola Rural)', mr: 'येवला ग्रामीण (Yeola Rural)', en: 'Yeola Rural' }, lat: 20.0425, lon: 74.4872 },
          { id: 'andarsul', name: { hi: 'अंदरसूल (Andarsul)', mr: 'अंदरसूल (Andarsul)', en: 'Andarsul' }, lat: 20.0211, lon: 74.5512 },
          { id: 'nagarsul', name: { hi: 'नगरसूल (Nagarsul)', mr: 'नगरसूल (Nagarsul)', en: 'Nagarsul' }, lat: 20.0821, lon: 74.4511 },
          { id: 'kotamgaon', name: { hi: 'कोटमगाव (Kotamgaon)', mr: 'कोटमगाव (Kotamgaon)', en: 'Kotamgaon' }, lat: 20.0612, lon: 74.4125 },
        ],
      },
      {
        id: 'dindori',
        name: { hi: 'दिंडोरी (Dindori)', mr: 'दिंडोरी (Dindori)', en: 'Dindori' },
        villages: [
          { id: 'dindori_rural', name: { hi: 'दिंडोरी गाव (Dindori)', mr: 'दिंडोरी गाव (Dindori)', en: 'Dindori Village' }, lat: 20.2014, lon: 73.8341 },
          { id: 'vani', name: { hi: 'वणी (Vani / Saptashrungi)', mr: 'वणी (Vani)', en: 'Vani' }, lat: 20.3152, lon: 73.8965 },
          { id: 'janori', name: { hi: 'जानोरी (Janori)', mr: 'जानोरी (Janori)', en: 'Janori' }, lat: 20.1412, lon: 73.8741 },
          { id: 'mohandari', name: { hi: 'मोहदरी (Mohdari)', mr: 'मोहदरी (Mohdari)', en: 'Mohdari' }, lat: 20.1812, lon: 73.7912 },
        ],
      },
      {
        id: 'sinnar',
        name: { hi: 'सिन्नर (Sinnar)', mr: 'सिन्नर (Sinnar)', en: 'Sinnar' },
        villages: [
          { id: 'sinnar_rural', name: { hi: 'सिन्नर ग्रामीण (Sinnar Rural)', mr: 'सिन्नर ग्रामीण (Sinnar Rural)', en: 'Sinnar Rural' }, lat: 19.8456, lon: 73.9982 },
          { id: 'dubere', name: { hi: 'डुबेरे (Dubere)', mr: 'डुबेरे (Dubere)', en: 'Dubere' }, lat: 19.8012, lon: 73.9451 },
          { id: 'musalgaon', name: { hi: 'मुसळगाव (Musalgaon)', mr: 'मुसळगाव (Musalgaon)', en: 'Musalgaon' }, lat: 19.8641, lon: 74.0412 },
          { id: 'dapur', name: { hi: 'दापूर (Dapur)', mr: 'दापूर (Dapur)', en: 'Dapur' }, lat: 19.8912, lon: 74.1245 },
        ],
      },
      {
        id: 'malegaon',
        name: { hi: 'मालेगांव (Malegaon)', mr: 'मालेगाव (Malegaon)', en: 'Malegaon' },
        villages: [
          { id: 'dabhadi', name: { hi: 'दाभाडी (Dabhadi)', mr: 'दाभाडी (Dabhadi)', en: 'Dabhadi' }, lat: 20.5512, lon: 74.5214 },
          { id: 'ravalgaon', name: { hi: 'रावळगाव (Ravalgaon)', mr: 'रावळगाव (Ravalgaon)', en: 'Ravalgaon' }, lat: 20.5912, lon: 74.4512 },
          { id: 'saundane', name: { hi: 'सौंदाणे (Saundane)', mr: 'सौंदाणे (Saundane)', en: 'Saundane' }, lat: 20.4812, lon: 74.4125 },
        ],
      },
      {
        id: 'chandwad',
        name: { hi: 'चांदवड (Chandwad)', mr: 'चांदवड (Chandwad)', en: 'Chandwad' },
        villages: [
          { id: 'chandwad_rural', name: { hi: 'चांदवड ग्रामीण (Chandwad Rural)', mr: 'चांदवड ग्रामीण (Chandwad Rural)', en: 'Chandwad Rural' }, lat: 20.3245, lon: 74.2412 },
          { id: 'vadner_bhairob', name: { hi: 'वडनेर भैरव (Vadner Bhairav)', mr: 'वडनेर भैरव (Vadner Bhairav)', en: 'Vadner Bhairav' }, lat: 20.2812, lon: 74.1512 },
          { id: 'dhotane', name: { hi: 'धोडांबे (Dhodambe)', mr: 'धोडंबे (Dhodambe)', en: 'Dhodambe' }, lat: 20.2512, lon: 74.1841 },
        ],
      },
      {
        id: 'baglan',
        name: { hi: 'बागलाण / सटाणा (Baglan / Satana)', mr: 'बागलाण / सटाणा (Baglan / Satana)', en: 'Baglan / Satana' },
        villages: [
          { id: 'satana', name: { hi: 'सटाणा (Satana)', mr: 'सटाणा (Satana)', en: 'Satana' }, lat: 20.5912, lon: 74.2012 },
          { id: 'nampur', name: { hi: 'नामपूर (Nampur)', mr: 'नामपूर (Nampur)', en: 'Nampur' }, lat: 20.6712, lon: 74.2812 },
          { id: 'taharabad', name: { hi: 'ताहाराबाद (Taharabad)', mr: 'ताहाराबाद (Taharabad)', en: 'Taharabad' }, lat: 20.6212, lon: 74.0512 },
        ],
      },
      {
        id: 'kalwan',
        name: { hi: 'कळवण (Kalwan)', mr: 'कळवण (Kalwan)', en: 'Kalwan' },
        villages: [
          { id: 'kalwan_rural', name: { hi: 'कळवण ग्रामीण (Kalwan Rural)', mr: 'कळवण ग्रामीण (Kalwan Rural)', en: 'Kalwan Rural' }, lat: 20.4812, lon: 73.9812 },
          { id: 'abhona', name: { hi: 'अभona (Abhona)', mr: 'आभोणा (Abhona)', en: 'Abhona' }, lat: 20.5212, lon: 73.8912 },
          { id: 'behed', name: { hi: 'बेहड (Behed)', mr: 'बेहड (Behed)', en: 'Behed' }, lat: 20.4412, lon: 73.9412 },
        ],
      },
      {
        id: 'deola',
        name: { hi: 'देवळा (Deola)', mr: 'देवळा (Deola)', en: 'Deola' },
        villages: [
          { id: 'deola_rural', name: { hi: 'देवळा मुख्य गाव (Deola)', mr: 'देवळा मुख्य गाव (Deola)', en: 'Deola Village' }, lat: 20.5124, lon: 74.1812 },
          { id: 'umrane', name: { hi: 'उमराणे (Umrane)', mr: 'उमराणे (Umrane)', en: 'Umrane' }, lat: 20.4512, lon: 74.2212 },
          { id: 'meshi', name: { hi: 'मेशी (Meshi)', mr: 'मेशी (Meshi)', en: 'Meshi' }, lat: 20.5312, lon: 74.2512 },
        ],
      },
      {
        id: 'igatpuri',
        name: { hi: 'इगतपुरी (Igatpuri)', mr: 'इगतपुरी (Igatpuri)', en: 'Igatpuri' },
        villages: [
          { id: 'ghoti', name: { hi: 'घोटी (Ghoti)', mr: 'घोटी (Ghoti)', en: 'Ghoti' }, lat: 19.7212, lon: 73.6812 },
          { id: 'bhavali', name: { hi: 'भावली (Bhavali)', mr: 'भावली (Bhavali)', en: 'Bhavali' }, lat: 19.6812, lon: 73.6112 },
        ],
      },
      {
        id: 'nashik_rural',
        name: { hi: 'नाशिक ग्रामीण (Nashik Rural)', mr: 'नाशिक ग्रामीण (Nashik Rural)', en: 'Nashik Rural' },
        villages: [
          { id: 'girnare', name: { hi: 'गिरणारे (Girnare)', mr: 'गिरणारे (Girnare)', en: 'Girnare' }, lat: 20.0212, lon: 73.6512 },
          { id: 'madhur', name: { hi: 'माडसांगवी (Madsangvi)', mr: 'माडसांगवी (Madsangvi)', en: 'Madsangvi' }, lat: 19.9812, lon: 73.8812 },
          { id: 'sayyad_pimpri', name: { hi: 'सय्यद पिंप्री (Sayyad Pimpri)', mr: 'सय्यद पिंप्री (Sayyad Pimpri)', en: 'Sayyad Pimpri' }, lat: 20.0412, lon: 73.8612 },
        ],
      },
    ],
  },

  {
    id: 'ahmednagar',
    name: { hi: 'अहमदनगर / अहिल्यानगर (Ahmednagar)', mr: 'अहिल्यानगर / अहमदनगर (Ahilyanagar)', en: 'Ahilyanagar (Ahmednagar)' },
    division: 'Nashik',
    state: 'Maharashtra',
    defaultLat: 19.0952,
    defaultLon: 74.7496,
    talukas: [
      {
        id: 'rahuri',
        name: { hi: 'राहुरी (Rahuri)', mr: 'राहुरी (Rahuri)', en: 'Rahuri' },
        villages: [
          { id: 'rahuri_factory', name: { hi: 'राहुरी फॅक्टरी (Rahuri Factory)', mr: 'राहुरी फॅक्टरी (Rahuri Factory)', en: 'Rahuri Factory' }, lat: 19.3912, lon: 74.6512 },
          { id: 'songaon', name: { hi: 'सोनगाव (Songaon)', mr: 'सोनगाव (Songaon)', en: 'Songaon' }, lat: 19.4212, lon: 74.5812 },
          { id: 'babhaleshwar', name: { hi: 'बाभळेश्वर (Babhaleshwar)', mr: 'बाभळेश्वर (Babhaleshwar)', en: 'Babhaleshwar' }, lat: 19.5112, lon: 74.5212 },
        ],
      },
      {
        id: 'sangamner',
        name: { hi: 'संगमनेर (Sangamner)', mr: 'संगमनेर (Sangamner)', en: 'Sangamner' },
        villages: [
          { id: 'sangamner_rural', name: { hi: 'संगमनेर ग्रामीण (Sangamner Rural)', mr: 'संगमनेर ग्रामीण (Sangamner Rural)', en: 'Sangamner Rural' }, lat: 19.5712, lon: 74.2112 },
          { id: 'ashwi', name: { hi: 'आश्वी (Ashwi)', mr: 'आश्वी (Ashwi)', en: 'Ashwi' }, lat: 19.6112, lon: 74.3212 },
          { id: 'sakur', name: { hi: 'साकूर (Sakur)', mr: 'साकूर (Sakur)', en: 'Sakur' }, lat: 19.4812, lon: 74.1512 },
        ],
      },
      {
        id: 'kopargaon',
        name: { hi: 'कोपरगांव (Kopargaon)', mr: 'कोपरगाव (Kopargaon)', en: 'Kopargaon' },
        villages: [
          { id: 'kopargaon_rural', name: { hi: 'कोपरगाव ग्रामीण (Kopargaon Rural)', mr: 'कोपरगाव ग्रामीण (Kopargaon Rural)', en: 'Kopargaon Rural' }, lat: 19.8912, lon: 74.4812 },
          { id: 'puntamba', name: { hi: 'पुणतांबा (Puntamba)', mr: 'पुणतांबा (Puntamba)', en: 'Puntamba' }, lat: 19.7812, lon: 74.6112 },
          { id: 'shingnapur', name: { hi: 'शिंगणापूर (Shingnapur Rural)', mr: 'शिंगणापूर (Shingnapur Rural)', en: 'Shingnapur Rural' }, lat: 19.8212, lon: 74.5412 },
        ],
      },
      {
        id: 'shrirampur',
        name: { hi: 'श्रीरामपूर (Shrirampur)', mr: 'श्रीरामपूर (Shrirampur)', en: 'Shrirampur' },
        villages: [
          { id: 'belapur', name: { hi: 'बेलापूर (Belapur)', mr: 'बेलापूर (Belapur)', en: 'Belapur' }, lat: 19.6112, lon: 74.6512 },
          { id: 'taklibhan', name: { hi: 'टाकळीभान (Taklibhan)', mr: 'टाकळीभान (Taklibhan)', en: 'Taklibhan' }, lat: 19.6812, lon: 74.7212 },
        ],
      },
      {
        id: 'newasa',
        name: { hi: 'नेवासा (Newasa)', mr: 'नेवासा (Newasa)', en: 'Newasa' },
        villages: [
          { id: 'sonai', name: { hi: 'सोनाई (Sonai)', mr: 'सोनाई (Sonai)', en: 'Sonai' }, lat: 19.5212, lon: 74.8512 },
          { id: 'kukana', name: { hi: 'कुकाणा (Kukana)', mr: 'कुकाणा (Kukana)', en: 'Kukana' }, lat: 19.4512, lon: 74.9512 },
        ],
      },
    ],
  },

  {
    id: 'jalgaon',
    name: { hi: 'जलगांव (Jalgaon)', mr: 'जळगाव (Jalgaon)', en: 'Jalgaon' },
    division: 'Nashik',
    state: 'Maharashtra',
    defaultLat: 21.0077,
    defaultLon: 75.5626,
    talukas: [
      {
        id: 'raver',
        name: { hi: 'रावेर (Raver)', mr: 'रावेर (Raver)', en: 'Raver' },
        villages: [
          { id: 'savda', name: { hi: 'सावदा (Savda)', mr: 'सावदा (Savda)', en: 'Savda' }, lat: 21.1512, lon: 75.8912 },
          { id: 'ainpur', name: { hi: 'ऐनपूर (Ainpur)', mr: 'ऐनपूर (Ainpur)', en: 'Ainpur' }, lat: 21.2112, lon: 75.9512 },
          { id: 'khiroda', name: { hi: 'खिरोदा (Khiroda)', mr: 'खिरोदा (Khiroda)', en: 'Khiroda' }, lat: 21.2412, lon: 75.8512 },
        ],
      },
      {
        id: 'chopda',
        name: { hi: 'चोपडा (Chopda)', mr: 'चोपडा (Chopda)', en: 'Chopda' },
        villages: [
          { id: 'chopda_rural', name: { hi: 'चोपडा ग्रामीण (Chopda Rural)', mr: 'चोपडा ग्रामीण (Chopda Rural)', en: 'Chopda Rural' }, lat: 21.2512, lon: 75.3012 },
          { id: 'adawad', name: { hi: 'अडावद (Adawad)', mr: 'अडावद (Adawad)', en: 'Adawad' }, lat: 21.2912, lon: 75.4512 },
          { id: 'gorgaon', name: { hi: 'गोरगाव (Gorgaon)', mr: 'गोरगाव (Gorgaon)', en: 'Gorgaon' }, lat: 21.2212, lon: 75.2212 },
        ],
      },
      {
        id: 'yawal',
        name: { hi: 'यावल (Yawal)', mr: 'यावल (Yawal)', en: 'Yawal' },
        villages: [
          { id: 'faizpur', name: { hi: 'फैजपूर (Faizpur)', mr: 'फैजपूर (Faizpur)', en: 'Faizpur' }, lat: 21.1712, lon: 75.8612 },
          { id: 'nhavi', name: { hi: 'न्हावी (Nhavi)', mr: 'न्हावी (Nhavi)', en: 'Nhavi' }, lat: 21.2212, lon: 75.7812 },
        ],
      },
      {
        id: 'pachora',
        name: { hi: 'पाचोरा (Pachora)', mr: 'पाचोरा (Pachora)', en: 'Pachora' },
        villages: [
          { id: 'pachora_rural', name: { hi: 'पाचोरा ग्रामीण (Pachora Rural)', mr: 'पाचोरा ग्रामीण (Pachora Rural)', en: 'Pachora Rural' }, lat: 20.6712, lon: 75.3512 },
          { id: 'shendurni', name: { hi: 'शेंदुर्णी (Shendurni)', mr: 'शेंदुर्णी (Shendurni)', en: 'Shendurni' }, lat: 20.6412, lon: 75.5812 },
        ],
      },
      {
        id: 'chalisgaon',
        name: { hi: 'चाळीसगांव (Chalisgaon)', mr: 'चाळीसगाव (Chalisgaon)', en: 'Chalisgaon' },
        villages: [
          { id: 'nagardeole', name: { hi: 'नगरदेवळे (Nagardeole)', mr: 'नगरदेवळे (Nagardeole)', en: 'Nagardeole' }, lat: 20.4812, lon: 75.0212 },
          { id: 'patna', name: { hi: 'पाटणादेवी (Patna Devi)', mr: 'पाटणादेवी (Patna Devi)', en: 'Patna Devi' }, lat: 20.4112, lon: 75.0512 },
        ],
      },
    ],
  },

  {
    id: 'dhule',
    name: { hi: 'धुले (Dhule)', mr: 'धुळे (Dhule)', en: 'Dhule' },
    division: 'Nashik',
    state: 'Maharashtra',
    defaultLat: 20.9042,
    defaultLon: 74.7749,
    talukas: [
      {
        id: 'shirpur',
        name: { hi: 'शिरपूर (Shirpur)', mr: 'शिरपूर (Shirpur)', en: 'Shirpur' },
        villages: [
          { id: 'thalner', name: { hi: 'थाळनेर (Thalner)', mr: 'थाळनेर (Thalner)', en: 'Thalner' }, lat: 21.2512, lon: 74.9812 },
          { id: 'rohini', name: { hi: 'रोहिणी (Rohini)', mr: 'रोहिणी (Rohini)', en: 'Rohini' }, lat: 21.3212, lon: 74.9112 },
          { id: 'babhulde', name: { hi: 'बाभूळदे (Babhulde)', mr: 'बाभूळदे (Babhulde)', en: 'Babhulde' }, lat: 21.3512, lon: 74.8812 },
        ],
      },
      {
        id: 'sindkheda',
        name: { hi: 'शिंदखेडा / दोंडाईचा (Sindkheda / Dondaicha)', mr: 'शिंदखेडा / दोंडाईचा (Sindkheda / Dondaicha)', en: 'Sindkheda / Dondaicha' },
        villages: [
          { id: 'dondaicha', name: { hi: 'दोंडाईचा (Dondaicha)', mr: 'दोंडाईचा (Dondaicha)', en: 'Dondaicha' }, lat: 21.3312, lon: 74.5712 },
          { id: 'betawad', name: { hi: 'बेटावद (Betawad)', mr: 'बेटावद (Betawad)', en: 'Betawad' }, lat: 21.2212, lon: 74.7512 },
          { id: 'chimthane', name: { hi: 'चिमठाणे (Chimthane)', mr: 'चिमठाणे (Chimthane)', en: 'Chimthane' }, lat: 21.1812, lon: 74.6512 },
        ],
      },
      {
        id: 'dhule_rural',
        name: { hi: 'धुळे ग्रामीण (Dhule Rural)', mr: 'धुळे ग्रामीण (Dhule Rural)', en: 'Dhule Rural' },
        villages: [
          { id: 'songir', name: { hi: 'सोनगीर (Songir)', mr: 'सोनगीर (Songir)', en: 'Songir' }, lat: 21.0812, lon: 74.8112 },
          { id: 'kusumba', name: { hi: 'कुसुंबा (Kusumba)', mr: 'कुसुंबा (Kusumba)', en: 'Kusumba' }, lat: 20.9512, lon: 74.6512 },
        ],
      },
      {
        id: 'sakri',
        name: { hi: 'साक्री (Sakri)', mr: 'साक्री (Sakri)', en: 'Sakri' },
        villages: [
          { id: 'nizampur', name: { hi: 'निजामपूर (Nizampur)', mr: 'निजामपूर (Nizampur)', en: 'Nizampur' }, lat: 21.0512, lon: 74.4512 },
          { id: 'dusane', name: { hi: 'दुसाणे (Dusane)', mr: 'दुसाणे (Dusane)', en: 'Dusane' }, lat: 20.9112, lon: 74.3212 },
        ],
      },
    ],
  },

  {
    id: 'nandurbar',
    name: { hi: 'नंदुरबार (Nandurbar)', mr: 'नंदुरबार (Nandurbar)', en: 'Nandurbar' },
    division: 'Nashik',
    state: 'Maharashtra',
    defaultLat: 21.3683,
    defaultLon: 74.2393,
    talukas: [
      {
        id: 'shahada',
        name: { hi: 'शहादा (Shahada - पपई हब)', mr: 'शहादा (Shahada - पपई हब)', en: 'Shahada' },
        villages: [
          { id: 'prakasha', name: { hi: 'प्रकाशा (Prakasha)', mr: 'प्रकाशा (Prakasha)', en: 'Prakasha' }, lat: 21.5212, lon: 74.3512 },
          { id: 'sarangkheda', name: { hi: 'सारंगखेडा (Sarangkheda)', mr: 'सारंगखेडा (Sarangkheda)', en: 'Sarangkheda' }, lat: 21.4812, lon: 74.5212 },
          { id: 'kheddigar', name: { hi: 'खेडदिगर (Kheddigar)', mr: 'खेडदिगर (Kheddigar)', en: 'Kheddigar' }, lat: 21.5812, lon: 74.4812 },
        ],
      },
      {
        id: 'taloda',
        name: { hi: 'तळोदा (Taloda)', mr: 'तळोदा (Taloda)', en: 'Taloda' },
        villages: [
          { id: 'borad', name: { hi: 'बोराड (Borad)', mr: 'बोराड (Borad)', en: 'Borad' }, lat: 21.5612, lon: 74.1512 },
          { id: 'taloda_rural', name: { hi: 'तळोदा ग्रामीण (Taloda Rural)', mr: 'तळोदा ग्रामीण (Taloda Rural)', en: 'Taloda Rural' }, lat: 21.5112, lon: 74.2112 },
        ],
      },
      {
        id: 'navapur',
        name: { hi: 'नवापूर (Navapur)', mr: 'नवापूर (Navapur)', en: 'Navapur' },
        villages: [
          { id: 'visarwadi', name: { hi: 'विसरवाडी (Visarwadi)', mr: 'विसरवाडी (Visarwadi)', en: 'Visarwadi' }, lat: 21.2812, lon: 74.0212 },
          { id: 'khapar', name: { hi: 'खापर (Khapar)', mr: 'खापर (Khapar)', en: 'Khapar' }, lat: 21.6512, lon: 74.0512 },
        ],
      },
    ],
  },

  // ================= PUNE & PASCHIM MAHARASHTRA =================
  {
    id: 'pune',
    name: { hi: 'पुणे (Pune)', mr: 'पुणे (Pune)', en: 'Pune' },
    division: 'Pune',
    state: 'Maharashtra',
    defaultLat: 18.5204,
    defaultLon: 73.8567,
    talukas: [
      {
        id: 'junnar',
        name: { hi: 'जुन्नर / नारायणगाव (Junnar / Narayangaon)', mr: 'जुन्नर / नारायणगाव (Junnar / Narayangaon)', en: 'Junnar / Narayangaon' },
        villages: [
          { id: 'narayangaon', name: { hi: 'नारायणगाव (Narayangaon - टोमॅटो हब)', mr: 'नारायणगाव (Narayangaon - टोमॅटो हब)', en: 'Narayangaon' }, lat: 19.1245, lon: 73.9782 },
          { id: 'alephata', name: { hi: 'आळेफाटा (Alephata)', mr: 'आळेफाटा (Alephata)', en: 'Alephata' }, lat: 19.1812, lon: 74.1112 },
          { id: 'otur', name: { hi: 'ओतूर (Otur)', mr: 'ओतूर (Otur)', en: 'Otur' }, lat: 19.2512, lon: 73.9112 },
          { id: 'junnar_rural', name: { hi: 'जुन्नर ग्रामीण (Junnar Rural)', mr: 'जुन्नर ग्रामीण (Junnar Rural)', en: 'Junnar Rural' }, lat: 19.2012, lon: 73.8712 },
        ],
      },
      {
        id: 'ambegaon',
        name: { hi: 'आंबेगाव / मंचर (Ambegaon / Manchar)', mr: 'आंबेगाव / मंचर (Ambegaon / Manchar)', en: 'Ambegaon / Manchar' },
        villages: [
          { id: 'manchar', name: { hi: 'मंचर (Manchar)', mr: 'मंचर (Manchar)', en: 'Manchar' }, lat: 19.0112, lon: 73.9412 },
          { id: 'ghodegaon', name: { hi: 'घोडेगाव (Ghodegaon)', mr: 'घोडेगाव (Ghodegaon)', en: 'Ghodegaon' }, lat: 19.0412, lon: 73.7812 },
          { id: 'avsari', name: { hi: 'अवसरी (Avsari)', mr: 'अवसरी (Avsari)', en: 'Avsari' }, lat: 18.9812, lon: 74.0212 },
        ],
      },
      {
        id: 'baramati',
        name: { hi: 'बारामती (Baramati)', mr: 'बारामती (Baramati)', en: 'Baramati' },
        villages: [
          { id: 'baramati_rural', name: { hi: 'बारामती ग्रामीण (Baramati Rural)', mr: 'बारामती ग्रामीण (Baramati Rural)', en: 'Baramati Rural' }, lat: 18.1512, lon: 74.5812 },
          { id: 'malegaon_bk', name: { hi: 'माळेगाव बुद्रुक (Malegaon BK)', mr: 'माळेगाव बुद्रुक (Malegaon BK)', en: 'Malegaon BK' }, lat: 18.1812, lon: 74.5112 },
          { id: 'supa', name: { hi: 'सुपा (Supa)', mr: 'सुपा (Supa)', en: 'Supa' }, lat: 18.2512, lon: 74.3512 },
        ],
      },
      {
        id: 'shirur',
        name: { hi: 'शिरूर (Shirur)', mr: 'शिरूर (Shirur)', en: 'Shirur' },
        villages: [
          { id: 'shikrapur', name: { hi: 'शिक्रापूर (Shikrapur)', mr: 'शिक्रापूर (Shikrapur)', en: 'Shikrapur' }, lat: 18.7812, lon: 74.1212 },
          { id: 'shirur_city', name: { hi: 'शिरूर ग्रामीण (Shirur Rural)', mr: 'शिरूर ग्रामीण (Shirur Rural)', en: 'Shirur Rural' }, lat: 18.8212, lon: 74.3712 },
          { id: 'sanaswadi', name: { hi: 'सनसवाडी (Sanaswadi)', mr: 'सनसवाडी (Sanaswadi)', en: 'Sanaswadi' }, lat: 18.7212, lon: 74.0812 },
        ],
      },
      {
        id: 'khed',
        name: { hi: 'खेड / चाकण (Khed / Chakan)', mr: 'खेड / चाकण (Khed / Chakan)', en: 'Khed / Chakan' },
        villages: [
          { id: 'chakan', name: { hi: 'चाकण (Chakan)', mr: 'चाकण (Chakan)', en: 'Chakan' }, lat: 18.7512, lon: 73.8512 },
          { id: 'rajgurunagar', name: { hi: 'राजगुरुनगर (Rajgurunagar)', mr: 'राजगुरुनगर (Rajgurunagar)', en: 'Rajgurunagar' }, lat: 18.8612, lon: 73.8812 },
          { id: 'khed_rural', name: { hi: 'खेड गाव (Khed Village)', mr: 'खेड गाव (Khed Village)', en: 'Khed Village' }, lat: 18.8912, lon: 73.8112 },
        ],
      },
      {
        id: 'indapur',
        name: { hi: 'इंदापूर (Indapur)', mr: 'इंदापूर (Indapur)', en: 'Indapur' },
        villages: [
          { id: 'walchandnagar', name: { hi: 'वालचंद Conf (Walchandnagar)', mr: 'वालचंद नगर (Walchandnagar)', en: 'Walchandnagar' }, lat: 18.1112, lon: 74.8212 },
          { id: 'bawada', name: { hi: 'बावडा (Bawada)', mr: 'बावडा (Bawada)', en: 'Bawada' }, lat: 18.0512, lon: 74.9212 },
        ],
      },
    ],
  },

  {
    id: 'solapur',
    name: { hi: 'सोलापुर (Solapur)', mr: 'सोलापूर (Solapur)', en: 'Solapur' },
    division: 'Pune',
    state: 'Maharashtra',
    defaultLat: 17.6599,
    defaultLon: 75.9064,
    talukas: [
      {
        id: 'pandharpur',
        name: { hi: 'पंढरपूर (Pandharpur)', mr: 'पंढरपूर (Pandharpur)', en: 'Pandharpur' },
        villages: [
          { id: 'karkamb', name: { hi: 'करकंब (Karkamb - द्राक्षे/डाळिंब)', mr: 'करकंब (Karkamb - द्राक्षे/डाळिंब)', en: 'Karkamb' }, lat: 17.8212, lon: 75.3812 },
          { id: 'wakhari', name: { hi: 'वाखरी (Wakhari)', mr: 'वाखरी (Wakhari)', en: 'Wakhari' }, lat: 17.7112, lon: 75.2812 },
          { id: 'bhatambre', name: { hi: 'भातांबरे (Bhatambre)', mr: 'भातांबरे (Bhatambre)', en: 'Bhatambre' }, lat: 17.7512, lon: 75.4212 },
        ],
      },
      {
        id: 'sangola',
        name: { hi: 'सांगोला (Sangola - डाळिंब हब)', mr: 'सांगोला (Sangola - डाळिंब हब)', en: 'Sangola' },
        villages: [
          { id: 'sangola_rural', name: { hi: 'सांगोला ग्रामीण (Sangola Rural)', mr: 'सांगोला ग्रामीण (Sangola Rural)', en: 'Sangola Rural' }, lat: 17.4312, lon: 75.1912 },
          { id: 'methwade', name: { hi: 'मेथवडे (Methwade)', mr: 'मेथवडे (Methwade)', en: 'Methwade' }, lat: 17.4812, lon: 75.1112 },
          { id: 'nazar', name: { hi: 'नाझरे (Nazare)', mr: 'नाझरे (Nazare)', en: 'Nazare' }, lat: 17.3912, lon: 75.2512 },
        ],
      },
      {
        id: 'barshi',
        name: { hi: 'बार्शी (Barshi)', mr: 'बार्शी (Barshi)', en: 'Barshi' },
        villages: [
          { id: 'vairag', name: { hi: 'वैराग (Vairag)', mr: 'वैराग (Vairag)', en: 'Vairag' }, lat: 18.0512, lon: 75.8512 },
          { id: 'pangaon', name: { hi: 'पानगाव (Pangaon)', mr: 'पानगाव (Pangaon)', en: 'Pangaon' }, lat: 18.1512, lon: 75.7212 },
        ],
      },
      {
        id: 'malshiras',
        name: { hi: 'माळशिरस / अकलूज (Malshiras / Akluj)', mr: 'माळशिरस / अकलूज (Malshiras / Akluj)', en: 'Malshiras / Akluj' },
        villages: [
          { id: 'akluj', name: { hi: 'अकलूज (Akluj)', mr: 'अकलूज (Akluj)', en: 'Akluj' }, lat: 17.8912, lon: 75.0212 },
          { id: 'natepute', name: { hi: 'नातेपुते (Natepute)', mr: 'नातेपुते (Natepute)', en: 'Natepute' }, lat: 17.9212, lon: 74.8812 },
          { id: 'velapur', name: { hi: 'वेळापूर (Velapur)', mr: 'वेळापूर (Velapur)', en: 'Velapur' }, lat: 17.7812, lon: 75.0812 },
        ],
      },
      {
        id: 'karmala',
        name: { hi: 'करमाळा (Karmala)', mr: 'करमाळा (Karmala)', en: 'Karmala' },
        villages: [
          { id: 'jeur', name: { hi: 'जेऊर (Jeur)', mr: 'जेऊर (Jeur)', en: 'Jeur' }, lat: 18.2512, lon: 75.1812 },
          { id: 'karmala_rural', name: { hi: 'करमाळा ग्रामीण (Karmala Rural)', mr: 'करमाळा ग्रामीण (Karmala Rural)', en: 'Karmala Rural' }, lat: 18.4112, lon: 75.2012 },
        ],
      },
    ],
  },

  {
    id: 'kolhapur',
    name: { hi: 'कोल्हापुर (Kolhapur)', mr: 'कोल्हापूर (Kolhapur)', en: 'Kolhapur' },
    division: 'Pune',
    state: 'Maharashtra',
    defaultLat: 16.7050,
    defaultLon: 74.2433,
    talukas: [
      {
        id: 'shirol',
        name: { hi: 'शिरोळ / जयसिंगपूर (Shirol / Jaysingpur)', mr: 'शिरोळ / जयसिंगपूर (Shirol / Jaysingpur)', en: 'Shirol / Jaysingpur' },
        villages: [
          { id: 'jaysingpur', name: { hi: 'जयसिंगपूर (Jaysingpur)', mr: 'जयसिंगपूर (Jaysingpur)', en: 'Jaysingpur' }, lat: 16.7912, lon: 74.5512 },
          { id: 'kurundwad', name: { hi: 'कुरुंदवाड (Kurundwad)', mr: 'कुरुंदवाड (Kurundwad)', en: 'Kurundwad' }, lat: 16.6812, lon: 74.6112 },
        ],
      },
      {
        id: 'hatkanangale',
        name: { hi: 'हातकणंगले (Hatkanangale)', mr: 'हातकणंगले (Hatkanangale)', en: 'Hatkanangale' },
        villages: [
          { id: 'hupari', name: { hi: 'हुपरी (Hupari)', mr: 'हुपरी (Hupari)', en: 'Hupari' }, lat: 16.6112, lon: 74.4012 },
          { id: 'vadgaon', name: { hi: 'वडगाव (Peth Vadgaon)', mr: 'पेठ वडगाव (Peth Vadgaon)', en: 'Peth Vadgaon' }, lat: 16.8212, lon: 74.3112 },
        ],
      },
      {
        id: 'karveer',
        name: { hi: 'करवीर (Karveer)', mr: 'करवीर (Karveer)', en: 'Karveer' },
        villages: [
          { id: 'uchgaon', name: { hi: 'उचगाव (Uchgaon)', mr: 'उचगाव (Uchgaon)', en: 'Uchgaon' }, lat: 16.6812, lon: 74.2812 },
          { id: 'gandhinagar', name: { hi: 'गांधीनगर (Gandhinagar)', mr: 'गांधीनगर (Gandhinagar)', en: 'Gandhinagar' }, lat: 16.6912, lon: 74.2912 },
        ],
      },
      {
        id: 'kagal',
        name: { hi: 'कागल (Kagal)', mr: 'कागल (Kagal)', en: 'Kagal' },
        villages: [
          { id: 'murgud', name: { hi: 'मुरगूड (Murgud)', mr: 'मुरगूड (Murgud)', en: 'Murgud' }, lat: 16.4212, lon: 74.2112 },
          { id: 'bidri', name: { hi: 'बिद्री (Bidri)', mr: 'बिद्री (Bidri)', en: 'Bidri' }, lat: 16.4812, lon: 74.1512 },
        ],
      },
    ],
  },

  {
    id: 'sangli',
    name: { hi: 'सांगली (Sangli)', mr: 'सांगली (Sangli)', en: 'Sangli' },
    division: 'Pune',
    state: 'Maharashtra',
    defaultLat: 16.8524,
    defaultLon: 74.5815,
    talukas: [
      {
        id: 'tasgaon',
        name: { hi: 'तासगाव (Tasgaon - बेदाणा/द्राक्षे हब)', mr: 'तासगाव (Tasgaon - बेदाणा/द्राक्षे हब)', en: 'Tasgaon' },
        villages: [
          { id: 'savlaj', name: { hi: 'सावळज (Savlaj)', mr: 'सावळज (Savlaj)', en: 'Savlaj' }, lat: 17.0212, lon: 74.8812 },
          { id: 'manerajuri', name: { hi: 'मणेराजुरी (Manerajuri)', mr: 'मणेराजुरी (Manerajuri)', en: 'Manerajuri' }, lat: 16.9812, lon: 74.7812 },
        ],
      },
      {
        id: 'walwa',
        name: { hi: 'वाळवा / इस्लामपूर (Walwa / Islampur)', mr: 'वाळवा / इस्लामपूर (Walwa / Islampur)', en: 'Walwa / Islampur' },
        villages: [
          { id: 'ashta', name: { hi: 'आष्टा (Ashta)', mr: 'आष्टा (Ashta)', en: 'Ashta' }, lat: 16.9512, lon: 74.4112 },
          { id: 'kirloskarwadi', name: { hi: 'किर्लोस्करवाडी (Kirloskarwadi)', mr: 'किर्लोस्करवाडी (Kirloskarwadi)', en: 'Kirloskarwadi' }, lat: 17.0812, lon: 74.4212 },
        ],
      },
      {
        id: 'miraj',
        name: { hi: 'मिरज (Miraj)', mr: 'मिरज (Miraj)', en: 'Miraj' },
        villages: [
          { id: 'arag', name: { hi: 'आरग (Arag)', mr: 'आरग (Arag)', en: 'Arag' }, lat: 16.8212, lon: 74.7512 },
          { id: 'kasabe_digraj', name: { hi: 'कसबे डिग्रज (Kasabe Digraj)', mr: 'कसबे डिग्रज (Kasabe Digraj)', en: 'Kasabe Digraj' }, lat: 16.8812, lon: 74.5212 },
        ],
      },
    ],
  },

  {
    id: 'satara',
    name: { hi: 'सातारा (Satara)', mr: 'सातारा (Satara)', en: 'Satara' },
    division: 'Pune',
    state: 'Maharashtra',
    defaultLat: 17.6805,
    defaultLon: 73.9997,
    talukas: [
      {
        id: 'karad',
        name: { hi: 'कराड (Karad)', mr: 'कराड (Karad)', en: 'Karad' },
        villages: [
          { id: 'masur', name: { hi: 'मसूर (Masur)', mr: 'मसूर (Masur)', en: 'Masur' }, lat: 17.3812, lon: 74.2212 },
          { id: 'shenoli', name: { hi: 'शेणोली (Shenoli)', mr: 'शेणोली (Shenoli)', en: 'Shenoli' }, lat: 17.2512, lon: 74.2512 },
        ],
      },
      {
        id: 'koregaon',
        name: { hi: 'कोरेगाव (Koregaon - आले/अदरक हब)', mr: 'कोरेगाव (Koregaon - आले/अदरक हब)', en: 'Koregaon' },
        villages: [
          { id: 'koregaon_rural', name: { hi: 'कोरेगाव ग्रामीण (Koregaon Rural)', mr: 'कोरेगाव ग्रामीण (Koregaon Rural)', en: 'Koregaon Rural' }, lat: 17.7112, lon: 74.1812 },
          { id: 'rahimatpur', name: { hi: 'रहिमतपूर (Rahimatpur)', mr: 'रहिमतपूर (Rahimatpur)', en: 'Rahimatpur' }, lat: 17.5812, lon: 74.2112 },
        ],
      },
      {
        id: 'phaltan',
        name: { hi: 'फलटण (Phaltan)', mr: 'फलटण (Phaltan)', en: 'Phaltan' },
        villages: [
          { id: 'lonand', name: { hi: 'लोणंद (Lonand - कांदा उपबाजार)', mr: 'लोणंद (Lonand - कांदा उपबाजार)', en: 'Lonand' }, lat: 18.0512, lon: 74.1912 },
          { id: 'taradgaon', name: { hi: 'तरडगाव (Taradgaon)', mr: 'तरडगाव (Taradgaon)', en: 'Taradgaon' }, lat: 18.0112, lon: 74.2812 },
        ],
      },
      {
        id: 'wai',
        name: { hi: 'वाई (Wai)', mr: 'वाई (Wai)', en: 'Wai' },
        villages: [
          { id: 'bhuinj', name: { hi: 'भुईंज (Bhuinj)', mr: 'भुईंज (Bhuinj)', en: 'Bhuinj' }, lat: 17.9512, lon: 73.9812 },
          { id: 'shirwal', name: { hi: 'शिरवळ (Shirwal)', mr: 'शिरवळ (Shirwal)', en: 'Shirwal' }, lat: 18.1212, lon: 74.0112 },
        ],
      },
    ],
  },

  // ================= MARATHWADA DIVISION =================
  {
    id: 'chhatrapati_sambhajinagar',
    name: { hi: 'छत्रपति संभाजीनगर (Aurangabad)', mr: 'छ. संभाजीनगर / औरंगाबाद (Sambhajinagar)', en: 'Chh. Sambhajinagar' },
    division: 'Marathwada',
    state: 'Maharashtra',
    defaultLat: 19.8762,
    defaultLon: 75.3433,
    talukas: [
      {
        id: 'gangapur',
        name: { hi: 'गंगापूर (Gangapur)', mr: 'गंगापूर (Gangapur)', en: 'Gangapur' },
        villages: [
          { id: 'lasur_station', name: { hi: 'लासूर स्टेशन (Lasur Station)', mr: 'लासूर स्टेशन (Lasur Station)', en: 'Lasur Station' }, lat: 19.9812, lon: 75.0512 },
          { id: 'waluj_rural', name: { hi: 'वाळूज ग्रामीण (Waluj Rural)', mr: 'वाळूज ग्रामीण (Waluj Rural)', en: 'Waluj Rural' }, lat: 19.8212, lon: 75.2212 },
        ],
      },
      {
        id: 'vaijapur',
        name: { hi: 'वैजापूर (Vaijapur)', mr: 'वैजापूर (Vaijapur)', en: 'Vaijapur' },
        villages: [
          { id: 'shiur', name: { hi: 'शिऊर (Shiur)', mr: 'शिऊर (Shiur)', en: 'Shiur' }, lat: 20.0812, lon: 74.8812 },
          { id: 'rotegaon', name: { hi: 'रोटेगाव (Rotegaon)', mr: 'रोटेगाव (Rotegaon)', en: 'Rotegaon' }, lat: 19.9212, lon: 74.7512 },
        ],
      },
      {
        id: 'paithan',
        name: { hi: 'पैठण (Paithan)', mr: 'पैठण (Paithan)', en: 'Paithan' },
        villages: [
          { id: 'bidkin', name: { hi: 'बिडकीन (Bidkin)', mr: 'बिडकीन (Bidkin)', en: 'Bidkin' }, lat: 19.6812, lon: 75.3512 },
          { id: 'pachod', name: { hi: 'पाचोड (Pachod)', mr: 'पाचोड (Pachod)', en: 'Pachod' }, lat: 19.5512, lon: 75.5212 },
        ],
      },
      {
        id: 'sillod',
        name: { hi: 'सिल्लोड (Sillod)', mr: 'सिल्लोड (Sillod)', en: 'Sillod' },
        villages: [
          { id: 'ajanta', name: { hi: 'अजिंठा (Ajanta)', mr: 'अजिंठा (Ajanta)', en: 'Ajanta' }, lat: 20.5512, lon: 75.7212 },
          { id: 'golegaon', name: { hi: 'गोळेगाव (Golegaon)', mr: 'गोळेगाव (Golegaon)', en: 'Golegaon' }, lat: 20.2512, lon: 75.6812 },
        ],
      },
    ],
  },

  {
    id: 'jalna',
    name: { hi: 'जालना (Jalna)', mr: 'जालना (Jalna)', en: 'Jalna' },
    division: 'Marathwada',
    state: 'Maharashtra',
    defaultLat: 19.8410,
    defaultLon: 75.8864,
    talukas: [
      {
        id: 'ambad',
        name: { hi: 'अंबड (Ambad)', mr: 'अंबड (Ambad)', en: 'Ambad' },
        villages: [
          { id: 'wadigodri', name: { hi: 'वाडीगोद्री (Wadigodri)', mr: 'वाडीगोद्री (Wadigodri)', en: 'Wadigodri' }, lat: 19.5812, lon: 75.7812 },
          { id: 'shahgad', name: { hi: 'शहागड (Shahgad)', mr: 'शहागड (Shahgad)', en: 'Shahgad' }, lat: 19.4912, lon: 75.8212 },
        ],
      },
      {
        id: 'partur',
        name: { hi: 'परतूर (Partur)', mr: 'परतूर (Partur)', en: 'Partur' },
        villages: [
          { id: 'ashti', name: { hi: 'आष्टी (Ashti)', mr: 'आष्टी (Ashti)', en: 'Ashti' }, lat: 19.6212, lon: 76.1512 },
          { id: 'rani_unchegaon', name: { hi: 'राणी उंचेगाव (Rani Unchegaon)', mr: 'राणी उंचेगाव (Rani Unchegaon)', en: 'Rani Unchegaon' }, lat: 19.5512, lon: 76.2212 },
        ],
      },
      {
        id: 'bhokardan',
        name: { hi: 'भोकरदन (Bhokardan)', mr: 'भोकरदन (Bhokardan)', en: 'Bhokardan' },
        villages: [
          { id: 'hasnabad', name: { hi: 'हसनाबाद (Hasnabad)', mr: 'हसनाबाद (Hasnabad)', en: 'Hasnabad' }, lat: 20.0812, lon: 75.9812 },
          { id: 'anwa', name: { hi: 'अनवा (Anwa)', mr: 'अनवा (Anwa)', en: 'Anwa' }, lat: 20.2112, lon: 75.8512 },
        ],
      },
    ],
  },

  {
    id: 'latur',
    name: { hi: 'लातुर (Latur - सोयाबीन/डाळ हब)', mr: 'लातूर (Latur - सोयाबीन/डाळ हब)', en: 'Latur' },
    division: 'Marathwada',
    state: 'Maharashtra',
    defaultLat: 18.4088,
    defaultLon: 76.5604,
    talukas: [
      {
        id: 'latur_rural',
        name: { hi: 'लातूर ग्रामीण (Latur Rural)', mr: 'लातूर ग्रामीण (Latur Rural)', en: 'Latur Rural' },
        villages: [
          { id: 'murud', name: { hi: 'मुरुड (Murud)', mr: 'मुरुड (Murud)', en: 'Murud' }, lat: 18.4212, lon: 76.4212 },
          { id: 'harangul', name: { hi: 'हरंगुळ (Harangul)', mr: 'हरंगुळ (Harangul)', en: 'Harangul' }, lat: 18.3912, lon: 76.4912 },
        ],
      },
      {
        id: 'ausa',
        name: { hi: 'औसा (Ausa)', mr: 'औसा (Ausa)', en: 'Ausa' },
        villages: [
          { id: 'lamjana', name: { hi: 'लामजना (Lamjana)', mr: 'लामजना (Lamjana)', en: 'Lamjana' }, lat: 18.1812, lon: 76.6212 },
          { id: 'killari', name: { hi: 'किल्लारी (Killari)', mr: 'किल्लारी (Killari)', en: 'Killari' }, lat: 18.0512, lon: 76.5812 },
        ],
      },
      {
        id: 'nilanga',
        name: { hi: 'निलंगा (Nilanga)', mr: 'निलंगा (Nilanga)', en: 'Nilanga' },
        villages: [
          { id: 'aurad_shahajani', name: { hi: 'औरद शहाजानी (Aurad Shahajani)', mr: 'औरद शहाजानी (Aurad Shahajani)', en: 'Aurad Shahajani' }, lat: 18.0212, lon: 76.8812 },
          { id: 'kasar_sirsi', name: { hi: 'कासार सिरसी (Kasar Sirsi)', mr: 'कासार सिरसी (Kasar Sirsi)', en: 'Kasar Sirsi' }, lat: 18.1212, lon: 76.7512 },
        ],
      },
      {
        id: 'udgir',
        name: { hi: 'उदगीर (Udgir)', mr: 'उदगीर (Udgir)', en: 'Udgir' },
        villages: [
          { id: 'nalegaon', name: { hi: 'नाळेगाव (Nalegaon)', mr: 'नाळेगाव (Nalegaon)', en: 'Nalegaon' }, lat: 18.4812, lon: 76.8812 },
          { id: 'deoni_v', name: { hi: 'देवणी गाव (Deoni)', mr: 'देवणी गाव (Deoni)', en: 'Deoni' }, lat: 18.3212, lon: 77.0212 },
        ],
      },
    ],
  },

  {
    id: 'dharashiv',
    name: { hi: 'धाराशिव / उस्मानाबाद (Dharashiv)', mr: 'धाराशिव / उस्मानाबाद (Dharashiv)', en: 'Dharashiv (Osmanabad)' },
    division: 'Marathwada',
    state: 'Maharashtra',
    defaultLat: 18.1856,
    defaultLon: 76.0423,
    talukas: [
      {
        id: 'tuljapur',
        name: { hi: 'तुळजापूर (Tuljapur)', mr: 'तुळजापूर (Tuljapur)', en: 'Tuljapur' },
        villages: [
          { id: 'naldurg', name: { hi: 'नळदुर्ग (Naldurg)', mr: 'नळदुर्ग (Naldurg)', en: 'Naldurg' }, lat: 17.8212, lon: 76.2912 },
          { id: 'tamalwadi', name: { hi: 'तामलवाडी (Tamalwadi)', mr: 'तामलवाडी (Tamalwadi)', en: 'Tamalwadi' }, lat: 18.0212, lon: 76.0812 },
        ],
      },
      {
        id: 'umarga',
        name: { hi: 'उमरगा (Umarga)', mr: 'उमरगा (Umarga)', en: 'Umarga' },
        villages: [
          { id: 'murum', name: { hi: 'मुरुम (Murum)', mr: 'मुरुम (Murum)', en: 'Murum' }, lat: 17.8512, lon: 76.4512 },
          { id: 'dalimb', name: { hi: 'डाळिंब (Dalimb)', mr: 'डाळिंब (Dalimb)', en: 'Dalimb' }, lat: 17.9212, lon: 76.5112 },
        ],
      },
      {
        id: 'kalamb',
        name: { hi: 'कळंब (Kalamb)', mr: 'कळंब (Kalamb)', en: 'Kalamb' },
        villages: [
          { id: 'shiradhon', name: { hi: 'शिराढोण (Shiradhon)', mr: 'शिराढोण (Shiradhon)', en: 'Shiradhon' }, lat: 18.3512, lon: 76.0112 },
          { id: 'it', name: { hi: 'ईट (It)', mr: 'ईट (It)', en: 'It' }, lat: 18.4212, lon: 75.9212 },
        ],
      },
    ],
  },

  {
    id: 'beed',
    name: { hi: 'बीड (Beed)', mr: 'बीड (Beed)', en: 'Beed' },
    division: 'Marathwada',
    state: 'Maharashtra',
    defaultLat: 18.9891,
    defaultLon: 75.7601,
    talukas: [
      {
        id: 'georai',
        name: { hi: 'गेवराई (Georai)', mr: 'गेवराई (Georai)', en: 'Georai' },
        villages: [
          { id: 'umapur', name: { hi: 'उमापूर (Umapur)', mr: 'उमापूर (Umapur)', en: 'Umapur' }, lat: 19.3212, lon: 75.6812 },
          { id: 'madalmohi', name: { hi: 'मादळमोही (Madalmohi)', mr: 'मादळमोही (Madalmohi)', en: 'Madalmohi' }, lat: 19.1812, lon: 75.6112 },
        ],
      },
      {
        id: 'majalgaon',
        name: { hi: 'माजलगाव (Majalgaon)', mr: 'माजलगाव (Majalgaon)', en: 'Majalgaon' },
        villages: [
          { id: 'talkhed', name: { hi: 'टाळखेड (Talkhed)', mr: 'टाळखेड (Talkhed)', en: 'Talkhed' }, lat: 19.1512, lon: 76.1812 },
          { id: 'gangamasla', name: { hi: 'गंगामासला (Gangamasla)', mr: 'गंगामासला (Gangamasla)', en: 'Gangamasla' }, lat: 19.2212, lon: 76.1112 },
        ],
      },
      {
        id: 'parli',
        name: { hi: 'परळी वैजनाथ (Parli Vaijnath)', mr: 'परळी वैजनाथ (Parli Vaijnath)', en: 'Parli Vaijnath' },
        villages: [
          { id: 'ghatnandur', name: { hi: 'घाटनांदूर (Ghatnandur)', mr: 'घाटनांदूर (Ghatnandur)', en: 'Ghatnandur' }, lat: 18.9512, lon: 76.4512 },
          { id: 'dharmapuri', name: { hi: 'धर्मापुरी (Dharmapuri)', mr: 'धर्मापुरी (Dharmapuri)', en: 'Dharmapuri' }, lat: 18.8812, lon: 76.5112 },
        ],
      },
    ],
  },

  {
    id: 'nanded',
    name: { hi: 'नांदेड (Nanded)', mr: 'नांदेड (Nanded)', en: 'Nanded' },
    division: 'Marathwada',
    state: 'Maharashtra',
    defaultLat: 19.1383,
    defaultLon: 77.3210,
    talukas: [
      {
        id: 'loha',
        name: { hi: 'लोहा (Loha)', mr: 'लोहा (Loha)', en: 'Loha' },
        villages: [
          { id: 'malakoli', name: { hi: 'मलकापूर / मलकोळी (Malakoli)', mr: 'मलकोळी (Malakoli)', en: 'Malakoli' }, lat: 18.9812, lon: 77.1512 },
          { id: 'sonkhed', name: { hi: 'सोनखेड (Sonkhed)', mr: 'सोनखेड (Sonkhed)', en: 'Sonkhed' }, lat: 19.0512, lon: 77.2112 },
        ],
      },
      {
        id: 'degloor',
        name: { hi: 'देगलूर (Degloor)', mr: 'देगलूर (Degloor)', en: 'Degloor' },
        villages: [
          { id: 'kundalwadi', name: { hi: 'कुंडलवाडी (Kundalwadi)', mr: 'कुंडलवाडी (Kundalwadi)', en: 'Kundalwadi' }, lat: 18.6212, lon: 77.6512 },
          { id: 'shahapur_d', name: { hi: 'शहापूर (Shahapur)', mr: 'शहापूर (Shahapur)', en: 'Shahapur' }, lat: 18.5512, lon: 77.5812 },
        ],
      },
      {
        id: 'kinwat',
        name: { hi: 'किनवट (Kinwat)', mr: 'किनवट (Kinwat)', en: 'Kinwat' },
        villages: [
          { id: 'islapur', name: { hi: 'इस्लापूर (Islapur)', mr: 'इस्लापूर (Islapur)', en: 'Islapur' }, lat: 19.6812, lon: 78.1812 },
          { id: 'bodhadi', name: { hi: 'बोधडी (Bodhadi)', mr: 'बोधडी (Bodhadi)', en: 'Bodhadi' }, lat: 19.6112, lon: 78.0812 },
        ],
      },
    ],
  },

  {
    id: 'parbhani',
    name: { hi: 'परभणी (Parbhani)', mr: 'परभणी (Parbhani)', en: 'Parbhani' },
    division: 'Marathwada',
    state: 'Maharashtra',
    defaultLat: 19.2644,
    defaultLon: 76.7749,
    talukas: [
      {
        id: 'gangakhed',
        name: { hi: 'गंगाखेड (Gangakhed)', mr: 'गंगाखेड (Gangakhed)', en: 'Gangakhed' },
        villages: [
          { id: 'rani_sawargaon', name: { hi: 'राणी सावरगाव (Rani Sawargaon)', mr: 'राणी सावरगाव (Rani Sawargaon)', en: 'Rani Sawargaon' }, lat: 19.0212, lon: 76.7212 },
          { id: 'makhani', name: { hi: 'माखणी (Makhani)', mr: 'माखणी (Makhani)', en: 'Makhani' }, lat: 18.9812, lon: 76.6812 },
        ],
      },
      {
        id: 'jintur',
        name: { hi: 'जिंतूर (Jintur)', mr: 'जिंतूर (Jintur)', en: 'Jintur' },
        villages: [
          { id: 'bori', name: { hi: 'बोरी (Bori)', mr: 'बोरी (Bori)', en: 'Bori' }, lat: 19.5512, lon: 76.7112 },
          { id: 'charthana', name: { hi: 'चारठाणा (Charthana)', mr: 'चारठाणा (Charthana)', en: 'Charthana' }, lat: 19.6212, lon: 76.5812 },
        ],
      },
    ],
  },

  {
    id: 'hingoli',
    name: { hi: 'हिंगोली (Hingoli - हळद हब)', mr: 'हिंगोली (Hingoli - हळद हब)', en: 'Hingoli' },
    division: 'Marathwada',
    state: 'Maharashtra',
    defaultLat: 19.7214,
    defaultLon: 77.1472,
    talukas: [
      {
        id: 'basmath',
        name: { hi: 'वसमत (Basmath / Vasmat)', mr: 'वसमत (Basmath / Vasmat)', en: 'Basmath' },
        villages: [
          { id: 'kurunda', name: { hi: 'कुरुंदा (Kurunda)', mr: 'कुरुंदा (Kurunda)', en: 'Kurunda' }, lat: 19.4512, lon: 77.0812 },
          { id: 'aral', name: { hi: 'आराळ (Aral)', mr: 'आराळ (Aral)', en: 'Aral' }, lat: 19.3812, lon: 77.1212 },
        ],
      },
      {
        id: 'kalamnuri',
        name: { hi: 'कळमनुरी (Kalamnuri)', mr: 'कळमनुरी (Kalamnuri)', en: 'Kalamnuri' },
        villages: [
          { id: 'akhada_balapur', name: { hi: 'आखाडा बाळापूर (Akhada Balapur)', mr: 'आखाडा बाळापूर (Akhada Balapur)', en: 'Akhada Balapur' }, lat: 19.6112, lon: 77.2512 },
          { id: 'waranga', name: { hi: 'वारंगा (Waranga)', mr: 'वारंगा (Waranga)', en: 'Waranga' }, lat: 19.5812, lon: 77.3112 },
        ],
      },
    ],
  },

  // ================= VIDARBHA DIVISION =================
  {
    id: 'nagpur',
    name: { hi: 'नागपुर (Nagpur - संत्रा हब)', mr: 'नागपूर (Nagpur - संत्रा हब)', en: 'Nagpur' },
    division: 'Vidarbha',
    state: 'Maharashtra',
    defaultLat: 21.1458,
    defaultLon: 79.0882,
    talukas: [
      {
        id: 'katol',
        name: { hi: 'काटोल (Katol - संत्रा मंडी)', mr: 'काटोल (Katol - संत्रा मंडी)', en: 'Katol' },
        villages: [
          { id: 'kondhali', name: { hi: 'कोंढाळी (Kondhali)', mr: 'कोंढाळी (Kondhali)', en: 'Kondhali' }, lat: 21.1812, lon: 78.6812 },
          { id: 'jalalkheda', name: { hi: 'जलालखेडा (Jalalkheda)', mr: 'जलालखेडा (Jalalkheda)', en: 'Jalalkheda' }, lat: 21.3512, lon: 78.4812 },
        ],
      },
      {
        id: 'saoner',
        name: { hi: 'सावनेर (Saoner)', mr: 'सावनेर (Saoner)', en: 'Saoner' },
        villages: [
          { id: 'kelvad', name: { hi: 'केळवद (Kelvad)', mr: 'केळवद (Kelvad)', en: 'Kelvad' }, lat: 21.5212, lon: 78.9112 },
          { id: 'khapa', name: { hi: 'खापा (Khapa)', mr: 'खापा (Khapa)', en: 'Khapa' }, lat: 21.4112, lon: 79.0212 },
        ],
      },
      {
        id: 'ramtek',
        name: { hi: 'रामटेक (Ramtek)', mr: 'रामटेक (Ramtek)', en: 'Ramtek' },
        villages: [
          { id: 'mansar', name: { hi: 'मनसर (Mansar)', mr: 'मनसर (Mansar)', en: 'Mansar' }, lat: 21.4112, lon: 79.2812 },
          { id: 'kachurwahi', name: { hi: 'काचुरवाही (Kachurwahi)', mr: 'काचुरवाही (Kachurwahi)', en: 'Kachurwahi' }, lat: 21.4812, lon: 79.3512 },
        ],
      },
    ],
  },

  {
    id: 'amravati',
    name: { hi: 'अमरावती (Amravati)', mr: 'अमरावती (Amravati)', en: 'Amravati' },
    division: 'Vidarbha',
    state: 'Maharashtra',
    defaultLat: 20.9374,
    defaultLon: 77.7796,
    talukas: [
      {
        id: 'warud',
        name: { hi: 'वरुड (Warud - संत्रा बेल्ट)', mr: 'वरुड (Warud - संत्रा बेल्ट)', en: 'Warud' },
        villages: [
          { id: 'shendurjana_ghat', name: { hi: 'शेंदुरजना घाट (Shendurjana Ghat)', mr: 'शेंदुरजना घाट (Shendurjana Ghat)', en: 'Shendurjana Ghat' }, lat: 21.5812, lon: 78.1112 },
          { id: 'benoda', name: { hi: 'बेनोडा (Benoda)', mr: 'बेनोडा (Benoda)', en: 'Benoda' }, lat: 21.4512, lon: 78.0212 },
        ],
      },
      {
        id: 'achalpur',
        name: { hi: 'अचलपूर / परतवाडा (Achalpur / Paratwada)', mr: 'अचलपूर / परतवाडा (Achalpur / Paratwada)', en: 'Achalpur / Paratwada' },
        villages: [
          { id: 'sirasgaon_kasba', name: { hi: 'शिरसगाव कसबा (Sirasgaon Kasba)', mr: 'शिरसगाव कसबा (Sirasgaon Kasba)', en: 'Sirasgaon Kasba' }, lat: 21.3212, lon: 77.6212 },
          { id: 'chandur_bazar_v', name: { hi: 'चांदूर बाजार ग्रामीण (Chandur Bazar)', mr: 'चांदूर बाजार ग्रामीण (Chandur Bazar)', en: 'Chandur Bazar' }, lat: 21.2512, lon: 77.7512 },
        ],
      },
    ],
  },

  {
    id: 'akola',
    name: { hi: 'अकोला (Akola - कॉटन/सोयाबीन)', mr: 'अकोला (Akola - कापूस/सोयाबीन)', en: 'Akola' },
    division: 'Vidarbha',
    state: 'Maharashtra',
    defaultLat: 20.7002,
    defaultLon: 77.0082,
    talukas: [
      {
        id: 'akot',
        name: { hi: 'आकोट (Akot)', mr: 'आकोट (Akot)', en: 'Akot' },
        villages: [
          { id: 'hiwarkhed', name: { hi: 'हिवरखेड (Hiwarkhed)', mr: 'हिवरखेड (Hiwarkhed)', en: 'Hiwarkhed' }, lat: 21.1512, lon: 76.8812 },
          { id: 'chohatta', name: { hi: 'चोहट्टा बाजार (Chohatta Bazar)', mr: 'चोहट्टा बाजार (Chohatta Bazar)', en: 'Chohatta Bazar' }, lat: 21.0212, lon: 76.9512 },
        ],
      },
      {
        id: 'balapur',
        name: { hi: 'बाळापूर (Balapur)', mr: 'बाळापूर (Balapur)', en: 'Balapur' },
        villages: [
          { id: 'wadegaon', name: { hi: 'वाडेगाव (Wadegaon)', mr: 'वाडेगाव (Wadegaon)', en: 'Wadegaon' }, lat: 20.6112, lon: 76.8512 },
          { id: 'paras', name: { hi: 'पारस (Paras)', mr: 'पारस (Paras)', en: 'Paras' }, lat: 20.7812, lon: 76.8112 },
        ],
      },
    ],
  },

  {
    id: 'yavatmal',
    name: { hi: 'यवतमाळ (Yavatmal - कापूस जिल्हा)', mr: 'यवतमाळ (Yavatmal - कापूस जिल्हा)', en: 'Yavatmal' },
    division: 'Vidarbha',
    state: 'Maharashtra',
    defaultLat: 20.3888,
    defaultLon: 78.1204,
    talukas: [
      {
        id: 'pusad',
        name: { hi: 'पुसद (Pusad)', mr: 'पुसद (Pusad)', en: 'Pusad' },
        villages: [
          { id: 'fulsawangi', name: { hi: 'फुलसावंगी (Fulsawangi)', mr: 'फुलसावंगी (Fulsawangi)', en: 'Fulsawangi' }, lat: 19.8212, lon: 77.6212 },
          { id: 'kali_d', name: { hi: 'काळी दौलत खान (Kali Daulat Khan)', mr: 'काळी दौलत खान (Kali Daulat Khan)', en: 'Kali Daulat Khan' }, lat: 19.9812, lon: 77.5112 },
        ],
      },
      {
        id: 'wani',
        name: { hi: 'वणी (Wani)', mr: 'वणी (Wani)', en: 'Wani' },
        villages: [
          { id: 'kayar', name: { hi: 'कायर (Kayar)', mr: 'कायर (Kayar)', en: 'Kayar' }, lat: 20.0212, lon: 78.9812 },
          { id: 'shirpur_y', name: { hi: 'शिरपूर (Shirpur)', mr: 'शिरपूर (Shirpur)', en: 'Shirpur' }, lat: 20.0812, lon: 78.8812 },
        ],
      },
    ],
  },

  {
    id: 'buldhana',
    name: { hi: 'बुलढाणा (Buldhana)', mr: 'बुलढाणा (Buldhana)', en: 'Buldhana' },
    division: 'Vidarbha',
    state: 'Maharashtra',
    defaultLat: 20.5310,
    defaultLon: 76.1842,
    talukas: [
      {
        id: 'khamgaon',
        name: { hi: 'खामगांव (Khamgaon)', mr: 'खामगाव (Khamgaon)', en: 'Khamgaon' },
        villages: [
          { id: 'wadner_b', name: { hi: 'वडनेर भोलजी (Wadner Bholji)', mr: 'वडनेर भोलजी (Wadner Bholji)', en: 'Wadner Bholji' }, lat: 20.7812, lon: 76.4512 },
          { id: 'shelodi', name: { hi: 'शेलोडी (Shelodi)', mr: 'शेलोडी (Shelodi)', en: 'Shelodi' }, lat: 20.6512, lon: 76.5112 },
        ],
      },
      {
        id: 'chikhli',
        name: { hi: 'चिखली (Chikhli)', mr: 'चिखली (Chikhli)', en: 'Chikhli' },
        villages: [
          { id: 'mera_khurd', name: { hi: 'मेरा खुर्द (Mera Khurd)', mr: 'मेरा खुर्द (Mera Khurd)', en: 'Mera Khurd' }, lat: 20.4212, lon: 76.3112 },
          { id: 'amalner_b', name: { hi: 'अमडापूर (Amdapur)', mr: 'अमडापूर (Amdapur)', en: 'Amdapur' }, lat: 20.4812, lon: 76.4512 },
        ],
      },
    ],
  },

  {
    id: 'washim',
    name: { hi: 'वाशिम (Washim)', mr: 'वाशिम (Washim)', en: 'Washim' },
    division: 'Vidarbha',
    state: 'Maharashtra',
    defaultLat: 20.1118,
    defaultLon: 77.1350,
    talukas: [
      {
        id: 'risod',
        name: { hi: 'रिसोड (Risod)', mr: 'रिसोड (Risod)', en: 'Risod' },
        villages: [
          { id: 'shirpur_jain', name: { hi: 'शिरपूर जैन (Shirpur Jain)', mr: 'शिरपूर जैन (Shirpur Jain)', en: 'Shirpur Jain' }, lat: 20.0812, lon: 76.8812 },
          { id: 'karda', name: { hi: 'करडा (Karda)', mr: 'करडा (Karda)', en: 'Karda' }, lat: 20.0212, lon: 76.7812 },
        ],
      },
      {
        id: 'karanja',
        name: { hi: 'कारंजा लाड (Karanja Lad)', mr: 'कारंजा लाड (Karanja Lad)', en: 'Karanja Lad' },
        villages: [
          { id: 'kamargaon', name: { hi: 'कामरगाव (Kamargaon)', mr: 'कामरगाव (Kamargaon)', en: 'Kamargaon' }, lat: 20.5212, lon: 77.4512 },
          { id: 'pohradevi', name: { hi: 'पोहरादेवी (Pohradevi)', mr: 'पोहरादेवी (Pohradevi)', en: 'Pohradevi' }, lat: 20.2512, lon: 77.4812 },
        ],
      },
    ],
  },

  {
    id: 'wardha',
    name: { hi: 'वर्धा (Wardha)', mr: 'वर्धा (Wardha)', en: 'Wardha' },
    division: 'Vidarbha',
    state: 'Maharashtra',
    defaultLat: 20.7453,
    defaultLon: 78.6022,
    talukas: [
      {
        id: 'hinganghat',
        name: { hi: 'हिंगणघाट (Hinganghat)', mr: 'हिंगणघाट (Hinganghat)', en: 'Hinganghat' },
        villages: [
          { id: 'girad', name: { hi: 'गिरड (Girad)', mr: 'गिरड (Girad)', en: 'Girad' }, lat: 20.6512, lon: 78.9812 },
          { id: 'pohana', name: { hi: 'पोहाना (Pohana)', mr: 'पोहाना (Pohana)', en: 'Pohana' }, lat: 20.4812, lon: 78.7812 },
        ],
      },
      {
        id: 'arvi',
        name: { hi: 'आर्वी (Arvi)', mr: 'आर्वी (Arvi)', en: 'Arvi' },
        villages: [
          { id: 'rohana', name: { hi: 'रोहणा (Rohana)', mr: 'रोहणा (Rohana)', en: 'Rohana' }, lat: 20.9212, lon: 78.4512 },
        ],
      },
    ],
  },

  {
    id: 'chandrapur',
    name: { hi: 'चंद्रपूर (Chandrapur)', mr: 'चंद्रपूर (Chandrapur)', en: 'Chandrapur' },
    division: 'Vidarbha',
    state: 'Maharashtra',
    defaultLat: 19.9615,
    defaultLon: 79.2961,
    talukas: [
      {
        id: 'warora',
        name: { hi: 'वरोरा (Warora)', mr: 'वरोरा (Warora)', en: 'Warora' },
        villages: [
          { id: 'shegaon_r', name: { hi: 'शेगाव ग्रामीण (Shegaon Rural)', mr: 'शेगाव ग्रामीण (Shegaon Rural)', en: 'Shegaon Rural' }, lat: 20.2512, lon: 79.0812 },
        ],
      },
      {
        id: 'chimur',
        name: { hi: 'चिमूर (Chimur)', mr: 'चिमूर (Chimur)', en: 'Chimur' },
        villages: [
          { id: 'neri', name: { hi: 'नेरी (Neri)', mr: 'नेरी (Neri)', en: 'Neri' }, lat: 20.5212, lon: 79.4512 },
        ],
      },
    ],
  },

  {
    id: 'bhandara',
    name: { hi: 'भंडारा (Bhandara - धान जिल्हा)', mr: 'भंडारा (Bhandara - भात जिल्हा)', en: 'Bhandara' },
    division: 'Vidarbha',
    state: 'Maharashtra',
    defaultLat: 21.1712,
    defaultLon: 79.6512,
    talukas: [
      {
        id: 'tumsar',
        name: { hi: 'तुमसर (Tumsar)', mr: 'तुमसर (Tumsar)', en: 'Tumsar' },
        villages: [
          { id: 'sihora', name: { hi: 'सिहोरा (Sihora)', mr: 'सिहोरा (Sihora)', en: 'Sihora' }, lat: 21.4512, lon: 79.7212 },
        ],
      },
    ],
  },

  {
    id: 'gondia',
    name: { hi: 'गोंदिया (Gondia)', mr: 'गोंदिया (Gondia)', en: 'Gondia' },
    division: 'Vidarbha',
    state: 'Maharashtra',
    defaultLat: 21.4624,
    defaultLon: 80.1983,
    talukas: [
      {
        id: 'tirora',
        name: { hi: 'तिरोरा (Tirora)', mr: 'तिरोरा (Tirora)', en: 'Tirora' },
        villages: [
          { id: 'kamtha', name: { hi: 'कामतथा (Kamtha)', mr: 'कामतथा (Kamtha)', en: 'Kamtha' }, lat: 21.4112, lon: 80.0512 },
        ],
      },
    ],
  },

  {
    id: 'gadchiroli',
    name: { hi: 'गडचिरोली (Gadchiroli)', mr: 'गडचिरोली (Gadchiroli)', en: 'Gadchiroli' },
    division: 'Vidarbha',
    state: 'Maharashtra',
    defaultLat: 20.1804,
    defaultLon: 80.0031,
    talukas: [
      {
        id: 'armori',
        name: { hi: 'आरमोरी (Armori)', mr: 'आरमोरी (Armori)', en: 'Armori' },
        villages: [
          { id: 'wairagad', name: { hi: 'वैरागड (Wairagad)', mr: 'वैरागड (Wairagad)', en: 'Wairagad' }, lat: 20.4512, lon: 79.9812 },
        ],
      },
    ],
  },

  // ================= KONKAN DIVISION =================
  {
    id: 'thane',
    name: { hi: 'ठाणे (Thane)', mr: 'ठाणे (Thane)', en: 'Thane' },
    division: 'Konkan',
    state: 'Maharashtra',
    defaultLat: 19.2183,
    defaultLon: 72.9781,
    talukas: [
      {
        id: 'murbad',
        name: { hi: 'मुरबाड (Murbad)', mr: 'मुरबाड (Murbad)', en: 'Murbad' },
        villages: [
          { id: 'saralgaon', name: { hi: 'सरळगाव (Saralgaon)', mr: 'सरळगाव (Saralgaon)', en: 'Saralgaon' }, lat: 19.3112, lon: 73.4512 },
        ],
      },
      {
        id: 'shahapur',
        name: { hi: 'शहापूर (Shahapur)', mr: 'शहापूर (Shahapur)', en: 'Shahapur' },
        villages: [
          { id: 'asangaon', name: { hi: 'आसनगाव (Asangaon)', mr: 'आसनगाव (Asangaon)', en: 'Asangaon' }, lat: 19.4512, lon: 73.3112 },
        ],
      },
    ],
  },

  {
    id: 'palghar',
    name: { hi: 'पालघर (Palghar)', mr: 'पालघर (Palghar)', en: 'Palghar' },
    division: 'Konkan',
    state: 'Maharashtra',
    defaultLat: 19.6936,
    defaultLon: 72.7655,
    talukas: [
      {
        id: 'dahanu',
        name: { hi: 'डहाणू (Dahanu - चिकू हब)', mr: 'डहाणू (Dahanu - चिकू हब)', en: 'Dahanu' },
        villages: [
          { id: 'bordi', name: { hi: 'बोर्डी (Bordi)', mr: 'बोर्डी (Bordi)', en: 'Bordi' }, lat: 20.0812, lon: 72.7512 },
          { id: 'kasa', name: { hi: 'कासा (Kasa)', mr: 'कासा (Kasa)', en: 'Kasa' }, lat: 19.9812, lon: 72.9212 },
        ],
      },
      {
        id: 'wada',
        name: { hi: 'वाडा (Wada)', mr: 'वाडा (Wada)', en: 'Wada' },
        villages: [
          { id: 'kudus', name: { hi: 'कुडूस (Kudus)', mr: 'कुडूस (Kudus)', en: 'Kudus' }, lat: 19.6512, lon: 73.0812 },
        ],
      },
    ],
  },

  {
    id: 'raigad',
    name: { hi: 'रायगड (Raigad)', mr: 'रायगड (Raigad)', en: 'Raigad' },
    division: 'Konkan',
    state: 'Maharashtra',
    defaultLat: 18.5158,
    defaultLon: 73.1812,
    talukas: [
      {
        id: 'alibag',
        name: { hi: 'अलिबाग (Alibag)', mr: 'अलिबाग (Alibag)', en: 'Alibag' },
        villages: [
          { id: 'poynad', name: { hi: 'पोयनाड (Poynad)', mr: 'पोयनाड (Poynad)', en: 'Poynad' }, lat: 18.6812, lon: 73.0512 },
        ],
      },
      {
        id: 'roha',
        name: { hi: 'रोहा (Roha)', mr: 'रोहा (Roha)', en: 'Roha' },
        villages: [
          { id: 'kolad', name: { hi: 'कोलाड (Kolad)', mr: 'कोलाड (Kolad)', en: 'Kolad' }, lat: 18.4212, lon: 73.2112 },
        ],
      },
    ],
  },

  {
    id: 'ratnagiri',
    name: { hi: 'रत्नागिरी (Ratnagiri - हापूस आंबा)', mr: 'रत्नागिरी (Ratnagiri - हापूस आंबा)', en: 'Ratnagiri' },
    division: 'Konkan',
    state: 'Maharashtra',
    defaultLat: 16.9902,
    defaultLon: 73.3120,
    talukas: [
      {
        id: 'chiplun',
        name: { hi: 'चिपळूण (Chiplun)', mr: 'चिपळूण (Chiplun)', en: 'Chiplun' },
        villages: [
          { id: 'alore', name: { hi: 'अलोरे (Alore)', mr: 'अलोरे (Alore)', en: 'Alore' }, lat: 17.5212, lon: 73.5512 },
        ],
      },
      {
        id: 'dapoli',
        name: { hi: 'दापोली (Dapoli)', mr: 'दापोली (Dapoli)', en: 'Dapoli' },
        villages: [
          { id: 'anjarle', name: { hi: 'आंजर्ले (Anjarle)', mr: 'आंजर्ले (Anjarle)', en: 'Anjarle' }, lat: 17.8512, lon: 73.1212 },
        ],
      },
    ],
  },

  {
    id: 'sindhudurg',
    name: { hi: 'सिंधुदुर्ग (Sindhudurg)', mr: 'सिंधुदुर्ग (Sindhudurg)', en: 'Sindhudurg' },
    division: 'Konkan',
    state: 'Maharashtra',
    defaultLat: 16.1210,
    defaultLon: 73.7120,
    talukas: [
      {
        id: 'devgad',
        name: { hi: 'देवगड (Devgad - हापूस राजा)', mr: 'देवगड (Devgad - हापूस राजा)', en: 'Devgad' },
        villages: [
          { id: 'jamsande', name: { hi: 'जामसंडे (Jamsande)', mr: 'जामसंडे (Jamsande)', en: 'Jamsande' }, lat: 16.3812, lon: 73.3812 },
          { id: 'shirgaon_d', name: { hi: 'शिरगाव (Shirgaon)', mr: 'शिरगाव (Shirgaon)', en: 'Shirgaon' }, lat: 16.4512, lon: 73.4512 },
        ],
      },
      {
        id: 'kudal',
        name: { hi: 'कुडाळ (Kudal)', mr: 'कुडाळ (Kudal)', en: 'Kudal' },
        villages: [
          { id: 'kasal', name: { hi: 'कसाल (Kasal)', mr: 'कसाल (Kasal)', en: 'Kasal' }, lat: 16.0512, lon: 73.6812 },
        ],
      },
    ],
  },

  {
    id: 'mumbai_suburban',
    name: { hi: 'मुंबई / वाशी APMC (Navi Mumbai Market)', mr: 'मुंबई / वाशी APMC (Vashi APMC)', en: 'Mumbai / Vashi APMC' },
    division: 'Konkan',
    state: 'Maharashtra',
    defaultLat: 19.0760,
    defaultLon: 72.8777,
    talukas: [
      {
        id: 'vashi_apmc',
        name: { hi: 'वाशी APMC थोक मार्केट (Vashi APMC)', mr: 'वाशी APMC मुख्य बाजार (Vashi APMC)', en: 'Vashi APMC' },
        villages: [
          { id: 'vashi_market', name: { hi: 'कांदा-बटाटा व भाजी मार्केट वाशी', mr: 'कांदा-बटाटा व भाजी मार्केट वाशी', en: 'Onion Potato Market Vashi' }, lat: 19.0712, lon: 73.0012 },
        ],
      },
    ],
  },
];

// Flat searchable item for instant autocomplete across 300+ villages and talukas
export interface VillageSearchEntry {
  villageId: string;
  villageName: { hi: string; mr: string; en: string };
  talukaId: string;
  talukaName: { hi: string; mr: string; en: string };
  districtId: string;
  districtName: { hi: string; mr: string; en: string };
  division: string;
  lat: number;
  lon: number;
}

export const ALL_VILLAGES_INDEX: VillageSearchEntry[] = [];
for (const dist of MAHARASHTRA_DISTRICTS) {
  for (const tal of dist.talukas) {
    for (const vil of tal.villages) {
      ALL_VILLAGES_INDEX.push({
        villageId: vil.id,
        villageName: vil.name,
        talukaId: tal.id,
        talukaName: tal.name,
        districtId: dist.id,
        districtName: dist.name,
        division: dist.division,
        lat: vil.lat,
        lon: vil.lon,
      });
    }
  }
}

export const DEFAULT_WEATHER_DATA: WeatherData = {
  city: 'लासलगाव (Lasalgaon)',
  district: 'निफाड, नाशिक (Niphad, Nashik)',
  state: 'महाराष्ट्र (Maharashtra)',
  temp: 29,
  condition: 'धूप व हल्के बादल',
  conditionKey: 'partly_cloudy',
  rainProb: 15,
  humidity: 58,
  windSpeed: 12,
  advisory: {
    hi: 'मौसम साफ और शुष्क है। खरीफ फसलों की कटाई व प्याज रोपाई की तैयारी के लिए अनुकूल समय है। दोपहर में कीटनाशक छिड़काव किया जा सकता है।',
    mr: 'हवामान कोरडे व निरभ्र आहे. पिकांची काढणी, कांदा पुनर्लागवड तयारीसाठी अनुकूल दिवस. कीटकनाशक फवारणीस उत्तम वेळ.',
    en: 'Weather is clear and dry. Excellent conditions for harvesting and onion transplanting. Safe to spray insecticides.',
  },
  sprayAlert: {
    status: 'good',
    hi: 'छिड़काव के लिए उत्तम: हवा शांत है और बारिश का कोई खतरा नहीं है।',
    mr: 'फवारणीसाठी उत्तम: वारा शांत आहे आणि पावसाची शक्यता नाही.',
    en: 'Safe to Spray: Calmer winds and minimal chance of rain.',
  },
  forecast: [
    {
      day: { hi: 'कल', mr: 'उद्या', en: 'Tomorrow' },
      date: '16 Oct',
      tempMax: 31,
      tempMin: 19,
      rainProb: 10,
      conditionKey: 'sunny',
    },
    {
      day: { hi: 'शुक्रवार', mr: 'शुक्रवार', en: 'Friday' },
      date: '17 Oct',
      tempMax: 30,
      tempMin: 18,
      rainProb: 20,
      conditionKey: 'partly_cloudy',
    },
    {
      day: { hi: 'शनिवार', mr: 'शनिवार', en: 'Saturday' },
      date: '18 Oct',
      tempMax: 28,
      tempMin: 18,
      rainProb: 35,
      conditionKey: 'cloudy',
    },
    {
      day: { hi: 'रविवार', mr: 'रविवार', en: 'Sunday' },
      date: '19 Oct',
      tempMax: 29,
      tempMin: 17,
      rainProb: 15,
      conditionKey: 'sunny',
    },
    {
      day: { hi: 'सोमवार', mr: 'सोमवार', en: 'Monday' },
      date: '20 Oct',
      tempMax: 30,
      tempMin: 18,
      rainProb: 5,
      conditionKey: 'sunny',
    },
  ],
};

// Fetch live weather from free Open-Meteo API
export async function fetchLiveWeatherByCoords(
  lat: number,
  lon: number,
  locationLabel: { village: string; taluka: string; district: string }
): Promise<WeatherData> {
  try {
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}&current=temperature_2m,relative_humidity_2m,precipitation,weather_code,wind_speed_10m&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max&timezone=Asia%2FKolkata`;

    const res = await fetch(url);
    if (!res.ok) throw new Error('Weather API error');
    const data = await res.json();

    const temp = Math.round(data.current?.temperature_2m ?? 28);
    const humidity = Math.round(data.current?.relative_humidity_2m ?? 60);
    const windSpeed = Math.round(data.current?.wind_speed_10m ?? 10);
    const rainProb = data.daily?.precipitation_probability_max?.[0] ?? 10;
    const weatherCode = data.current?.weather_code ?? 0;

    let conditionKey: WeatherData['conditionKey'] = 'sunny';
    let conditionName = 'साफ धूप';

    if (weatherCode >= 80 || (weatherCode >= 51 && weatherCode <= 67)) {
      conditionKey = 'rainy';
      conditionName = 'बारिश / रिमझिम';
    } else if (weatherCode >= 95) {
      conditionKey = 'thunderstorm';
      conditionName = 'तूफान / बिजली';
    } else if (weatherCode === 1 || weatherCode === 2) {
      conditionKey = 'partly_cloudy';
      conditionName = 'धूप व हल्के बादल';
    } else if (weatherCode === 3) {
      conditionKey = 'cloudy';
      conditionName = 'बादल छाए रहेंगे';
    }

    // Agricultural spray safety alert
    let sprayAlert: WeatherData['sprayAlert'] = {
      status: 'good',
      hi: 'छिड़काव के लिए उत्तम: हवा की गति सामान्य है और बारिश की संभावना बहुत कम है।',
      mr: 'फवारणीसाठी उत्तम दिवस: वाऱ्याचा वेग शांत असून पावसाची शक्यता नाही.',
      en: 'Safe to Spray: Low winds and minimal rain probability.',
    };

    if (rainProb > 40) {
      sprayAlert = {
        status: 'danger',
        hi: 'सावधान: बारिश की संभावना 40% से अधिक है। आज कीटनाशक या फफूंदनाशक का छिड़काव न करें, दवा बह जाएगी।',
        mr: 'सावधान: पावसाची शक्यता ४०% पेक्षा जास्त आहे. आज कोणतीही औषध फवारणी करू नका, औषध वाहून जाईल.',
        en: 'Do not spray: Rain chance over 40%. Chemical will wash away.',
      };
    } else if (windSpeed > 18) {
      sprayAlert = {
        status: 'caution',
        hi: `सावधानी: हवा की गति तेज है (${windSpeed} km/h)। सुबह जल्दी या शाम को शांत मौसम में ही छिड़काव करें।`,
        mr: `सावधगिरी बाळगा: वाऱ्याचा वेग जास्त आहे (${windSpeed} किमी/तास). औषध उडून जाण्याचा धोका, सकाळी किंवा संध्याकाळी फवारा.`,
        en: `High wind speed (${windSpeed} km/h). Spray only during early morning or late evening.`,
      };
    }

    const weekdays = [
      { hi: 'रविवार', mr: 'रविवार', en: 'Sun' },
      { hi: 'सोमवार', mr: 'सोमवार', en: 'Mon' },
      { hi: 'मंगलवार', mr: 'मंगळवार', en: 'Tue' },
      { hi: 'बुधवार', mr: 'बुधवार', en: 'Wed' },
      { hi: 'गुरुवार', mr: 'गुरुवार', en: 'Thu' },
      { hi: 'शुक्रवार', mr: 'शुक्रवार', en: 'Fri' },
      { hi: 'शनिवार', mr: 'शनिवार', en: 'Sat' },
    ];

    const forecast: WeatherData['forecast'] = [];
    const dailyTimes = data.daily?.time ?? [];
    const maxTemps = data.daily?.temperature_2m_max ?? [];
    const minTemps = data.daily?.temperature_2m_min ?? [];
    const rainProbs = data.daily?.precipitation_probability_max ?? [];
    const codes = data.daily?.weather_code ?? [];

    for (let i = 1; i < Math.min(6, dailyTimes.length); i++) {
      const d = new Date(dailyTimes[i]);
      const dayObj = weekdays[d.getDay()] || { hi: 'दिन', mr: 'वार', en: 'Day' };
      const dateStr = `${d.getDate()} ${d.toLocaleString('default', { month: 'short' })}`;
      const c = codes[i] ?? 0;

      let cKey: WeatherData['conditionKey'] = 'sunny';
      if (c >= 80 || (c >= 51 && c <= 67)) cKey = 'rainy';
      else if (c >= 95) cKey = 'thunderstorm';
      else if (c === 1 || c === 2) cKey = 'partly_cloudy';
      else if (c === 3) cKey = 'cloudy';

      forecast.push({
        day: dayObj,
        date: dateStr,
        tempMax: Math.round(maxTemps[i] ?? 30),
        tempMin: Math.round(minTemps[i] ?? 18),
        rainProb: rainProbs[i] ?? 10,
        conditionKey: cKey,
      });
    }

    return {
      city: `${locationLabel.village} (गाव)`,
      district: `${locationLabel.taluka} (तालुका), ${locationLabel.district} (जिल्हा)`,
      state: 'महाराष्ट्र (Maharashtra)',
      temp,
      condition: conditionName,
      conditionKey,
      rainProb,
      humidity,
      windSpeed,
      advisory: {
        hi: `स्थानिक सलाह (${locationLabel.village}): तापमान ${temp}°C एवं आर्द्रता ${humidity}% है। खेत में सिंचाई और फवारणी मौसम अनुसार करें।`,
        mr: `स्थानिक कृषी सल्ला (${locationLabel.village}): तापमान ${temp}°C आणि आर्द्रता ${humidity}% आहे. जमिनीतील ओलावा बघून पाणी व्यवस्थापन करा.`,
        en: `Local Advisory (${locationLabel.village}): Temp is ${temp}°C with ${humidity}% humidity. Manage irrigation accordingly.`,
      },
      sprayAlert,
      forecast,
    };
  } catch (err) {
    console.warn('Weather fetch error, returning default data:', err);
    return {
      ...DEFAULT_WEATHER_DATA,
      city: `${locationLabel.village} (गाव)`,
      district: `${locationLabel.taluka} (तालुका), ${locationLabel.district} (जिल्हा)`,
    };
  }
}
