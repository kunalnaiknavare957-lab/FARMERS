export interface StageIrrigation {
  stage: { hi: string; mr: string; en: string };
  timing: string; // e.g. "0-15 दिवस"
  frequency: { hi: string; mr: string; en: string }; // e.g. "प्रत्येक 3-4 दिवसांनी"
  waterDetails: { hi: string; mr: string; en: string }; // e.g. "ड्रिप असेल तर रोज 1.5 तास"
  criticalWarning: { hi: string; mr: string; en: string };
}

export interface StageFertilizer {
  stage: { hi: string; mr: string; en: string };
  timing: string; // e.g. "लागवडीच्या वेळी (Basal)"
  fertilizerDose: { hi: string; mr: string; en: string };
  howToApply: { hi: string; mr: string; en: string };
}

export interface StageSpray {
  stage: { hi: string; mr: string; en: string };
  timing: string; // e.g. "20 ते 25 दिवस"
  targetPestOrDisease: { hi: string; mr: string; en: string };
  recommendedMedicine: { hi: string; mr: string; en: string };
  dosePerPump: string; // e.g. "15 लिटर पंपाला 10 मिली"
  organicOption: { hi: string; mr: string; en: string };
}

export interface DetailedCropGuidance {
  id: string;
  name: { hi: string; mr: string; en: string };
  tagline: { hi: string; mr: string; en: string };
  category: 'vegetables' | 'fruits' | 'cash' | 'grains' | 'pulses' | 'spices';
  durationDays: string;
  expectedYieldPerAcre: { hi: string; mr: string; en: string };
  soilAndClimate: { hi: string; mr: string; en: string };
  bestVarieties: { hi: string[]; mr: string[]; en: string[] };
  landPreparation: { hi: string[]; mr: string[]; en: string[] };
  spacingAndPlanting: { hi: string; mr: string; en: string };
  irrigationSchedule: StageIrrigation[];
  fertilizerSchedule: StageFertilizer[];
  spraySchedule: StageSpray[];
  bumperYieldSecrets: Array<{ hi: string; mr: string; en: string }>;
  harvestingAndGrading: { hi: string; mr: string; en: string };
}

export const CROP_GUIDANCE_DATABASE: DetailedCropGuidance[] = [
  // ================= ONION (कांदा / प्याज) =================
  {
    id: 'onion',
    name: { hi: 'प्याज (कांदा / Onion)', mr: 'कांदा (Onion - लाल व उन्हाळी)', en: 'Onion' },
    tagline: {
      hi: 'प्रति एकड़ 150 से 180 क्विंटल बंपर प्याज उत्पादन की A-Z वैज्ञानिक गाइड',
      mr: 'एकर १२० ते १५० क्विंटल भरघोस कांदा उत्पादनासाठी संपूर्ण आधुनिक शेती गाईड',
      en: 'Complete step-by-step roadmap for 150+ quintal/acre onion yield',
    },
    category: 'vegetables',
    durationDays: '110-125 दिवस (Days)',
    expectedYieldPerAcre: {
      hi: '150 - 180 क्विंटल प्रति एकड़ (उत्तम व्यवस्थापन से 200+ क्विंटल)',
      mr: '१४० - १८० क्विंटल प्रति एकर (उत्कृष्ट व्यवस्थापनाने २००+ क्विंटल)',
      en: '150 - 180 quintals per acre (up to 200 with precision farming)',
    },
    soilAndClimate: {
      hi: 'मध्यम से भारी, उत्तम जल निकासी वाली दोमट मिट्टी (pH 6.5 से 7.5)। जलभराव बिल्कुल न हो।',
      mr: 'मध्यम ते काळी, पाण्याचा उत्तम निचरा होणारी पोयट्याची जमीन (सामू ६.५ ते ७.५). पाणथळ जमीन टाळावी.',
      en: 'Medium to heavy well-drained loam soil with pH 6.5-7.5. Avoid waterlogging.',
    },
    bestVarieties: {
      hi: ['भीमा सुपर (लाल रंग व चमक)', 'भीमा रेड', 'भीमा शक्ति (उन्हाळी टिकवण)', 'प्रशांत बॉम्बे रेड', 'एलोरा फुरसुंगी'],
      mr: ['फुले समर्थ (खरिपासाठी उत्तम)', 'भीमा सुपर (गर्द लाल)', 'भीमा शक्ती (उन्हाळी दीर्घ साठवण)', 'एलोरा फुरसुंगी', 'पंचगंगा'],
      en: ['Bhima Super', 'Bhima Shakti (best storage)', 'Phule Samarth', 'Ellora Fursungi', 'Prashant Red'],
    },
    landPreparation: {
      hi: [
        'खेत की 2 बार गहरी जुताई करें और ढेले फोड़कर मिट्टी को भुरभुरा बनाएं।',
        'प्रति एकड़ 5 से 6 ट्रॉली अच्छी सड़ी हुई गोबर की खाद (FYM) या 2 टन वर्मीकम्पोस्ट मिलाएं।',
        'सपाट वाफे की जगह 120 सेमी चौड़े और 15 सेमी ऊंचे गादी वाफे (Raised Beds) बनाएं, जिससे 30% अधिक पैदावार मिलती है।',
        'ड्रिप इरीगेशन (इनलाइन 16mm ड्रिप, 40 सेमी ड्रिपर दूरी) अवश्य बिछाएं।',
      ],
      mr: [
        'जमिनीची खोल नांगरट करून रोटाव्हेटरने ढेकळे फोडून भुसभुशीत करा.',
        'एकर ५-६ ट्रॉली चांगले कुजलेले शेणखत किंवा २ टन गांडूळ खत जमिनीत मिसळा.',
        'सपाट वाफ्यांपेक्षा १२० सेंमी रुंद गादीवाफे (Raised Beds) बनवा, यामुळे मुळांची वाढ उत्तम होते.',
        'गादीवाफ्यावर इनलाईन ठिबक सिंचन नळी (४० सेंमी अंतरावरील ड्रिपर) वापरा.',
      ],
      en: [
        'Plow deeply twice and rotavate to fine tilth.',
        'Incorporate 5-6 trolleys of well-rotted FYM or 2 tons of vermicompost per acre.',
        'Make 120cm raised beds rather than flat beds for 30% higher bulb development.',
        'Install 16mm inline drip irrigation for uniform moisture.',
      ],
    },
    spacingAndPlanting: {
      hi: 'पौध से पौध 10 सेमी और कतार से कतार 15 सेमी। रोपाई से पहले पौधों की जड़ों को कार्बेंडाजिम (2 ग्राम) + इमिडाक्लोप्रिड (1 मिली/लीटर) के घोल में 10 मिनट डुबोएं।',
      mr: 'रोप लागवड अंतर: दोन रोपांत १० सेंमी आणि दोन ओळींत १५ सेंमी ठेवा. पुनर्लागवडीपूर्वी रोपांची मुळे कार्बेंडाझिम (२ ग्रॅम) + इमिडाक्लोप्रिड (१ मिली/लिटर) द्रावणात १० मिनिटे बुडवावीत.',
      en: 'Row to row 15 cm, plant to plant 10 cm. Dip seedling roots in Carbendazim (2g) + Imidacloprid (1ml) per liter water for 10 minutes before transplanting.',
    },
    irrigationSchedule: [
      {
        stage: { hi: 'रोपाई का पहला चरण', mr: 'पुनर्लागवड ते १० दिवस', en: 'Transplanting to Day 10' },
        timing: '0 - 10 दिवस',
        frequency: { hi: 'रोपाई के तुरंत बाद, फिर 3-4 दिन बाद हल्की सिंचाई', mr: 'लागवडीनंतर लगेच आणि चौथ्या दिवशी चिंबवणी पाणी', en: 'Immediate after planting, then day 4' },
        waterDetails: { hi: 'जड़ों को जमने के लिए हल्की नमी जरूरी है, खेत में पानी ठहरने न दें।', mr: 'रोप स्थिर होण्यासाठी हलका ओलावा ठेवा, पाणी साचू देऊ नका.', en: 'Maintain light moisture for root grip.' },
        criticalWarning: { hi: 'ज्यादा पानी से रोपा गल सकता है (डंपिंग ऑफ)।', mr: 'जास्त पाणी दिल्यास रोप कूज (Damping off) होऊ शकते.', en: 'Excess water causes damping off.' },
      },
      {
        stage: { hi: 'शाकीय बढ़वार (Vegetative)', mr: 'शाकीय वाढ (१० ते ५० दिवस)', en: 'Vegetative (Day 10-50)' },
        timing: '10 - 50 दिवस',
        frequency: { hi: 'हर 5 से 6 दिन के अंतराल पर (ड्रिप में रोज 1.5 घंटे)', mr: 'दर ५ ते ७ दिवसांनी पाणी द्या (ठिबक असल्यास रोज १.५ तास)', en: 'Every 5-7 days (drip 1.5 hrs daily)' },
        waterDetails: { hi: 'नमी एकसमान रहनी चाहिए ताकि पत्ते तेजी से बढ़ें।', mr: 'जमीन नेहमी वाफसा स्थितीत ठेवावी, ज्यामुळे मुळे वेगाने अन्न शोषतात.', en: 'Keep field in vafsa (aerated moisture) condition.' },
        criticalWarning: { hi: 'इस दौरान पानी का तनाव होने पर पत्तियां पीली पड़ जाती हैं।', mr: 'पाण्याचा ताण पडल्यास पाती वाळतात व वाढ खुंटते.', en: 'Water stress causes tip burning.' },
      },
      {
        stage: { hi: 'कंद बनने का चरण (Bulb Formation)', mr: 'कांदा पोसणे (५० ते ९० दिवस)', en: 'Bulb Formation (Day 50-90)' },
        timing: '50 - 90 दिवस',
        frequency: { hi: 'हर 4 से 5 दिन में नियमित सिंचाई', mr: 'दर ४ ते ५ दिवसांनी नियमित पाणी (सर्वात नाजूक टप्पा)', en: 'Every 4-5 days strictly' },
        waterDetails: { hi: 'कांदा मोटा होने के लिए भरपूर नमी आवश्यक है। ड्रिप से रोजाना 2 घंटे पानी दें।', mr: 'कांद्याचा आकार आणि वजन वाढण्यासाठी नियमित पाणी आवश्यक. ठिबकमधून रोज २ तास.', en: 'Crucial for bulb expansion and heavy weight.' },
        criticalWarning: { hi: 'पानी में अनियमितता (सूखने के बाद भारी पानी) से प्याज फट जाता है (डबल कंद)!', mr: 'पाण्यात अनियमितता झाल्यास कांदा फुटतो (डोकरा/जोड कांदा होतो).', en: 'Irregular watering splits bulbs (double onions).' },
      },
      {
        stage: { hi: 'परिपक्वता व कटाई पूर्व', mr: 'पक्वता व काढणीपूर्व (९०+ दिवस)', en: 'Maturity (90+ Days)' },
        timing: '90 - 115 दिवस',
        frequency: { hi: 'सिंचाई हल्की करें, कटाई से 12-15 दिन पहले पानी पूरी तरह बंद कर दें!', mr: 'काढणीच्या १२ ते १५ दिवस आधी पाणी पूर्णपणे तोडावे (बंद करावे)!', en: 'Stop irrigation 12-15 days before harvest!' },
        waterDetails: { hi: 'मिट्टी सूखने दें ताकि प्याज की गर्दन पतली हो और छिलका लाल व चमकदार बने।', mr: 'मान बारीक होऊन मान गळू द्या, ज्यामुळे कांद्याची टिकवण क्षमता वाढते.', en: 'Allows neck to fall and cures outer skins for 6-month storage.' },
        criticalWarning: { hi: 'कटाई से ठीक पहले पानी देने पर प्याज गोदाम में सड़ जाएगा!', mr: 'काढणीपूर्वी पाणी दिल्यास साठवणीत कांदा सडतो व कोंब येतात!', en: 'Watering near harvest causes rot in chawl storage!' },
      },
    ],
    fertilizerSchedule: [
      {
        stage: { hi: 'बुआई/रोपाई के समय (Basal Dose)', mr: 'लागवडीच्या वेळी (बेसल डोस)', en: 'Basal Dose at Planting' },
        timing: 'रोपाई के दिन 0',
        fertilizerDose: {
          hi: '10:26:26 (1 बोरी / 50 किलो) + सिंगल सुपर फॉस्फेट (SSP 100 किलो) + सल्फर 90% दानेदार (10 किलो) प्रति एकड़',
          mr: '१०:२६:२६ (१ बॅग/५० किलो) + सिंगल सुपर फॉस्फेट (SSP १०० किलो) + सल्फर ९०% (१० किलो) एकरी टाका',
          en: '10:26:26 (50kg) + SSP (100kg) + 90% Sulphur granules (10kg) per acre',
        },
        howToApply: {
          hi: 'रोपाई से पहले अंतिम जुताई या बेड बनाते समय मिट्टी में अच्छी तरह मिला दें।',
          mr: 'बेड तयार करताना किंवा लागवडीपूर्वी जमिनीत मिसळून द्या.',
          en: 'Mix thoroughly into bed soil before planting.',
        },
      },
      {
        stage: { hi: 'शाकीय बढ़वार (25-30 दिन)', mr: 'पहिला खत डोस (२५ ते ३० दिवस)', en: 'Vegetative (Day 25-30)' },
        timing: '25 - 30 दिवस',
        fertilizerDose: {
          hi: 'यूरिया 30 किलो + 19:19:19 (5 किलो ड्रिप से) + ह्यूमिक एसिड 500 ग्राम',
          mr: 'युरिया ३० किलो + १९:१९:१९ (५ किलो ठिबकमधून) + ह्युमिक ऍसिड ५०० ग्रॅम',
          en: 'Urea 30kg + 19:19:19 (5kg via drip) + Humic acid 500g',
        },
        howToApply: {
          hi: 'ड्रिप से वेंचुरी द्वारा चलाएं या हल्की सिंचाई के बाद जड़ों के पास डालें।',
          mr: 'ठिबक असल्यास व्हेंचुरीने द्या किंवा ओलावा असताना मुळांजवळ द्या.',
          en: 'Inject via venturi or dress near root zone.',
        },
      },
      {
        stage: { hi: 'कंद फुलाव (50-60 दिन)', mr: 'कांदा पोसणे (५० ते ६० दिवस)', en: 'Bulb Expansion (Day 50-60)' },
        timing: '50 - 60 दिवस',
        fertilizerDose: {
          hi: '12:61:00 (5 किलो) + 0:52:34 (5 किलो) + बोरॉन 20% (1 किलो) प्रति एकड़ ड्रिप से',
          mr: '१२:६१:०० (५ किलो) + ०:५२:३४ (५ किलो) + बोरॉन २०% (१ किलो) ठिबकमधून',
          en: '12:61:00 (5kg) + 0:52:34 (5kg) + Boron 20% (1kg) per acre drip',
        },
        howToApply: {
          hi: 'ड्रिप से 5 दिन के अंतराल में 2 बार दें। इससे प्याज का पर्दा मजबूत होता है और वजन बढ़ता है।',
          mr: '५ दिवसांच्या अंतराने २ हप्त्यांत द्या. कांद्याला जाड पापुद्रा व वजन येते.',
          en: 'Apply in 2 splits. Ensures thick skin and maximum weight.',
        },
      },
      {
        stage: { hi: 'चमक व वजन (75-80 दिन)', mr: 'वजन व चमक (७५ ते ८० दिवस)', en: 'Final Finishing (Day 75-80)' },
        timing: '75 - 80 दिवस',
        fertilizerDose: {
          hi: 'पोटाश 00:00:50 (5 किलो) + कैल्शियम नाइट्रेट (5 किलो) ड्रिप से',
          mr: '००:००:५० पोटॅश (५ किलो) + कॅल्शियम नायट्रेट (५ किलो) ठिबकमधून',
          en: '00:00:50 Potash (5kg) + Calcium Nitrate (5kg) per acre',
        },
        howToApply: {
          hi: 'नाइट्रोजन पूरी तरह बंद कर दें, केवल पोटाश दें ताकि प्याज का रंग गहरा लाल और ठोस बने।',
          mr: 'युरिया पूर्णपणे बंद करावा. पोटॅशमुळे कांदा टणक बनतो व टिकवण वाढते.',
          en: 'Cut off nitrogen completely. Potash hardens bulb for storage.',
        },
      },
    ],
    spraySchedule: [
      {
        stage: { hi: 'पहली फवारणी (थ्रिप्स व कीट रोकथाम)', mr: 'पहिली फवारणी (फुलकिडे/थ्रिप्स व करपा प्रतिबंध)', en: 'Spray 1: Thrips & Blight Prevention' },
        timing: '20 - 25 दिवस',
        targetPestOrDisease: { hi: 'थ्रिप्स (फुलकीड़ा), पत्ती मुड़ना, पीलापन', mr: 'थ्रिप्स (पातीतील पिवळे बारीक किडे), पानांच्या कडा पिवळ्या पडणे', en: 'Onion thrips & tip yellowing' },
        recommendedMedicine: { hi: 'फिप्रोनिल 5% SC (रीजेंट) 30 मिली + मैन्कोजेब 75% WP (साफ) 35 ग्राम + स्टिकर 5 मिली प्रति 15L पंप', mr: 'फिप्रोनिल ५% SC (३० मिली) + मॅन्कोझेब ७५% (३५ ग्रॅम) + स्टिकर (५ मिली) प्रति १५ लिटर पंप', en: 'Fipronil 5% SC (30ml) + Mancozeb (35g) + Spreader (5ml)' },
        dosePerPump: '15L पंप में 30ml फिप्रोनिल + 35g साफ',
        organicOption: { hi: 'नीम तेल 10,000 ppm (30 मिली) + 5% दशपर्णी अर्क', mr: 'निंबोळी तेल १०,००० ppm (३० मिली) + गोमूत्र १०० मिली', en: 'Neem oil 10,000 ppm @ 30ml/pump' },
      },
      {
        stage: { hi: 'दूसरी फवारणी (करपा व बैंगनी धब्बा)', mr: 'दुसरी फवारणी (जांभळा करपा व रसशोषक किडी)', en: 'Spray 2: Purple Blotch & Stempylium' },
        timing: '40 - 45 दिवस',
        targetPestOrDisease: { hi: 'बैंगनी धब्बा रोग (Purple blotch), थ्रिप्स प्रकोप', mr: 'जांभळा करपा (Purple Blotch), पानांवर काळे-जांभळे ठिपके', en: 'Purple blotch fungal spots' },
        recommendedMedicine: { hi: 'कस्टोडिया (अज़ॉक्सीस्ट्रॉबिन + टेबुकोनाज़ोल) 20 मिली + कराटे (लैमडा सायहलोथ्रिन) 15 मिली + स्टिकर', mr: 'कस्टोडिया (२० मिली) किंवा नॅटिव्हो (१० ग्रॅम) + कराटे (१५ मिली) प्रति १५ लिटर पंप', en: 'Custodia 20ml or Nativo 10g + Lambda-cyhalothrin 15ml' },
        dosePerPump: '15L पंप: कस्टोडिया 20ml + कराटे 15ml + स्टिकर 5ml',
        organicOption: { hi: 'खट्टी छाछ (ताक) 500 मिली + हींग 5 ग्राम प्रति पंप', mr: 'आंबट ताक ५०० मिली + हिंग ५ ग्रॅम प्रति पंप फवारा', en: 'Sour buttermilk 500ml + 5g Asafoetida' },
      },
      {
        stage: { hi: 'तीसरी फवारणी (कंद फुलाव व वजन)', mr: 'तिसरी फवारणी (कांदा फुगवण व रंग-चमक)', en: 'Spray 3: Bulb Bulking & Shine' },
        timing: '65 - 70 दिवस',
        targetPestOrDisease: { hi: 'प्याज का साइज बढ़ाना, गर्दन पतली करना, चमक लाना', mr: 'कांद्याची फुगवण, गर्द लाल रंग, मान बारीक करणे', en: 'Bulb sizing and color enhancement' },
        recommendedMedicine: { hi: '0:52:34 (75 ग्राम) + चमत्कार (मेपिक्वॉट क्लोराइड) 15 मिली + बोरॉन 20% (20 ग्राम) प्रति 15L पंप', mr: '०:५२:३४ (७५ ग्रॅम) + चमत्कार (१५ मिली) + बोरॉन (२० ग्रॅम) प्रति १५ लिटर पंप', en: '0:52:34 (75g) + Chamatkar/Mepiquat (15ml) + Boron (20g)' },
        dosePerPump: '15L पंप: 0:52:34 (75g) + Mepiquat (15ml) + Boron (20g)',
        organicOption: { hi: 'सीवीड अर्क (Seaweed) 30 मिली + पोटाश बैक्टीरिया', mr: 'समुद्री शेवाळ अर्क (Seaweed) ३० मिली प्रति पंप', en: 'Liquid seaweed extract 30ml/pump' },
      },
    ],
    bumperYieldSecrets: [
      {
        hi: 'सल्फर का जादू: प्याज में तीखापन, गहरा लाल रंग और 6 महीने की टिकाऊ क्षमता केवल सल्फर से आती है। बुआई के समय 10 किलो सल्फर अवश्य दें।',
        mr: 'सल्फरचा नियम: कांद्याला गर्द लाल रंग, वजन आणि ६ महिने साठवण क्षमता सल्फरमुळे येते. बेसल डोसमध्ये एकरी १० किलो सल्फर नक्की टाका.',
        en: 'Sulphur Secret: Sulphur gives pungent taste, dark red shine, and long shelf life.',
      },
      {
        hi: 'स्टिकर (सिलिकॉन स्प्रेडर) अनिवार्य: प्याज के पत्ते चिकने होते हैं, बिना स्टिकर दवा बह जाती है। हर फवारणी में 5 मिली सिलिकॉन स्टिकर अवश्य मिलाएं।',
        mr: 'स्टिकर अनिवार्य: कांद्याची पात गुळगुळीत असते. स्टिकर (Spreader) न वापरल्यास औषध खाली गळते. प्रत्येक फवारणीत ५ मिली स्टिकर टाका.',
        en: 'Silicone Spreader is mandatory on waxy onion leaves.',
      },
      {
        hi: 'चमत्कार या लिहोसिन का सही समय: 65 से 70 दिन पर जब प्याज नींबू बराबर हो, तब मेपिक्वॉट क्लोराइड (चमत्कार) डालें। यह पत्तों की व्यर्थ बढ़वार रोककर सारा रस प्याज में उतारता है।',
        mr: 'चमत्कार/लिहोसिनचा वापर: कांदा लिंबाएवढा झाल्यावर (६५-७० दिवस) चमत्कार फवारा. यामुळे पातीतला अन्नरस कांद्यात उतरून कांदा वजनदार बनतो.',
        en: 'Apply Mepiquat chloride at 65-70 days to divert vegetative energy into bulb enlargement.',
      },
      {
        hi: 'कटाई के बाद 3 दिन खेत में सुखाएं (क्युरिंग): पत्तों से प्याज को ढककर 3 दिन धूप में सुखाएं, फिर 1 इंच डंठल छोड़कर काटें।',
        mr: 'काढणीनंतर ३ दिवस शेतात सुकवणे: कांदा काढल्यावर पातीखाली झाकून ३ दिवस शेतात वाळवा. नंतर १ इंच मान ठेवून कापा.',
        en: 'Field curing for 3 days with foliage cover prevents storage rot.',
      },
    ],
    harvestingAndGrading: {
      hi: 'जब 60-70% पत्तियां खुद झुक जाएं, तब कटाई करें। ग्रेडिंग 3 भागों में करें: सुपर लाल (50mm+), मीडियम (40-50mm), गोलटा। अलग-अलग बेचने पर 20-30% ज्यादा भाव मिलता है।',
      mr: 'शेतातील ६०-७०% पाती आडव्या पडल्यावर काढणी करावी. कांद्याची प्रतवारी (सुपर कांदा ५० मिमी+, मध्यम व गोलटा) करून बाजारात न्यावा. सरमिसळ न विकल्यास २०-२५% अधिक भाव मिळतो.',
      en: 'Harvest when 60-70% foliage tops fall. Grade into Super (50mm+), Medium, and Golta for premium APMC rates.',
    },
  },

  // ================= TOMATO (टोमॅटो / टमाटर) =================
  {
    id: 'tomato',
    name: { hi: 'टमाटर (Tomato)', mr: 'टोमॅटो (Tomato - मल्चिंग व तार-बांबू)', en: 'Tomato' },
    tagline: {
      hi: 'प्रति एकड़ 35 से 45 टन बंपर टमाटर उत्पादन व वायरस-कीट मुक्ति गाइड',
      mr: 'एकर ३० ते ४० टन भरघोस टोमॅटो उत्पादनासाठी संपूर्ण आधुनिक शेती गाईड',
      en: 'Complete guide for 35-45 tons/acre high yield tomato cultivation',
    },
    category: 'vegetables',
    durationDays: '130-150 दिवस (Days)',
    expectedYieldPerAcre: {
      hi: '35 - 45 टन (1,500 से 2,000 क्रेट प्रति एकड़)',
      mr: '३० - ४० टन (१,५०० ते २,००० क्रेट प्रति एकर)',
      en: '35 - 45 tons (1,500 - 2,000 crates per acre)',
    },
    soilAndClimate: {
      hi: 'गहरी, उपजाऊ दोमट मिट्टी जिसमें जल निकास अच्छा हो। तापमान 20°C से 30°C सबसे उत्तम।',
      mr: 'मध्यम ते भारी, उत्तम निचऱ्याची गाळाची जमीन. २० ते ३० अंश से. तापमान फळधारणेस उत्तम.',
      en: 'Fertile loamy soil with excellent drainage. Optimal temp 20-30°C.',
    },
    bestVarieties: {
      hi: ['सिंजेंटा साहो (3251) - भारी उत्पादन व कठोर फल', 'अभिनव (सिंजेंटा)', 'नामधारी NS-4266', 'आर्यन', 'यूएस-1505'],
      mr: ['सिंजेंटा साहो ३२५१ (टणक फळे व दूरच्या वाहतुकीसाठी)', 'अभिनव टोमॅटो', 'नामधारी NS-४२६६', 'आर्यन', 'US-१५०५'],
      en: ['Syngenta Saho (3251)', 'Abhinav', 'Namdhari NS-4266', 'Aryan', 'US-1505'],
    },
    landPreparation: {
      hi: [
        'खेत की गहरी जुताई करके 4 फीट की दूरी पर 3 फीट चौड़े बेड बनाएं।',
        'प्रति एकड़ 6 ट्रॉली देसी खाद + 2 बोरी डीएपी + 1 बोरी पोटाश बेसल डोस में डालें।',
        '25 या 30 माइक्रोन का सिल्वर-ब्लैक मल्चिंग पेपर अवश्य लगाएं (खरपतवार व वायरस नियंत्रण हेतु)।',
        'तार और बांस (स्टेकिंग) विधि से ही खेती करें, नीचे जमीन पर टमाटर सड़ जाता है।',
      ],
      mr: [
        '४ फूट अंतरावर ३ फूट रुंद गादीवाफे (Raised Beds) तयार करा.',
        'एकर ६ ट्रॉली कुजलेले शेणखत + २ बॅग DAP + १ बॅग पोटॅश बेसल डोस म्हणून टाका.',
        '२५ किंवा ३० मायक्रॉनचा सिल्व्हर-ब्लॅक मल्चिंग पेपर नक्की अंथरा (तण व व्हायरस रोखण्यासाठी).',
        'तार-बांबू आधार पद्धतीचाच (Staking) वापर करा, जमिनीवर टोमॅटो सडतात.',
      ],
      en: [
        'Form 3-ft wide raised beds with 4-ft walking alleys.',
        'Apply 6 trolleys FYM + 2 bags DAP + 1 bag MOP as basal.',
        'Install 25-micron silver-black plastic mulch.',
        'Trellising with wire and bamboo stakes is mandatory for export quality.',
      ],
    },
    spacingAndPlanting: {
      hi: 'बेड पर पौधे से पौधे की दूरी 1.5 से 2 फीट (जिग-जैग विधि)। शाम के समय रोपाई करें और तुरंत ड्रिप से पानी दें।',
      mr: 'बेडवर रोपांमधील अंतर १.५ ते २ फूट (झिग-झॅग पद्धतीने) ठेवा. संध्याकाळी लागवड करावी व तात्काळ पाणी द्यावे.',
      en: '1.5 to 2 ft zig-zag spacing on bed. Plant in evening and irrigate immediately.',
    },
    irrigationSchedule: [
      {
        stage: { hi: 'रोपाई से 20 दिन तक', mr: 'लागवड ते २० दिवस', en: 'Establishment (Day 0-20)' },
        timing: '0 - 20 दिवस',
        frequency: { hi: 'रोपाई के समय भरपूर पानी, फिर हर 2 दिन में 1 घंटा ड्रिप', mr: 'लागवडीच्या वेळी भरपूर पाणी, नंतर रोज किंवा आडदिवशी १ तास ठिबक', en: 'Daily or alternate day 1 hr drip' },
        waterDetails: { hi: 'नमी एकसमान रहनी चाहिए ताकि नई जड़ें तेजी से फैले।', mr: 'मुळांचा विस्तार होण्यासाठी जमिनीत योग्य ओलावा ठेवावा.', en: 'Maintain consistent root-zone moisture.' },
        criticalWarning: { hi: 'अधिक पानी से कॉलर रॉट (तना सड़न) हो सकता है।', mr: 'जास्त ओलाव्यामुळे खोडकुज रोग होऊ शकतो.', en: 'Prevent collar rot from soggy soil.' },
      },
      {
        stage: { hi: 'फूल व फल लगने का समय', mr: 'फुलोरा व फळधारणा (३० ते ७० दिवस)', en: 'Flowering & Fruit Set (Day 30-70)' },
        timing: '30 - 70 दिवस',
        frequency: { hi: 'रोजाना ड्रिप से 1.5 से 2 घंटे नियमित पानी', mr: 'ठिबकमधून दररोज १.५ ते २ तास नियमित पाणी (अतिसंवेदनशील काळ)', en: '1.5 to 2 hours daily via drip' },
        waterDetails: { hi: 'पानी कभी भी कम या ज्यादा न हो। पानी का झटका लगते ही फूल झड़ जाते हैं।', mr: 'पाण्यात चढ-उतार झाल्यास फुलगळ होते आणि फळे तडकतात.', en: 'Water stress causes severe flower drop.' },
        criticalWarning: { hi: 'पानी की कमी से फलों का निचला हिस्सा काला पड़ता है (Blossom End Rot)।', mr: 'पाण्याच्या ताणामुळे फळाचा खालचा भाग काळा पडतो (ब्लॉसम एंड रॉट).', en: 'Water stress causes Blossom End Rot.' },
      },
      {
        stage: { hi: 'फलों की तुड़ाई का समय', mr: 'तोडणीचा टप्पा (७० ते १३० दिवस)', en: 'Harvesting Phase (Day 70-130)' },
        timing: '70 - 140 दिवस',
        frequency: { hi: 'हर 2 से 3 दिन में संतुलित सिंचाई', mr: 'तोडणीच्या १ दिवस आधी पाणी बंद ठेवावे, तोडणीनंतर लगेच पाणी द्यावे', en: 'Irrigate after each harvest picking' },
        waterDetails: { hi: 'तुड़ाई के दिन खेत सूखा रखें ताकि क्रेट उठाने में आसानी हो।', mr: 'तोडणीच्या दिवशी शेतात चिखल असू नये.', en: 'Keep soil dry during picking.' },
        criticalWarning: { hi: 'तुड़ाई से ठीक पहले ज्यादा पानी देने से टमाटर नरम हो जाता है और जल्दी पचकता है।', mr: 'तोडणीपूर्वी जास्त पाणी दिल्यास फळे मऊ पडतात व वाहतुकीत फुटतात.', en: 'Overwatering softens fruit skin.' },
      },
    ],
    fertilizerSchedule: [
      {
        stage: { hi: 'प्रारंभिक बढ़वार (10-25 दिन)', mr: 'शाकीय वाढ (१० ते २५ दिवस)', en: 'Vegetative (Day 10-25)' },
        timing: '10 - 25 दिवस',
        fertilizerDose: {
          hi: '19:19:19 (3 किलो प्रति एकड़) + 12:61:00 (2 किलो) सप्ताह में 2 बार ड्रिप से',
          mr: '१९:१९:१९ (३ किलो एकरी) + १२:६१:०० (२ किलो) आठवड्यातून दोनदा ठिबकमधून',
          en: '19:19:19 (3kg) + 12:61:00 (2kg) twice a week',
        },
        howToApply: { hi: 'ड्रिप वेंचुरी से पानी के साथ दें।', mr: 'ठिबक व्हेंचुरीने द्यावे.', en: 'Inject via drip venturi.' },
      },
      {
        stage: { hi: 'फूल व फल सेटिंग (30-60 दिन)', mr: 'फुलोरा व फळ धारणा (३० ते ६० दिवस)', en: 'Flowering & Setting (Day 30-60)' },
        timing: '30 - 60 दिवस',
        fertilizerDose: {
          hi: '12:61:00 (4 किलो) + बोरॉन 20% (500 ग्राम) + मैग्नीशियम सल्फेट (5 किलो) प्रति एकड़',
          mr: '१२:६१:०० (४ किलो) + बोरॉन (५०० ग्रॅम) + मॅग्नेशियम सल्फेट (५ किलो) आठवड्यातून एकदा',
          en: '12:61:00 (4kg) + Boron (500g) + Magnesium Sulphate (5kg)',
        },
        howToApply: { hi: 'बोरॉन से फूल फल में बदलता है और फूल झड़ने से रुकते हैं।', mr: 'बोरॉनमुळे फुलगळ थांबते व प्रत्येक फुलाचे फळात रूपांतर होते.', en: 'Boron prevents flower drop.' },
      },
      {
        stage: { hi: 'फल मोटा होना व चमक (60+ दिन)', mr: 'फळांचा आकार व वजन (६०+ दिवस)', en: 'Bulking & Color (Day 60+)' },
        timing: '60 - 120 दिवस',
        fertilizerDose: {
          hi: '0:52:34 (4 किलो) + 0:0:50 (5 किलो) + कैल्शियम नाइट्रेट (5 किलो अलग से) प्रति एकड़',
          mr: '०:५२:३४ (४ किलो) + ००:००:५० पोटॅश (५ किलो) + कॅल्शियम नायट्रेट (५ किलो स्वतंत्र)',
          en: '0:52:34 (4kg) + 0:0:50 (5kg) + Calcium Nitrate (5kg separately)',
        },
        howToApply: { hi: 'कैल्शियम नाइट्रेट को पोटाश के साथ कभी न मिलाएं, 2 दिन का अंतर रखें। इससे फल कड़क और चमकीला बनता है।', mr: 'कॅल्शियम व पोटॅश एकत्र मिसळू नका, २ दिवसांचा गॅप ठेवा. यामुळे फळे टणक होतात.', en: 'Do not mix Calcium with Potash; space 2 days apart.' },
      },
    ],
    spraySchedule: [
      {
        stage: { hi: 'सफेद मक्खी व थ्रिप्स (वायरस रोकथाम)', mr: 'पांढरी माशी व फुलकिडे (व्हायरस प्रतिबंध)', en: 'Whitefly & Virus Vector Control' },
        timing: '15 - 20 दिवस',
        targetPestOrDisease: { hi: 'सफेद मक्खी (जो लीफ कर्ल वायरस फैलाती है)', mr: 'पांढरी माशी (यामुळे पानांचा चुरडा-मुरडा व्हायरस येतो)', en: 'Whitefly vector of leaf curl virus' },
        recommendedMedicine: { hi: 'उलाला (Flonicamid) 6 ग्राम प्रति 15L पंप या पेगासस (Diafenthiuron) 20 ग्राम', mr: 'उलाला (६ ग्रॅम) किंवा पेगासस (२० ग्रॅम) प्रति १५ लिटर पंप', en: 'Ulala (Flonicamid) 6g or Pegasus 20g per 15L pump' },
        dosePerPump: '15L पंप में 6 ग्राम उलाला + 5ml स्टिकर',
        organicOption: { hi: 'पीले और नीले चिपचिपे कार्ड (Sticky Traps) प्रति एकड़ 25 लगाएं', mr: 'पिवळे व निळे चिकट सापळे एकरी २५ लावा + निंबोळी तेल फवारा', en: '25 yellow sticky traps per acre' },
      },
      {
        stage: { hi: 'फूल टिकने व करपा रोकथाम', mr: 'फुलगळ थांबवणे व करपा नियंत्रण', en: 'Flower retention & Early Blight' },
        timing: '35 - 40 दिवस',
        targetPestOrDisease: { hi: 'फूल झड़ना, पत्तियों पर झुलसा/करपा (Early Blight)', mr: 'फुलगळ होणे, पानावरील करपा व काळे चट्टे', en: 'Flower drop & early blight' },
        recommendedMedicine: { hi: 'एमिस्टार टॉप 15 मिली + प्लानोफिक्स 4 मिली (ज्यादा नहीं!) + साफ 30 ग्राम প্রতি 15L पंप', mr: 'अमिस्टार टॉप (१५ मिली) + प्लानोफिक्स (फक्त ४ मिली) + साफ (३० ग्रॅम) प्रति १५ लिटर पंप', en: 'Amistar Top 15ml + Planofix strictly 4ml + Saaf 30g' },
        dosePerPump: '15L पंप: Amistar Top 15ml + Planofix 4ml',
        organicOption: { hi: 'गोमूत्र 100ml + खट्टी छाछ 300ml', mr: 'गाईचे गोमूत्र १०० मिली + ताक ३०० मिली प्रति पंप', en: 'Cow urine 100ml + buttermilk 300ml' },
      },
      {
        stage: { hi: 'फल छेदक इल्ली (Fruit Borer) नियंत्रण', mr: 'फळ पोखरणारी अळी नियंत्रण', en: 'Fruit Borer (Helicoverpa)' },
        timing: '55 - 60 दिवस',
        targetPestOrDisease: { hi: 'टमाटर में छेद करने वाली हरी इल्ली', mr: 'टोमॅटो फळाला छिद्र पाडणारी हिरवी अळी', en: 'Fruit borer caterpillars' },
        recommendedMedicine: { hi: 'कोराजन (Chlorantraniliprole) 6 मिली प्रति 15L पंप या प्रोक्लेम (Emamectin) 8 ग्राम', mr: 'कोराजन (६ मिली) किंवा प्रोक्लेम (८ ग्रॅम) प्रति १५ लिटर पंप', en: 'Coragen (6ml) or Proclaim (8g) per 15L pump' },
        dosePerPump: '15L पंप: कोराजन 6ml + स्टिकर 5ml',
        organicOption: { hi: 'BT (Bacillus thuringiensis) 2 ग्राम/लीटर या नीमार्क', mr: 'बीटी (BT) पावडर ३० ग्रॅम प्रति पंप किंवा फेरोमोन ट्रॅप ५ एकरी', en: 'BT powder 30g + 5 pheromone traps/acre' },
      },
    ],
    bumperYieldSecrets: [
      {
        hi: 'तार-बांस अनिवार्य: जमीन पर पड़े टमाटर में 40% सड़न होती है और भाव नहीं मिलता। तार-बांस पर फल हवा में लटकता है, दाग नहीं लगते और रंग लाल-चमकदार आता है।',
        mr: 'तार-बांबू आधार: जमिनीवर टोमॅटो ठेवल्यास ४०% नुकसान होते. तारांवर वेल चढवल्याने फळाला डाग पडत नाहीत आणि बाजारात नंबर १ चा भाव मिळतो.',
        en: 'Trellising with wire and bamboo prevents 40% rotting losses.',
      },
      {
        hi: 'बगल की शाखाएं (सकर्स) छांटना: मुख्य तने के नीचे से निकलने वाली छोटी शाखाएं (सकर्स) 20 से 40 दिन के भीतर तोड़ दें। इससे पौधे का सारा खाना फलों में जाता है।',
        mr: 'फुटवे (Suckers) छाटणी: खोडाच्या खालून फुटणारे अनावश्यक शेंडे (सकर्स) आठवड्यातून एकदा खुडा. झाडाची ताकद फळांच्या आकाराकडे वळते.',
        en: 'Prune unwanted side suckers weekly to divert energy into fruit sizing.',
      },
      {
        hi: 'प्लानोफिक्स का नियम: फूल झड़ने से रोकने के लिए प्लानोफिक्स केवल 4 मिली प्रति 15 लीटर पंप डालें। गलती से भी 4ml से ज्यादा न डालें वरना फूल और पत्ते जल जाते हैं!',
        mr: 'प्लॅनोफिक्सचा नियम: फुलगळ थांबवण्यासाठी पंपाला फक्त ४ मिली प्लॅनोफिक्स टाकावे. जास्त टाकल्यास उलट नुकसान होते.',
        en: 'Never exceed 4ml of Planofix per 15L pump; overdose drops flowers.',
      },
    ],
    harvestingAndGrading: {
      hi: 'दूर की मंडियों (दिल्ली, मुंबई) के लिए जब टमाटर हल्का गुलाबी-लाल (Breaker Stage) हो तभी तोड़ें। स्थानीय बाजार के लिए पूरा लाल टमाटर तोड़ें। क्रेट में अखबार लगाकर पैक करें।',
      mr: 'लांबच्या बाजारासाठी (मुंबई, सुरत, दिल्ली) टोमॅटो लालसर-पिवळा (टणक) असतानाच तोडावा. स्थानिक बाजारासाठी पूर्ण लाल तोडावा. क्रेटमध्ये खाली-वर वर्तमानपत्र लावावे.',
      en: 'Pick at breaker stage (pink blush) for long transport. Line plastic crates with paper.',
    },
  },

  // ================= BANANA (केळी / केला) =================
  {
    id: 'banana',
    name: { hi: 'केला (Banana - G-9)', mr: 'केळी (Banana - ग्रँड नैन G-9)', en: 'Banana (G-9)' },
    tagline: {
      hi: 'प्रति एकड़ 35 से 45 टन (30-35 किलो का घार) केला उत्पादन की संपूर्ण तकनीक',
      mr: 'एकर ३५ ते ४५ टन (३० ते ३५ किलोची घड) केळी उत्पादनासाठी परिपूर्ण शेती गाईड',
      en: 'High yield tissue culture G-9 banana farming guide for 35+ tons/acre',
    },
    category: 'fruits',
    durationDays: '11-12 महिने (Months)',
    expectedYieldPerAcre: {
      hi: '35 - 45 टन प्रति एकड़ (1,200 से 1,400 पौधे प्रति एकड़)',
      mr: '३५ - ४५ टन प्रति एकर (प्रति झाड सरासरी ३०-३५ किलो घड)',
      en: '35 - 45 tons per acre (average 30-35 kg per bunch)',
    },
    soilAndClimate: {
      hi: 'गहरी, उपजाऊ काली या दोमट मिट्टी जिसमें कम से कम 1 मीटर तक जल निकास अच्छा हो। गर्म व आर्द्र जलवायु।',
      mr: 'किमान १ मीटर खोल, काळी-कसदार व उत्तम निचऱ्याची गाळाची जमीन. पाणथळ जमिनीत कंदकूज होते.',
      en: 'Deep well-drained fertile black/loam soil at least 1m depth. Warm humid climate.',
    },
    bestVarieties: {
      hi: ['ग्रैंड नैन (Grand Naine - G-9) टिशू कल्चर (सबसे लोकप्रिय व निर्यात योग्य)', 'श्रीमंती', 'महाभारत'],
      mr: ['ग्रँड नैन (G-9) टिशू कल्चर (बाजारात सर्वाधिक मागणी, एकसारखे घड)', 'श्रीमंती', 'वसंत'],
      en: ['Grand Naine (G-9) Tissue Culture', 'Shrimanti', 'Basrai'],
    },
    landPreparation: {
      hi: [
        'खेत की 2 बार गहरी जुताई करके मिट्टी को भुरभुरा बनाएं।',
        'प्रति गड्ढा (Pit) या ट्रेंच में 10 किलो सड़ी गोबर खाद + 250 ग्राम नीम की खली + 100 ग्राम एसएसपी डालें।',
        'पौधों के बीच 6 x 5 फीट (1,452 पौधे/एकड़) या 5 x 5 फीट का अंतर सबसे उत्तम है।',
        'डबल लाइन ड्रिप इरीगेशन (पौधे के दोनों ओर) लगाना अनिवार्य है।',
      ],
      mr: [
        'उभी-आडवी खोल नांगरट करून रोटाव्हेटर फिरवा.',
        '६ x ५ फूट (एकर १,४५० रोपे) किंवा ५ x ५ फूट अंतरावर सऱ्या पाडा किंवा खड्डे करा.',
        'प्रत्येक खड्ड्यात १० किलो कुजलेले शेणखत + २५० ग्रॅम निंबोळी पेंड + १०० ग्रॅम SSP टाका.',
        'केळीला भरपूर पाणी लागत असल्याने दोन बाजूला डबल लॅटरल ठिबक सिंचन बसवा.',
      ],
      en: [
        'Deep plow and make trenches at 6x5 ft spacing (1,450 plants/acre).',
        'Apply 10kg FYM + 250g Neem cake + 100g SSP per pit.',
        'Install dual-line drip lateral on either side of the plant row.',
      ],
    },
    spacingAndPlanting: {
      hi: '6 फीट कतार से कतार और 5 फीट पौधे से पौधा। टिशू कल्चर बैग को ब्लेड से काटकर पॉलीथीन हटाकर रोपें, मिट्टी अच्छे से दबाएं।',
      mr: '६ x ५ फूट अंतर. टिशू कल्चर पिशवी ब्लेडने कापून मातीचा गोळा न फुटता लावावी. मुळांभोवती माती घट्ट दाबावी.',
      en: '6 x 5 ft spacing. Slit polybag gently without breaking root ball and firm soil.',
    },
    irrigationSchedule: [
      {
        stage: { hi: 'लागवड ते 3 महिने', mr: 'लागवड ते ३ महिने (सुरुवातीची वाढ)', en: 'Establishment (Month 1-3)' },
        timing: '0 - 90 दिवस',
        frequency: { hi: 'ड्रिप से रोजाना 10 से 15 लीटर प्रति पौधा', mr: 'ठिबकमधून दररोज प्रति झाड १० ते १५ लिटर पाणी', en: '10-15 liters per plant daily' },
        waterDetails: { hi: 'पौधे की जड़ें अभी छोटी हैं, मिट्टी नम रहनी चाहिए।', mr: 'मुळांच्या कार्यक्षेत्रात सतत हलका ओलावा ठेवा.', en: 'Keep rhizosphere evenly moist.' },
        criticalWarning: { hi: 'जलभराव से तना गलन (ERWINIA ROT) हो सकता है।', mr: 'खोडाला पाणी साचल्यास कंदकूज होते.', en: 'Water stagnation rots rhizome.' },
      },
      {
        stage: { hi: 'भरपूर बढ़वार (4 से 8 महिने)', mr: 'जोमदार शाकीय वाढ (४ ते ८ महिने)', en: 'Peak Vegetative (Month 4-8)' },
        timing: '90 - 240 दिवस',
        frequency: { hi: 'गर्मी में रोज 20 से 25 लीटर प्रति पौधा (सर्दी में 12-15L)', mr: 'उन्हाळ्यात रोज २० ते २५ लिटर प्रति झाड (हिवाळ्यात १२-१५ लिटर)', en: '20-25 L/day in summer, 12-15 L/day in winter' },
        waterDetails: { hi: 'केला 80% पानी से बना है, इस अवस्था में पानी की कमी से घार छोटा रह जाता है।', mr: 'केळीला सर्वाधिक पाणी या टप्प्यात लागते. पाण्याचा ताण पडल्यास घड आखूड होतो.', en: 'Never let plant face water stress.' },
        criticalWarning: { hi: 'हवा तेज हो तो मिट्टी चढ़ाकर पौधों को सहारा दें।', mr: 'झाडाला मातीचा भक्कम भर लावा जेणेकरून झाड पडणार नाही.', en: 'Earth up soil around pseudostem.' },
      },
      {
        stage: { hi: 'फूल/कमल निकलना व घार भरना (8 से 11 महिने)', mr: 'कमळ बाहेर पडणे व घड भरणे (८ ते ११ महिने)', en: 'Bunch Development (Month 8-11)' },
        timing: '240 - 330 दिवस',
        frequency: { hi: 'रोजाना 25 से 30 लीटर प्रति पौधा', mr: 'दररोज २५ ते ३० लिटर प्रति झाड (घड पूर्ण पोसण्यासाठी)', en: '25-30 L per plant daily' },
        waterDetails: { hi: 'घार में केलों की मोटाई व लंबाई बढ़ाने के लिए भरपूर पानी दें।', mr: 'केळीची लांबी आणि गोलाई वाढण्यासाठी नियमित पाणी द्यावे.', en: 'Critical for finger length and caliber.' },
        criticalWarning: { hi: 'कटाई से 10 दिन पहले पानी बंद करें ताकि केले में मिठास और टिकाऊपन आए।', mr: 'घड कापणीच्या १० दिवस आधी पाणी कमी करावे.', en: 'Reduce watering 10 days before harvest.' },
      },
    ],
    fertilizerSchedule: [
      {
        stage: { hi: 'पहला चरण (15 से 60 दिन)', mr: 'पहिला टप्पा (१५ ते ६० दिवस)', en: 'Vegetative 1 (Day 15-60)' },
        timing: '15 - 60 दिवस',
        fertilizerDose: {
          hi: 'यूरिया (50g) + 19:19:19 (30g) प्रति पौधा प्रति माह ड्रिप से या जड़ों में',
          mr: 'युरिया (५० ग्रॅम) + १९:१९:१९ (३० ग्रॅम) प्रति झाड दर महिन्याला',
          en: 'Urea 50g + 19:19:19 30g per plant per month',
        },
        howToApply: { hi: 'ड्रिप से हर सप्ताह थोड़ा-थोड़ा दें।', mr: 'ठिबक असल्यास दर आठवड्याला विभागून द्या.', en: 'Split weekly via drip fertigation.' },
      },
      {
        stage: { hi: 'दूसरा चरण (3 से 7 महिने)', mr: 'दुसरा टप्पा (३ ते ७ महिने - पानांची संख्या वाढवणे)', en: 'Vegetative 2 (Month 3-7)' },
        timing: '90 - 210 दिवस',
        fertilizerDose: {
          hi: '12:61:00 (20g) + पोटाश MOP (75g) + मैग्नीशियम सल्फेट (25g) प्रति पौधा प्रति माह',
          mr: '१२:६१:०० (२० ग्रॅम) + पोटॅश MOP (७५ ग्रॅम) + मॅग्नेशियम सल्फेट (२५ ग्रॅम) प्रति झाड',
          en: '12:61:00 (20g) + MOP (75g) + MgSO4 (25g) per plant/month',
        },
        howToApply: { hi: 'केले को पोटाश सबसे अधिक चाहिए, पोटाश देने में कंजूसी न करें।', mr: 'केळीला पोटॅशची सर्वाधिक गरज असते. पोटॅश भरपूर द्या.', en: 'Potash is paramount for bunch weight.' },
      },
      {
        stage: { hi: 'घार पोषण (कमल निकलने के बाद)', mr: 'तिसरा टप्पा (कमळ निसवल्यानंतर घड फुगवण)', en: 'Bunch Bulking (After Heading)' },
        timing: '240 - 320 दिवस',
        fertilizerDose: {
          hi: '0:52:34 (40g) + 0:0:50 (60g) + बोरॉन 20% (5g) प्रति पौधा',
          mr: '०:५२:३४ (४० ग्रॅम) + ००:००:५० (६० ग्रॅम) + बोरॉन (५ ग्रॅम) प्रति झाड',
          en: '0:52:34 (40g) + 0:0:50 (60g) + Boron (5g) per plant',
        },
        howToApply: { hi: 'इससे केले का वजन 30 किलो से ऊपर जाता है और हर केल एकसमान लंबी बनती है।', mr: 'यामुळे केळीची लांबी एकसारखी होते व घड ३०-३५ किलोचा भरतो.', en: 'Achieves uniform finger length and 30kg+ bunches.' },
      },
    ],
    spraySchedule: [
      {
        stage: { hi: 'सिगाटोका पत्ती धब्बा रोग नियंत्रण', mr: 'सिगाटोका करपा रोग नियंत्रण', en: 'Sigatoka Leaf Spot' },
        timing: 'बारिश के मौसम में (दर 20-25 दिन)',
        targetPestOrDisease: { hi: 'सिगाटोका (पत्तों पर नाव के आकार के भूरे-काले धब्बे, पत्ते सूखना)', mr: 'सिगाटोका करपा (पानांवर लांबट तपकिरी ठिपके पडून पाने वाळणे)', en: 'Sigatoka leaf spot disease' },
        recommendedMedicine: { hi: 'प्रोपिकोनाज़ोल 25% EC (टिल्ट) 15 मिली + मिनरल ऑयल (कृषि तेल) 100 मिली + स्टिकर प्रति 15L पंप', mr: 'प्रोपिकोनाझोल २५% EC (१५ मिली) + कृषी खनिज तेल (१०० मिली) प्रति १५ लिटर पंप', en: 'Propiconazole (15ml) + Mineral oil (100ml) per 15L pump' },
        dosePerPump: '15L पंप: Propiconazole 15ml + Oil 100ml',
        organicOption: { hi: 'सूडोमोनास फ्लोरेसेंस (Pseudomonas) 10 ग्राम/लीटर का छिड़काव', mr: 'सुडोमोनास फ्लोरोसन्स १० ग्रॅम/लिटर पाण्यात मिसळून फवारा', en: 'Pseudomonas fluorescens 10g/L' },
      },
      {
        stage: { hi: 'घार पर फवारणी (कमल निकलने के बाद)', mr: 'घडावर फवारणी (कमळ निसवल्यानंतर)', en: 'Bunch Spray for Shine' },
        timing: 'कमल निकलने के 10 दिन बाद',
        targetPestOrDisease: { hi: 'केले पर थ्रिप्स, दाग-धब्बे, खुरदरापन रोकना', mr: 'केळीच्या सालीवर काळे डाग, ओरखडे व सुरकुत्या रोखणे', en: 'Flower thrips and fruit scarring' },
        recommendedMedicine: { hi: 'क्लोरोपायरीफॉस (20ml) + कार्बेंडाजिम (20g) + जीए3 (Gibberellic acid 1g) प्रति 15L पंप', mr: 'क्लोरपायरीफॉस (२० मिली) + कार्बेंडाझिम (२० ग्रॅम) + GA-३ (१ ग्रॅम) घडावर फवारा', en: 'Chlorpyriphos 20ml + Carbendazim 20g + GA3 1g' },
        dosePerPump: 'घार पर पूरा नहलाकर स्प्रे करें',
        organicOption: { hi: 'नीम तेल 5ml/L + पोटैशियम सिलिकेट', mr: 'निंबोळी तेल ५ मिली/लिटर', en: 'Neem oil 5ml/L' },
      },
    ],
    bumperYieldSecrets: [
      {
        hi: 'कमल (नर फूल) तोड़ना: जब घार के सारे फने खुल जाएं, तो सबसे नीचे का नर फूल (कमल) तेज धारदार चाकू से काट दें। इससे घार का सारा रस केलों में जाता है और वजन 3 से 5 किलो बढ़ जाता है!',
        mr: 'नरफूल (कमळ) तोडणे: घडातील शेवटचा फणी निसवल्यानंतर खालचे कमळ धारदार विळ्याने कापून टाकावे. यामुळे घडात ३ ते ५ किलो वजन वाढते!',
        en: 'Denavelling (cutting male bud) increases bunch weight by 3-5 kg.',
      },
      {
        hi: 'स्कर्टिंग बैग (नीली थैली) पहनाना: कमल तोड़ने के बाद घार पर 6% वेंटेड नीली पॉलिथीन थैली (Skirting Bag) चढ़ाएं। इससे केले पर धूप, कीड़े और दाग नहीं लगते, केला एकदम हरा व चिकना चमकता है और निर्यात भाव मिलता है।',
        mr: 'निळी स्कर्टिंग बॅग लावणे: घड निसवल्यावर निळी छिद्रे असलेली प्लास्टिक पिशवी (Bunch Sleeve) घालावी. यामुळे केळीला ऊन लागत नाही व डागमुक्त चकचकीत केळी मिळते.',
        en: 'Blue skirting bunch sleeve protects fruit from sun scorch and thrips.',
      },
      {
        hi: 'झाड़ को बांस का सहारा (Propping): भारी घार आने पर पौधा झुक जाता है। हर पौधे को बांस या नायलॉन रस्सी से सहारा अवश्य दें ताकि आंधी में घार न गिरे।',
        mr: 'बांबूचा टेकू देणे: घड भरल्यावर झाड झुकते. वाऱ्याने झाड मोडू नये म्हणून बांबूचा टेकू (Propping) देणे अत्यंत गरजेचे आहे.',
        en: 'Propping bunches with bamboo prevents stem lodging during winds.',
      },
    ],
    harvestingAndGrading: {
      hi: 'जब केले के कोणीय किनारे (Edges) गोल हो जाएं और रंग हल्का हरा हो जाए, तब घार काटें। घार को कभी जमीन पर न पटकें, फोम पैड पर रखें।',
      mr: 'केळीच्या बोटांच्या कडा गोल (Round) झाल्यावर आणि रंग फिकट हिरवा झाल्यावर घड कापावा. घड जमिनीवर आपटू नये, गादीवर ठेवावा.',
      en: 'Harvest when fingers become round and angles disappear. Place on foam pads to avoid bruising.',
    },
  },

  // ================= PAPAYA (पपई / पपीता) =================
  {
    id: 'papaya',
    name: { hi: 'पपीता (Papaya - रेड लेडी 786)', mr: 'पपई (Papaya - तैवान रेड लेडी ७८६)', en: 'Papaya (Taiwan 786)' },
    tagline: {
      hi: 'प्रति एकड़ 40 से 50 टन पपीता उत्पादन व वायरस से 100% सुरक्षा तकनीक',
      mr: 'एकर ४० ते ५० टन भरघोस पपई उत्पादनासाठी संपूर्ण आधुनिक शेती गाईड',
      en: 'Taiwan Red Lady 786 papaya cultivation guide for 40-50 tons/acre',
    },
    category: 'fruits',
    durationDays: '9-10 महिने (Months)',
    expectedYieldPerAcre: {
      hi: '40 - 50 टन प्रति एकड़ (प्रति पौधा 40-50 किलो फल)',
      mr: '४० - ५० टन प्रति एकर (प्रति झाड सरासरी ४० ते ६० किलो फळे)',
      en: '40 - 50 tons per acre (40-60 kg fruit per tree)',
    },
    soilAndClimate: {
      hi: 'उत्तम जल निकासी वाली रेतीली दोमट या मध्यम काली मिट्टी। पपीते की जड़ों में 2 घंटे भी पानी रुका तो पौधा मर जाता है!',
      mr: 'पाण्याचा निचरा होणारी हलकी ते मध्यम जमीन. पपईच्या मुळाशी २ तास जरी पाणी साचले तरी झाड १००% मरते!',
      en: 'Sandy loam or well-drained medium soil. Water stagnation for even 2 hours kills papaya roots!',
    },
    bestVarieties: {
      hi: ['ताइवान रेड लेडी 786 (Taiwan 786) - 100% उभयलिंगी व भारी फल', 'आइसबेरी', 'पूसा नन्हा', 'रेड रॉयल'],
      mr: ['तैवान रेड लेडी ७८६ (Taiwan 786 - सर्वाधिक उत्पादन, गोड व लाल गर)', 'आईसबरी', 'पुसा नन्हा'],
      en: ['Taiwan Red Lady 786 (Hermaphrodite, high brix)', 'Iceberry', 'Pusa Nanha'],
    },
    landPreparation: {
      hi: [
        'खेत में 7 x 7 फीट या 8 x 6 फीट की दूरी पर 1.5 फीट ऊंचे गादी वाफे (Raised Beds) बनाएं।',
        'सीधी जमीन पर पपीता कभी न लगाएं, केवल बेड पर ही लगाएं।',
        'प्रति एकड़ 5 ट्रॉली सड़ी गोबर खाद + 100 किलो नीम खली + 2 किलो ट्राइकोडर्मा मिलाएं।',
        'इनलाइन ड्रिप इरीगेशन लगाएं, पानी तने से 1 फीट दूर गिरना चाहिए।',
      ],
      mr: [
        '७ x ७ फूट किंवा ८ x ६ फूट अंतरावर १.५ फूट उंच गादीवाफे (Raised Beds) बनवा.',
        'सपाट जमिनीवर पपई कधीही लावू नका, बेडवरच लावावी.',
        'एकर ५ ट्रॉली शेणखत + १०० किलो निंबोळी पेंड + २ किलो ट्रायकोडर्मा बेसलमध्ये मिसळा.',
        'ठिबक सिंचनाची नळी खोडापासून १ फूट लांब ठेवावी, खोडाला पाणी लागू देऊ नये.',
      ],
      en: [
        'Make 1.5 ft high raised beds at 7x7 or 8x6 ft spacing.',
        'Never plant on flat ground.',
        'Incorporate 5 trolleys FYM + 100kg Neem cake + 2kg Trichoderma.',
        'Keep drip drippers 1 ft away from trunk.',
      ],
    },
    spacingAndPlanting: {
      hi: '7 x 7 फीट (प्रति एकड़ 900 पौधे)। रोपाई के समय पौधे को 1% बोर्डो मिश्रण या साफ (2g/L) से ड्रेन्च करें।',
      mr: '७ x ७ फूट अंतर (एकर ९०० रोपे). लागवडीच्या वेळी खोडाभोवती साफ (२ ग्रॅम/लिटर) किंवा १% बोर्डो मिश्रणाने आळवणी (Drenching) करा.',
      en: '7 x 7 ft spacing (900 plants/acre). Drench collar with 1% Bordeaux mixture or Saaf @ 2g/L.',
    },
    irrigationSchedule: [
      {
        stage: { hi: 'रोपाई से 60 दिन', mr: 'लागवड ते ६० दिवस', en: 'Initial 60 Days' },
        timing: '0 - 60 दिवस',
        frequency: { hi: 'ड्रिप से रोजाना 3 से 5 लीटर प्रति पौधा', mr: 'ठिबकमधून रोज ३ ते ५ लिटर प्रति झाड', en: '3-5 liters per plant daily' },
        waterDetails: { hi: 'मिट्टी में केवल नमी रहे, कीचड़ न बने।', mr: 'जमीन फक्त ओली ठेवा, चिखल होऊ देऊ नका.', en: 'Maintain aerated moist root zone.' },
        criticalWarning: { hi: 'तने के पास पानी जमने पर कॉलर रॉट (Collar rot) से पौधा गल जाता है।', mr: 'खोडाला पाणी लागल्यास खोडकूज होऊन झाड उन्मळून पडते.', en: 'Water on trunk collar causes fatal fungal rot.' },
      },
      {
        stage: { hi: 'फूल व फल सेटिंग (3 से 7 महिने)', mr: 'फुलोरा व फळधारणा (३ ते ७ महिने)', en: 'Flowering & Setting (Month 3-7)' },
        timing: '90 - 210 दिवस',
        frequency: { hi: 'मौसम अनुसार रोजाना 8 से 12 लीटर प्रति पौधा', mr: 'उन्हाळ्यात रोज १० ते १२ लिटर (हिवाळ्यात ६-८ लिटर)', en: '8-12 L per plant daily' },
        waterDetails: { hi: 'फल एकसमान भरने के लिए नियमित पानी जरूरी है।', mr: 'फळांचा आकार वाढण्यासाठी नियमित पाणी द्यावे.', en: 'Consistent moisture for fruit elongation.' },
        criticalWarning: { hi: 'पानी का झटका लगने पर फूल झड़ जाते हैं।', mr: 'पाण्याचा ताण पडल्यास फुलगळ होते.', en: 'Water stress causes blossom drop.' },
      },
      {
        stage: { hi: 'फल पकने का समय (7 से 10 महिने)', mr: 'फळे पक्व होणे (७ ते १० महिने)', en: 'Maturity (Month 7-10)' },
        timing: '210 - 300 दिवस',
        frequency: { hi: 'हल्की सिंचाई (6-8 लीटर प्रति पौधा)', mr: 'हलके पाणी (६ ते ८ लिटर प्रति झाड)', en: 'Light irrigation (6-8 L/day)' },
        waterDetails: { hi: 'अधिक पानी से पपीता फीका (कम मीठा) हो जाता है।', mr: 'जास्त पाणी दिल्यास पपई अळणी (कमी गोड) होते.', en: 'Excess water dilutes sweetness (Brix).' },
        criticalWarning: { hi: 'तुड़ाई से 2 दिन पहले पानी बंद रखें।', mr: 'तोडणीपूर्वी पाणी बंद ठेवावे.', en: 'Stop water 2 days before picking.' },
      },
    ],
    fertilizerSchedule: [
      {
        stage: { hi: 'बढ़वार चरण (20 से 90 दिन)', mr: 'शाकीय वाढ (२० ते ९० दिवस)', en: 'Vegetative Growth (Day 20-90)' },
        timing: '20 - 90 दिवस',
        fertilizerDose: {
          hi: '19:19:19 (25g) + 12:61:00 (15g) + मैग्नीशियम सल्फेट (10g) प्रति पौधा प्रति माह',
          mr: '१९:१९:१९ (२५ ग्रॅम) + १२:६१:०० (१५ ग्रॅम) + मॅग्नेशियम सल्फेट (१० ग्रॅम) प्रति झाड दरमहा',
          en: '19:19:19 (25g) + 12:61:00 (15g) + MgSO4 (10g) per plant/month',
        },
        howToApply: { hi: 'ड्रिप से हर सप्ताह थोड़ा-थोड़ा दें।', mr: 'ठिबक व्हेंचुरीने द्या.', en: 'Drip fertigation weekly.' },
      },
      {
        stage: { hi: 'फूल व फल सेटिंग (90 से 180 दिन)', mr: 'फुलोरा व फळ सेटिंग (३ ते ६ महिने)', en: 'Fruit Setting (Month 3-6)' },
        timing: '90 - 180 दिवस',
        fertilizerDose: {
          hi: '13:00:45 (30g) + बोरॉन 20% (3g) + कैल्शियम नाइट्रेट (20g) प्रति पौधा प्रति माह',
          mr: '१३:००:४५ पोटॅशियम नायट्रेट (३० ग्रॅम) + बोरॉन (३ ग्रॅम) + कॅल्शियम नायट्रेट (२० ग्रॅम) दरमहा',
          en: '13:00:45 (30g) + Boron (3g) + Calcium Nitrate (20g) per plant',
        },
        howToApply: { hi: 'बोरॉन से पपीता टेढ़ा-मेढ़ा नहीं होता और फल में मिठास आती है।', mr: 'बोरॉनमुळे पपई वाकडी-तिकडी होत नाही व फळ गोड होते.', en: 'Boron prevents fruit deformities.' },
      },
      {
        stage: { hi: 'फल मोटा होना (180+ दिन)', mr: 'फळ फुगवण (६ महिन्यांनंतर)', en: 'Fruit Bulking (Month 6+)' },
        timing: '180 - 300 दिवस',
        fertilizerDose: {
          hi: '00:00:50 पोटाश (40g) + 0:52:34 (25g) प्रति पौधा प्रति माह',
          mr: '००:००:५० पोटॅश (४० ग्रॅम) + ०:५२:३४ (२५ ग्रॅम) प्रति झाड दरमहा',
          en: '0:0:50 (40g) + 0:52:34 (25g) per plant/month',
        },
        howToApply: { hi: 'पोटाश से पपीते का छिलका कड़क बनता है और वजन 2 से 2.5 किलो प्रति फल होता है।', mr: 'पोटॅशमुळे फळाला वजन येते (२ ते २.५ किलो) व फळ गोड होते.', en: 'Potash boosts weight to 2-2.5 kg per fruit.' },
      },
    ],
    spraySchedule: [
      {
        stage: { hi: 'रिंग स्पॉट वायरस (Ring Spot Virus) रोकथाम', mr: 'रिंग स्पॉट व्हायरस प्रतिबंध (मावा व पांढरी माशी नियंत्रण)', en: 'Papaya Ring Spot Virus (PRSV) Prevention' },
        timing: 'शुरुआत से हर 15 दिन में',
        targetPestOrDisease: { hi: 'माहू (Aphids) और सफेद मक्खी - जो पपीते का सबसे बड़ा दुश्मन वायरस फैलाते हैं', mr: 'मावा व तुडतुडे (व्हायरस पसरवणारे कीटक)', en: 'Aphid vectors of PRSV' },
        recommendedMedicine: { hi: 'कॉन्फिडोर (इमिडाक्लोप्रिड) 0.5 मिली/लीटर या ओशीन (डिनोटेफ्यूरॉन) 0.5 ग्राम/लीटर + नीम तेल 3ml/L', mr: 'कॉन्फिडॉर (०.५ मिली/लिटर) किंवा ओशीन (०.५ ग्रॅम/लिटर) + निंबोळी तेल ३ मिली/लिटर', en: 'Imidacloprid 0.5ml/L or Dinotefuran 0.5g/L + Neem oil 3ml/L' },
        dosePerPump: '15L पंप में 7ml कॉन्फिडोर + 40ml नीम तेल',
        organicOption: { hi: 'खेत के चारों ओर मक्का या ज्वार की 3 कतारें बॉर्डर क्रॉप के रूप में लगाएं (वायरस अवरोधक)', mr: 'शेताभोवती मका किंवा ज्वारीच्या ३ ओळी लावाव्यात (व्हायरस रोखणारी कुंपण भिंत)', en: 'Border crop of 3 rows of Maize or Sorghum' },
      },
      {
        stage: { hi: 'कॉलर रॉट व फफूंद नियंत्रण', mr: 'खोडकूज व बुरशी प्रतिबंध', en: 'Collar Rot & Stem Canker' },
        timing: 'बारिश के दिनों में',
        targetPestOrDisease: { hi: 'तना सड़ना (Collar Rot / Phytophthora)', mr: 'खोडाची साल सडणे व झाड कोलमडणे', en: 'Phytophthora collar rot' },
        recommendedMedicine: { hi: 'तने पर 1% बोर्डो पेस्ट का लेप लगाएं + रिडोमिल गोल्ड (2.5 ग्राम/लीटर) से जड़ों में ड्रेन्चिंग करें', mr: 'खोडाला १% बोर्डो पेस्ट लावावी + रिडोमिल गोल्ड (२.५ ग्रॅम/लिटर) मुळाशी आळवणी करावी', en: 'Apply 1% Bordeaux paste on trunk + drench Ridomil Gold @ 2.5g/L' },
        dosePerPump: 'ड्रेन्चिंग: प्रति पौधा 1 लीटर घोल डालें',
        organicOption: { hi: 'ट्राइकोडर्मा विरिडी 10 ग्राम/लीटर का तने के पास घोल डालें', mr: 'ट्रायकोडर्मा व्हिरीडी १० ग्रॅम/लिटर मुळाशी ओता', en: 'Trichoderma viride 10g/L root drench' },
      },
    ],
    bumperYieldSecrets: [
      {
        hi: 'बॉर्डर क्रॉप का नियम: पपीते में रिंग स्पॉट वायरस हवा में उड़ने वाले माहू लाते हैं। खेत के चारों ओर मक्का या बाजरे की 3 घनी कतारें लगाएं। यह वायरस को खेत में घुसने से 80% रोक देता है!',
        mr: 'मका कुंपण नियम: पपईच्या शेताभोवती मक्याची ३ ओळींची दाट लागवड करा. यामुळे व्हायरस आणणारा मावा कीटक शेतात येत नाही.',
        en: 'Plant 3 barrier rows of maize around papaya field to filter out aphid virus vectors.',
      },
      {
        hi: 'बोर्डो पेस्ट का लेप: रोपाई के 2 महीने बाद और बारिश शुरू होने से पहले तने पर जमीन से 1.5 फीट तक 1% बोर्डो पेस्ट अवश्य लगाएं। इससे तना गलन की बीमारी कभी नहीं आएगी।',
        mr: 'बोर्डो पेस्ट लेप: पावसाळ्यापूर्वी खोडाला जमिनीपासून १.५ फुटापर्यंत बोर्डो पेस्टचा लेप लावावा. खोडकूज कधीही होणार नाही.',
        en: 'Paint 1% Bordeaux paste up to 1.5 ft height on stem before monsoons.',
      },
      {
        hi: 'बेड पर मल्चिंग: पपीते की जड़ें उथली होती हैं। सिल्वर-ब्लैक मल्चिंग लगाने से नमी बनी रहती है और खरपतवार नहीं उगते।',
        mr: 'मल्चिंग पेपर: पपईची मुळे उथळ असतात. मल्चिंगमुळे तण होत नाही व मुळांना इजा होत नाही.',
        en: 'Plastic mulching preserves shallow surface feeder roots.',
      },
    ],
    harvestingAndGrading: {
      hi: 'जब फल के निचले हिस्से पर 1 या 2 पीली धारियां दिखने लगें (Color Break Stage), तब तुड़ाई करें। कभी भी पूरा पीला फल न तोड़ें वरना रास्ते में दब जाएगा।',
      mr: 'फळाच्या खालच्या टोकाला पिवळसर पट्टे दिसू लागल्यावर (Color Break) फळे तोडावीत. पूर्ण पिवळी फळे तोडू नयेत.',
      en: 'Harvest when fruit apex develops 1-2 yellow streaks (color break stage). Never pick fully yellow fruits.',
    },
  },

  // ================= SOYBEAN (सोयाबीन) =================
  {
    id: 'soybean',
    name: { hi: 'सोयाबीन (Soybean)', mr: 'सोयाबीन (Soybean - खरीप सोनं)', en: 'Soybean' },
    tagline: {
      hi: 'प्रति एकड़ 12 से 15 क्विंटल सोयाबीन उत्पादन व पीला मोज़ेक मुक्ति तकनीक',
      mr: 'एकर १२ ते १५ क्विंटल भरघोस सोयाबीन उत्पादनासाठी संपूर्ण आधुनिक शेती गाईड',
      en: 'Complete guide for 12-15 quintals/acre high yield soybean farming',
    },
    category: 'grains',
    durationDays: '90-100 दिवस (Days)',
    expectedYieldPerAcre: {
      hi: '12 - 15 क्विंटल प्रति एकड़',
      mr: '१२ - १५ क्विंटल प्रति एकर (उत्कृष्ट व्यवस्थापनाने १८ क्विंटल)',
      en: '12 - 15 quintals per acre (up to 18 with BBF technology)',
    },
    soilAndClimate: {
      hi: 'मध्यम से भारी काली मिट्टी जिसमें जल निकासी की उचित व्यवस्था हो।',
      mr: 'मध्यम ते भारी, कसदार काळी जमीन. पाणी साचून राहणारी जमीन टाळावी.',
      en: 'Medium to deep black soils with good drainage.',
    },
    bestVarieties: {
      hi: ['जेएस 20-34 (कम दिनों में पकने वाली)', 'जेएस 20-98', 'एमएसीएस 1407', 'एनआरसी 142', 'फुले संगम (KDS 726 - सबसे ज्यादा पैदावार)'],
      mr: ['फुले संगम (KDS-७२६ - विक्रमी उत्पादन, तांबेरा प्रतिकारक)', 'फुले किमया (KDS-७५३)', 'JS-२०३४', 'JS-२०९८', 'MACS-१४०७'],
      en: ['Phule Sangam (KDS-726)', 'Phule Kimaya (KDS-753)', 'JS-20-34', 'JS-20-98'],
    },
    landPreparation: {
      hi: [
        'खेत की गहरी जुताई करें और रोटावेटर चलाकर मिट्टी समतल करें।',
        'बीबीएफ (ब्रॉड बेड फरो - BBF) तकनीक से बुआई करें, इससे कम या ज्यादा बारिश दोनों में फसल बचती है।',
        'प्रति एकड़ 1 बोरी डीएपी + 25 किलो पोटाश + 10 किलो सल्फर बुआई के समय डालें।',
      ],
      mr: [
        'BBF (रुंद वरंबा-चर) यंत्राने पेरणी करा. यामुळे अतिवृष्टी किंवा दुष्काळातही पीक वाचते.',
        'पेरणीच्या वेळी एकरी १ बॅग DAP किंवा १०:२६:२६ + १० किलो सल्फर टाका.',
      ],
      en: [
        'Sow with Broad Bed Furrow (BBF) machine for climate resilience.',
        'Apply 1 bag DAP + 25kg MOP + 10kg Sulphur per acre at sowing.',
      ],
    },
    spacingAndPlanting: {
      hi: 'कतार से कतार 45 सेमी (1.5 फीट) और बीज से बीज 5 से 7 सेमी। बीज दर: 25 से 30 किलो प्रति एकड़। बीज उपचार (राइजोबियम + ट्राइकोडर्मा) अवश्य करें।',
      mr: 'दोन ओळींत ४५ सेंमी (१.५ फूट) व दोन रोपांत ५ ते ७ सेंमी अंतर. एकरी बियाणे: २५ ते ३० किलो (फुले संगमसाठी २०-२२ किलो). रायझोबियम व ट्रायकोडर्मा बीजप्रक्रिया अनिवार्य.',
      en: 'Row spacing 45cm, plant 5-7cm. Seed rate 25-30kg/acre. Seed treatment with Rhizobium & Trichoderma.',
    },
    irrigationSchedule: [
      {
        stage: { hi: 'फूल आने का समय', mr: 'फुलोरा अवस्था (३५ ते ४५ दिवस)', en: 'Flowering Stage (Day 35-45)' },
        timing: '35 - 45 दिवस',
        frequency: { hi: 'यदि बारिश न हो तो 1 सिंचाई अवश्य दें', mr: 'पावसाचा खंड पडल्यास तुषार सिंचनाने (Sprinkler) एक पाणी नक्की द्या', en: '1 protective sprinkler irrigation if dry' },
        waterDetails: { hi: 'फूल आते समय सूखा पड़ने पर फूल झड़ जाते हैं।', mr: 'फुलोरा अवस्थेत पाण्याचा ताण पडल्यास फुलगळ होते.', en: 'Prevents flower drop during dry spells.' },
        criticalWarning: { hi: 'खेत में पानी भरने न दें, तुरंत निकालें।', mr: 'शेतात पाणी साचल्यास चर काढून पाणी बाहेर काढा.', en: 'Drain excess rain water immediately.' },
      },
      {
        stage: { hi: 'फली भरने का समय', mr: 'शेंगा भरणे (६० ते ७५ दिवस)', en: 'Pod Filling (Day 60-75)' },
        timing: '60 - 75 दिवस',
        frequency: { hi: 'बारिश न होने पर फली भरते समय 1 सिंचाई दें', mr: 'शेंगांमध्ये दाणे भरताना पाणी देणे अतिशय महत्त्वाचे आहे', en: 'Crucial protective irrigation' },
        waterDetails: { hi: 'इससे दाना मोटा, चमकदार और भारी बनता है।', mr: 'यामुळे दाणा टपोरा, भरदार आणि चमकदार बनतो.', en: 'Ensures bold grains and high oil content.' },
        criticalWarning: { hi: 'इस समय पानी न मिलने पर दाना बारीक रह जाता है।', mr: 'पाणी न मिळाल्यास दाणे चपटे व बारीक राहतात.', en: 'Drought at this stage shrinks grains.' },
      },
    ],
    fertilizerSchedule: [
      {
        stage: { hi: 'बुआई के समय', mr: 'पेरणीच्या वेळी (बेसल डोस)', en: 'Basal at Sowing' },
        timing: 'पेरणीच्या वेळी',
        fertilizerDose: {
          hi: 'डीएपी (50 किलो) + पोटाश (25 किलो) + सल्फर 90% (10 किलो) प्रति एकड़',
          mr: 'DAP (५० किलो) + पोटॅश (२५ किलो) + सल्फर (१० किलो) एकरी',
          en: 'DAP 50kg + MOP 25kg + Sulphur 10kg per acre',
        },
        howToApply: { hi: 'बीज से 5 सेमी नीचे खाद डालें।', mr: 'बियाण्याखाली खत पडेल असे पेरावे.', en: 'Place below seed furrow.' },
      },
      {
        stage: { hi: 'फूल आते समय फवारणी', mr: 'फुलोरा अवस्थेत फवारणी (४० दिवस)', en: 'Flowering Foliar Spray (Day 40)' },
        timing: '40 दिवस',
        fertilizerDose: {
          hi: '12:61:00 (75 ग्राम) + बोरॉन 20% (20 ग्राम) प्रति 15L पंप',
          mr: '१२:६१:०० (७५ ग्रॅम) + बोरॉन (२० ग्रॅम) प्रति १५ लिटर पंप',
          en: '12:61:00 (75g) + Boron (20g) per 15L pump',
        },
        howToApply: { hi: 'फूलों की संख्या बढ़ती है और फूल गिरना बंद होते हैं।', mr: 'शेंगांची संख्या दुपटीने वाढते.', en: 'Foliar spray for abundant pod setting.' },
      },
      {
        stage: { hi: 'फली भरते समय फवारणी', mr: 'शेंगा भरताना फवारणी (६५ दिवस)', en: 'Pod Filling Foliar Spray (Day 65)' },
        timing: '65 दिवस',
        fertilizerDose: {
          hi: '00:00:50 पोटाश (100 ग्राम) प्रति 15L पंप',
          mr: '००:००:५० पोटॅश (१०० ग्रॅम) प्रति १५ लिटर पंप',
          en: '0:0:50 Potash (100g) per 15L pump',
        },
        howToApply: { hi: 'दाना बोल्ड, चमकदार और 15% अधिक वजनदार बनता है।', mr: 'दाणा टपोरा व वजनदार बनवण्यासाठी.', en: 'Foliar spray for plump bold grains.' },
      },
    ],
    spraySchedule: [
      {
        stage: { hi: 'खोडकीड़ा व चक्रभृंग (Girdle beetle)', mr: 'खोडमाशी व चक्रीभुंगा नियंत्रण', en: 'Stem Fly & Girdle Beetle' },
        timing: '15 - 20 दिवस',
        targetPestOrDisease: { hi: 'खोडमाखी और चक्रभृंग (जो पौधे के तने में रिंग काटता है)', mr: 'चक्रीभुंगा (फांदीवर दोन रिंग मारून अंडी घालतो) व खोडमाशी', en: 'Girdle beetle and stem fly' },
        recommendedMedicine: { hi: 'क्लोरेंट्रानिलिप्रोल 18.5% SC (कोराजन) 6 मिली प्रति 15L पंप या प्रोफेक्स सुपर 30 मिली', mr: 'कोराजन (६ मिली) किंवा प्रोफेक्स सुपर (३० मिली) प्रति १५ लिटर पंप', en: 'Coragen (6ml) or Profex Super (30ml) per 15L pump' },
        dosePerPump: '15L पंप: कोराजन 6ml',
        organicOption: { hi: 'नीम तेल 10000 ppm (30ml प्रति पंप)', mr: 'निंबोळी अर्क ५% किंवा नीम तेल ३० मिली प्रति पंप', en: 'Neem oil 10,000 ppm @ 30ml/pump' },
      },
      {
        stage: { hi: 'तांबेरा व शेंगा पोखरणारी अळी', mr: 'तांबेरा रोग व पाने खाणारी अळी', en: 'Rust Disease & Pod Borer' },
        timing: '50 - 55 दिवस',
        targetPestOrDisease: { hi: 'तांबेरा (पत्तियों पर जंग जैसे भूरे धब्बे) व फली छेदक इल्ली', mr: 'तांबेरा (पानांखाली तांबूस डाग) आणि तंबाखूची पाने खाणारी अळी', en: 'Soybean rust & Spodoptera' },
        recommendedMedicine: { hi: 'टेबुकोनाज़ोल 25.9% (फॉलिकुर) 15 मिली + एमामेक्टिन बेंजोएट (प्रोक्लेम) 8 ग्राम प्रति 15L पंप', mr: 'फॉलिकुर (१५ मिली) + प्रोक्लेम (८ ग्रॅम) प्रति १५ लिटर पंप', en: 'Folicur (15ml) + Proclaim (8g) per 15L pump' },
        dosePerPump: '15L पंप: टेबुकोनाज़ोल 15ml + प्रोक्लेम 8g',
        organicOption: { hi: 'दशपर्णी अर्क 100ml + गोमूत्र', mr: 'दशपर्णी अर्क १०० मिली प्रति पंप', en: 'Dashparni extract 100ml' },
      },
    ],
    bumperYieldSecrets: [
      {
        hi: 'बीबीएफ (BBF) वरंबा पद्धत: बीबीएफ यंत्राने पेरणी केल्यास 20% बियाणे बचते, पाणी तुंबत नाही आणि उत्पादन एकरी 3-4 क्विंटल जास्त मिळते.',
        mr: 'BBF तंत्रज्ञान: रुंद वरंबा-चर पद्धतीमुळे जास्तीचे पाणी निघून जाते आणि दुष्काळात ओलावा टिकतो. उत्पादन ३-४ क्विंटलने वाढते.',
        en: 'Broad Bed Furrow planting increases yield by 3-4 quintals/acre.',
      },
      {
        hi: 'सल्फर अवश्य दें: सोयाबीन तिलहन फसल है। सल्फर देने से दानों में तेल की मात्रा और दाने का वजन 15% बढ़ जाता है।',
        mr: 'सल्फरचे महत्त्व: सोयाबीन हे तेलबिया पीक आहे. सल्फरमुळे दाण्यातील तेलाचे प्रमाण आणि वजन वाढते.',
        en: 'Sulphur application boosts oil content and grain test weight.',
      },
    ],
    harvestingAndGrading: {
      hi: 'जब 90% पत्तियां सूखकर झड़ जाएं और फलियां भूरी-पीली हो जाएं, तब कटाई करें। कटाई के बाद धूप में 2 दिन सुखाकर थ्रेशर से धीमी गति (400 RPM) पर गहाई करें ताकि दाना न फूटे।',
      mr: 'झाडाची पाने पिवळी पडून गळल्यावर आणि शेंगा तपकिरी झाल्यावर काढणी करा. थ्रेशरचा वेग कमी ठेवा (४०० RPM) जेणेकरून बियाण्याला मार लागणार नाही.',
      en: 'Harvest when 90% leaves drop and pods turn brown. Thresh at low speed (400 RPM) to prevent grain split.',
    },
  },

  // ================= COTTON (कापूस / कपास) =================
  {
    id: 'cotton',
    name: { hi: 'कपास (Cotton - बीटी कॉटन)', mr: 'कापूस (Cotton - पांढरं सोनं)', en: 'Cotton (Bt Cotton)' },
    tagline: {
      hi: 'प्रति एकड़ 15 से 20 क्विंटल कपास उत्पादन व गुलाबी सुंडी से संपूर्ण मुक्ति',
      mr: 'एकर १५ ते २० क्विंटल भरघोस कापूस उत्पादनासाठी संपूर्ण आधुनिक शेती गाईड',
      en: 'Complete guide for 15-20 quintals/acre high yield cotton farming',
    },
    category: 'cash',
    durationDays: '150-180 दिवस (Days)',
    expectedYieldPerAcre: {
      hi: '15 - 20 क्विंटल प्रति एकड़ (ड्रिप से 25 क्विंटल)',
      mr: '१५ - २० क्विंटल प्रति एकर (ठिबक सिंचनाने २५ क्विंटल)',
      en: '15 - 20 quintals per acre (up to 25 with drip fertigation)',
    },
    soilAndClimate: {
      hi: 'गहरी काली कपास मिट्टी (Black Cotton Soil) जिसमें नमी सोखने की क्षमता अधिक हो।',
      mr: 'खोल काळी, कसदार जमीन. उष्ण व दमट हवामान.',
      en: 'Deep black cotton soil with high moisture retention capacity.',
    },
    bestVarieties: {
      hi: ['राशि 659 (RCH-659 - सबसे लोकप्रिय)', 'अजीत 155', 'जादू (कावेरी)', 'मनीमेकर', 'भक्ति'],
      mr: ['राशी ६५९ (RCH-६५९ - सर्वाधिक पसंती, मोठी बोंडे)', 'अजित १५५', 'जादू (कावेरी)', 'भक्ती', 'मनीमेकर'],
      en: ['Rasi 659 (RCH-659)', 'Ajit 155', 'Jadoo (Kaveri)', 'Bhakti'],
    },
    landPreparation: {
      hi: [
        'खेत की गहरी जुताई करके 4 x 1.5 फीट या 5 x 1.5 फीट पर मेड़ बनाएं।',
        'प्रति एकड़ 5 ट्रॉली सड़ी गोबर खाद + 100 किलो डीएपी + 50 किलो पोटाश बेसल में डालें।',
        'ड्रिप इरीगेशन लगाने से पैदावार दोगुनी हो जाती है।',
      ],
      mr: [
        'जमिनीची खोल नांगरट करून ४ x १.५ फूट किंवा ५ x १.५ फूट अंतरावर सऱ्या पाडा.',
        'एकर ५ ट्रॉली कुजलेले शेणखत + १ बॅग DAP + १ बॅग पोटॅश बेसल डोस म्हणून द्या.',
        'ठिबक सिंचनाचा वापर केल्यास उत्पादनात दुपटीने वाढ होते.',
      ],
      en: [
        'Plow deeply and ridge at 4x1.5 or 5x1.5 ft spacing.',
        'Apply 5 trolleys FYM + 1 bag DAP + 1 bag MOP.',
        'Drip irrigation drastically improves boll retention.',
      ],
    },
    spacingAndPlanting: {
      hi: 'हल्की मिट्टी में 4 x 1.5 फीट, भारी काली मिट्टी में 5 x 1.5 या 5 x 2 फीट। एक जगह एक ही स्वस्थ पौधा रखें।',
      mr: 'मध्यम जमिनीत ४ x १.५ फूट, भारी काळ्या जमिनीत ५ x २ फूट. एका जागी एकच जोमदार रोप ठेवावे (विरळणी करा).',
      en: '4 x 1.5 ft in medium soil, 5 x 2 ft in heavy soil. Thin to 1 plant per hill.',
    },
    irrigationSchedule: [
      {
        stage: { hi: 'फूल व गूलर (बोंड) बनने का समय', mr: 'पात्या व बोंडे लागणे (५० ते ११० दिवस)', en: 'Squaring & Boll Formation (Day 50-110)' },
        timing: '50 - 110 दिवस',
        frequency: { hi: 'हर 8 से 10 दिन में (ड्रिप से हर दूसरे दिन 2 घंटा)', mr: 'दर ८ ते १० दिवसांनी (ठिबक असल्यास रोज २ तास)', en: 'Every 8-10 days (drip 2 hrs alt. day)' },
        waterDetails: { hi: 'कपास को इस समय पानी की सबसे ज्यादा जरूरत होती है।', mr: 'हा पाण्याचा अत्यंत संवेदनशील काळ आहे. बोंडे पोसण्यासाठी भरपूर ओलावा लागतो.', en: 'Peak water requirement stage.' },
        criticalWarning: { hi: 'पानी की कमी होने पर फूल व कलियां (पात्या) तेजी से झड़ जाती हैं।', mr: 'पाण्याचा ताण पडल्यास पात्या आणि फुलांची प्रचंड गळ होते.', en: 'Water stress causes massive squaring drop.' },
      },
    ],
    fertilizerSchedule: [
      {
        stage: { hi: 'बुआई के समय', mr: 'पेरणीच्या वेळी (बेसल डोस)', en: 'Basal at Sowing' },
        timing: 'पेरणीच्या दिवशी',
        fertilizerDose: {
          hi: '10:26:26 (1 बोरी) + सिंगल सुपर फॉस्फेट (50 किलो) + मैग्नीशियम सल्फेट (10 किलो)',
          mr: '१०:२६:२६ (१ बॅग) + SSP (५० किलो) + मॅग्नेशियम सल्फेट (१० किलो) एकरी',
          en: '10:26:26 (1 bag) + SSP (50kg) + MgSO4 (10kg)',
        },
        howToApply: { hi: 'मेड़ पर जड़ों के पास डालें।', mr: 'सऱ्यांमध्ये मुळांजवळ द्या.', en: 'Side dress along furrow.' },
      },
      {
        stage: { hi: 'फूल व बोंड बनते समय (60-70 दिन)', mr: 'बोंडे भरताना (६० ते ७० दिवस)', en: 'Boll Development (Day 60-70)' },
        timing: '60 - 70 दिवस',
        fertilizerDose: {
          hi: 'यूरिया (30 किलो) + पोटाश 00:00:50 (5 किलो ड्रिप से) + 13:00:45 (फवारणी)',
          mr: 'युरिया (३० किलो) + पोटॅश ००:००:५० (५ किलो ठिबकमधून) + १३:००:४५ फवारणी',
          en: 'Urea 30kg + 0:0:50 (5kg via drip) + 13:00:45 foliar',
        },
        howToApply: { hi: 'पोटाश से बोंड का साइज बड़ा होता है और कपास का रेशा लंबा व चमकदार बनता है।', mr: 'पोटॅशमुळे बोंडाचा आकार मोठा होतो व कापसाची प्रत सुधारते.', en: 'Potash boosts boll size and fiber strength.' },
      },
    ],
    spraySchedule: [
      {
        stage: { hi: 'गुलाबी सुंडी (Pink Bollworm) रोकथाम', mr: 'गुलाबी बोंडअळी प्रतिबंध (फेरोमोन सापळे व फवारणी)', en: 'Pink Bollworm Management' },
        timing: '45 - 50 दिवसांपासून पुढे',
        targetPestOrDisease: { hi: 'गुलाबी सुंडी - जो बोंड के अंदर घुसकर कपास खा जाती है', mr: 'गुलाबी बोंडअळी (बोंडात शिरून कापूस खराब करणारी अळी)', en: 'Pink bollworm larvae in bolls' },
        recommendedMedicine: { hi: 'प्रोफेनोफॉस 50% EC 30ml प्रति 15L पंप या एम्पलीगो 10ml प्रति 15L पंप', mr: 'प्रोफेनोफॉस ५०% (३० मिली) किंवा एम्प्लिगो (१० मिली) प्रति १५ लिटर पंप', en: 'Profenofos 50% EC 30ml or Ampligo 10ml per 15L pump' },
        dosePerPump: '15L पंप: प्रोफेनोफॉस 30ml',
        organicOption: { hi: 'खेत में प्रति एकड़ 5 से 8 फेरोमोन ट्रैप (Pheromone Traps) लगाएं', mr: 'एकरी ५ ते ८ गुलाबी बोंडअळीचे कामगंध सापळे (Pheromone Traps) लावावेत', en: 'Install 5-8 pheromone traps per acre' },
      },
      {
        stage: { hi: 'रसशोषक कीट (माहू, थ्रिप्स, सफेद मक्खी)', mr: 'रसशोषक किडी (पांढरी माशी, तुडतुडे, मावा)', en: 'Sucking Pests (Whitefly, Jassids)' },
        timing: '30 - 35 दिवस',
        targetPestOrDisease: { hi: 'पत्तियों का मुड़ना और पीला पड़ना', mr: 'पाने पिवळी व लाल पडणे, कडा वाकड्या होणे', en: 'Leaf curling and reddening' },
        recommendedMedicine: { hi: 'उलाला (Flonicamid) 6 ग्राम प्रति 15L पंप या ओशीन 8 ग्राम', mr: 'उलाला (६ ग्रॅम) किंवा ओशीन (८ ग्रॅम) प्रति १५ लिटर पंप', en: 'Ulala (6g) or Oshin (8g) per 15L pump' },
        dosePerPump: '15L पंप: उलाला 6g',
        organicOption: { hi: 'नीम तेल 10000 ppm (30ml)', mr: 'निंबोळी तेल ३० मिली प्रति पंप', en: 'Neem oil 30ml/pump' },
      },
    ],
    bumperYieldSecrets: [
      {
        hi: 'शिखर छांटाई (Topping): 80 से 90 दिन पर जब पौधे की ऊंचाई 4.5 से 5 फीट हो जाए, तो ऊपर का मुख्य शेंडा (1 इंच) काट दें। इससे पौधा ऊपर नहीं भागेगा और साइड में 20 से 30 नई शाखाएं और बोंड फूटेंगे!',
        mr: 'शेंडा खुडणे (Topping): कापूस ८०-९० दिवसांचा झाल्यावर मुख्य शेंडा १ इंच खुडावा. यामुळे झाडाची वाढ फांद्यांकडे वळून बोंडांची संख्या दुप्पट होते.',
        en: 'Nipping the terminal shoot (topping) at 85 days diverts energy to side branches and doubles boll count.',
      },
      {
        hi: 'फेरोमोन ट्रैप: गुलाबी सुंडी से बचने का सबसे सस्ता और अचूक तरीका है 45 दिन पर खेत में फेरोमोन ट्रैप लगाना। नर पतंगे फंस जाते हैं और अंडे नहीं बन पाते।',
        mr: 'कामगंध सापळे: गुलाबी बोंडअळीसाठी ४५ व्या दिवशी एकरी ५ कामगंध सापळे लावा. अळीचा प्रादुर्भाव ७०% कमी होतो.',
        en: 'Pheromone traps break reproduction cycle of pink bollworm.',
      },
    ],
    harvestingAndGrading: {
      hi: 'जब बोंड पूरी तरह खिल जाए, तब तेज धूप में दोपहर को ही कपास चुनें ताकि ओस की नमी न रहे। पत्ती और कचरा न आने दें, सफेद चमकदार कपास का 500 रु प्रति क्विंटल अधिक भाव मिलता है।',
      mr: 'दुपारी ऊन पडल्यावरच वेचणी करावी जेणेकरून कापसात ओलावा राहणार नाही. पालापाचोळा वेगळा ठेवावा. स्वच्छ व पांढऱ्याशुभ्र कापसाला चांगला बाजारभाव मिळतो.',
      en: 'Pick dry cotton during sunny afternoons. Keep leaf trash out for premium APMC pricing.',
    },
  },

  // ================= WHEAT (गहू / गेहूं) =================
  {
    id: 'wheat',
    name: { hi: 'गेहूं (Wheat)', mr: 'गहू (Wheat - रब्बी सम्राट)', en: 'Wheat' },
    tagline: {
      hi: 'प्रति एकड़ 22 से 28 क्विंटल गेहूं पैदावार व 6 पानी का वैज्ञानिक कैलेंडर',
      mr: 'एकर २२ ते २५ क्विंटल भरघोस गहू उत्पादनासाठी पाणी व खत नियोजन गाईड',
      en: 'Scientific wheat management for 22-28 quintals/acre yield',
    },
    category: 'grains',
    durationDays: '110-120 दिवस (Days)',
    expectedYieldPerAcre: {
      hi: '22 - 28 क्विंटल प्रति एकड़ (शरबती व 1544 उत्तम किस्में)',
      mr: '२० - २५ क्विंटल प्रति एकर',
      en: '22 - 28 quintals per acre',
    },
    soilAndClimate: {
      hi: 'मध्यम से भारी दोमट या काली मिट्टी। ठंडा व शुष्क मौसम।',
      mr: 'मध्यम ते भारी, कसदार जमीन. थंडीचे प्रमाण चांगले असल्यास उत्पादन वाढते.',
      en: 'Medium to heavy loam or clay soil. Cool dry winter.',
    },
    bestVarieties: {
      hi: ['GW-496', 'GW-322', 'लोकवान (Lokwan - सबसे लोकप्रिय)', 'पूसा तेजस (HI-8759)', 'शरबती गेहूं C-306'],
      mr: ['समाधान (NIAW-१९९४ - प्रचंड उत्पादन)', 'त्र्यंबक (NIAW-३०१)', 'गोदावरी', 'लोकवान (Lokwan)', 'GW-४९६'],
      en: ['Samadhan (NIAW-1994)', 'GW-322', 'Lokwan', 'Pusa Tejas'],
    },
    landPreparation: {
      hi: ['खेत को 2 बार जोतकर पाटा लगाकर समतल करें। प्रति एकड़ 4 ट्रॉली गोबर खाद + 1 बोरी डीएपी बेसल में दें।'],
      mr: ['जमीन चांगली नांगरून भुसभुशीत व सपाट करा. पेरणीच्या वेळी एकरी १ बॅग DAP + अर्धी बॅग पोटॅश टाका.'],
      en: ['Plow, plank, and level. Apply 1 bag DAP + 25kg MOP at sowing.'],
    },
    spacingAndPlanting: {
      hi: 'कतार से कतार 20 सेमी (8 इंच)। बीज दर: 40 किलो प्रति एकड़। 15 नवंबर से 30 नवंबर का समय बुआई के लिए सबसे उत्तम है।',
      mr: 'दोन ओळींत २० ते २२ सेंमी अंतर. एकरी बियाणे: ४० किलो. १५ नोव्हेंबर ते ३० नोव्हेंबर दरम्यान पेरणी सर्वोत्तम.',
      en: '20cm row spacing. Seed rate 40kg/acre. Optimal sowing Nov 15-30.',
    },
    irrigationSchedule: [
      {
        stage: { hi: 'CRI स्टेज (मुकुट जड़ निकलने पर)', mr: 'मुकुट मुळे फुटण्याची वेळ (CRI Stage)', en: 'Crown Root Initiation (CRI)' },
        timing: '20 - 22 दिवस',
        frequency: { hi: 'यह गेहूं का सबसे महत्वपूर्ण पानी है! एक दिन भी लेट न करें!', mr: 'हा गव्हाचा सर्वात महत्त्वाचा पाणी टप्पा आहे. अजिबात उशीर करू नका!', en: 'Most critical irrigation! Never delay.' },
        waterDetails: { hi: 'इस समय पानी न मिलने पर कल्ले (Tillers) नहीं फूटते और पैदावार 30% घट जाती है।', mr: 'या वेळी पाणी न मिळाल्यास फुटवे फुटत नाहीत व उत्पादन ३०% घटते.', en: 'Determines total productive tillers.' },
        criticalWarning: { hi: 'पानी देने के 3 दिन बाद प्रति एकड़ 35 किलो यूरिया बुरकें।', mr: 'पाणी दिल्यावर एकरी ३५ किलो युरिया फेकून द्या.', en: 'Top dress 35kg Urea after this irrigation.' },
      },
      {
        stage: { hi: 'कल्ले फूटने का समय (Tillering)', mr: 'फुटवे फुटण्याची वेळ (४० ते ४५ दिवस)', en: 'Tillering Stage (Day 40-45)' },
        timing: '40 - 45 दिवस',
        frequency: { hi: 'दूसरी सिंचाई', mr: 'दुसरे पाणी', en: 'Second irrigation' },
        waterDetails: { hi: 'पौधे की तेजी से बढ़वार होती है।', mr: 'जोमदार वाढीसाठी आवश्यक.', en: 'Boosts vegetative growth.' },
        criticalWarning: { hi: 'खरपतवार हों तो 30 दिन पर सल्फोसल्फ्यूरॉन का छिड़काव करें।', mr: 'तण असल्यास पेरणीनंतर ३० दिवसांनी तणनाशक फवारा.', en: 'Spray weedicide around 30 days.' },
      },
      {
        stage: { hi: 'गांठे बनने का समय (Jointing)', mr: 'कांडी अवस्था (६० ते ६५ दिवस)', en: 'Jointing Stage (Day 60-65)' },
        timing: '60 - 65 दिवस',
        frequency: { hi: 'तीसरी सिंचाई', mr: 'तिसरे पाणी', en: 'Third irrigation' },
        waterDetails: { hi: 'तने में गांठें बनती हैं।', mr: 'खोडाला कांडी धरताना पाणी द्यावे.', en: 'Stem elongation phase.' },
        criticalWarning: { hi: 'तेज हवा में पानी न दें, गेहूं गिर सकता है।', mr: 'वारा शांत असतानाच पाणी द्या, गहू लोळू नये.', en: 'Avoid irrigating during high winds.' },
      },
      {
        stage: { hi: 'बालियां निकलने का समय (Booting/Flowering)', mr: 'लोंब्या बाहेर पडताना (७५ ते ८० दिवस)', en: 'Booting / Heading (Day 75-80)' },
        timing: '75 - 80 दिवस',
        frequency: { hi: 'चौथी अत्यंत महत्वपूर्ण सिंचाई', mr: 'चौथे अत्यंत महत्त्वाचे पाणी', en: 'Fourth crucial irrigation' },
        waterDetails: { hi: 'बाली लंबी बनने और दानों की संख्या तय होने का समय।', mr: 'या वेळी पाण्याचा ताण पडल्यास लोंबी आखूड राहते.', en: 'Determines earhead length and grains per ear.' },
        criticalWarning: { hi: '0:52:34 का छिड़काव करें।', mr: '०:५२:३४ (७५ ग्रॅम/पंप) फवारा.', en: 'Spray 0:52:34 for bold earheads.' },
      },
      {
        stage: { hi: 'दूधिया अवस्था (Milking)', mr: 'दाण्यात चीक भरताना (९० ते ९५ दिवस)', en: 'Milking Stage (Day 90-95)' },
        timing: '90 - 95 दिवस',
        frequency: { hi: 'पांचवी सिंचाई (हल्का पानी)', mr: 'पाचवे हलके पाणी', en: 'Fifth light irrigation' },
        waterDetails: { hi: 'दाने में दूध भरता है।', mr: 'दाणा भरण्यासाठी पाणी आवश्यक.', en: 'Grain filling.' },
        criticalWarning: { hi: 'भारी पानी न दें।', mr: 'जास्त पाणी देऊ नका.', en: 'Light water only.' },
      },
      {
        stage: { hi: 'दाना पकने का समय (Dough)', mr: 'दाणा कडक होताना (१०५ दिवस)', en: 'Dough Stage (Day 105)' },
        timing: '105 दिवस',
        frequency: { hi: 'अंतिम हल्की सिंचाई (यदि तापमान अधिक हो)', mr: 'शेवटचे हलके पाणी (उष्णता वाढल्यास)', en: 'Final irrigation if hot weather' },
        waterDetails: { hi: 'दाना मोटा व वजनदार बनता है।', mr: 'दाणा टपोरा व वजनदार होतो.', en: 'Final test weight enhancement.' },
        criticalWarning: { hi: 'कटाई से 12 दिन पहले पानी बंद करें।', mr: 'कापणीच्या १० दिवस आधी पाणी बंद करावे.', en: 'Stop 10 days before harvest.' },
      },
    ],
    fertilizerSchedule: [
      {
        stage: { hi: 'बुआई के समय', mr: 'पेरणीच्या वेळी', en: 'Basal at Sowing' },
        timing: 'दिवस 0',
        fertilizerDose: {
          hi: 'डीएपी (50 किलो) + पोटाश (25 किलो) + यूरिया (25 किलो) प्रति एकड़',
          mr: 'DAP (५० किलो) + पोटॅश (२५ किलो) + युरिया (२५ किलो) एकरी',
          en: 'DAP 50kg + MOP 25kg + Urea 25kg per acre',
        },
        howToApply: { hi: 'बीज के साथ ड्रिल करें।', mr: 'पेरणी यंत्राने पेरावे.', en: 'Drill with seed.' },
      },
      {
        stage: { hi: 'पहली सिंचाई के बाद (22 दिन)', mr: 'पहिल्या पाण्यानंतर (२२ दिवस)', en: 'After 1st Irrigation (Day 22)' },
        timing: '22 दिवस',
        fertilizerDose: {
          hi: 'यूरिया (35 किलो) + जिंक सल्फेट 33% (5 किलो) प्रति एकड़',
          mr: 'युरिया (३५ किलो) + झिंक सल्फेट (५ किलो) एकरी',
          en: 'Urea 35kg + Zinc Sulphate 5kg per acre',
        },
        howToApply: { hi: 'हल्की नमी में खेत में बुरकें।', mr: 'वाफसा असताना फेकून द्यावे.', en: 'Broadcasting in moist soil.' },
      },
    ],
    spraySchedule: [
      {
        stage: { hi: 'खरपतवार नियंत्रण', mr: 'तण नियंत्रण', en: 'Weed Management' },
        timing: '30 - 35 दिवस',
        targetPestOrDisease: { hi: 'चौड़ी व संकरी पत्ती के खरपतवार (मंडूसी, बथुआ)', mr: 'गव्हातील गवत व रुंद पानांचे तण', en: 'Broad and narrow leaf weeds' },
        recommendedMedicine: { hi: 'सल्फोसल्फ्यूरॉन 75% + मेटसल्फ्यूरॉन 5% (टोटल) 16 ग्राम प्रति एकड़', mr: 'सल्फोसल्फ्यूरॉन (१६ ग्रॅम एकरी) फवारा', en: 'Sulfosulfuron + Metsulfuron 16g/acre' },
        dosePerPump: '150 लीटर पानी में 1 एकड़ स्प्रे करें',
        organicOption: { hi: 'खुरपी से 25 दिन पर निराई-गुड़ाई', mr: 'खुरपणी करून तण काढावे', en: 'Manual weeding at 25 days' },
      },
    ],
    bumperYieldSecrets: [
      {
        hi: 'CRI स्टेज का नियम: 21 दिन पर मुकुट जड़ें फूटती हैं। यह पानी 2 दिन भी लेट हुआ तो कल्ले आधे रह जाएंगे और पैदावार कभी 20 क्विंटल नहीं पहुंचेगी।',
        mr: '२१ व्या दिवसाचा नियम: २१ व्या दिवशी मुकुट मुळे फुटतात. या दिवशी दिलेले पाणी गव्हाचे उत्पादन ठरवते.',
        en: 'The 21-day CRI watering is non-negotiable for bumper tillering.',
      },
    ],
    harvestingAndGrading: {
      hi: 'जब बालियां सुनहरी पीली हो जाएं और दाना दांत से दबाने पर कट की आवाज करे, तब कंबाइन या रीपर से कटाई करें।',
      mr: 'लोंब्या सोनेरी पिवळ्या झाल्यावर आणि दाणा दाताखाली दाबल्यावर ‘कट’ असा आवाज आल्यावर कापणी करावी.',
      en: 'Harvest when moisture is 12% and grain breaks crisply under tooth pressure.',
    },
  },
];
