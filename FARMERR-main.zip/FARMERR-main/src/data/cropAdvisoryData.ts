import { CropGuide } from '../types';

export const CROP_ADVISORY_DATA: CropGuide[] = [
  {
    id: 'crop-wheat',
    name: {
      hi: 'गेहूं (Wheat)',
      mr: 'गहू (Wheat)',
      en: 'Wheat',
    },
    season: 'rabi',
    sowingMonths: {
      hi: '15 नवंबर से 30 नवंबर (अगेती/समय पर)',
      mr: '१५ नोव्हेंबर ते ३० नोव्हेंबर (वेळेवर पेरणी)',
      en: '15th Nov to 30th Nov',
    },
    seedRate: {
      hi: '40 से 45 किलोग्राम प्रति एकड़ (समय पर बुआई)',
      mr: '४० ते ४५ किलो प्रति एकर',
      en: '40 - 45 kg per acre',
    },
    seedTreatment: {
      hi: 'कार्बेंडाजिम 2g + थायरम 2g प्रति किलो बीज, या ट्राइकोडर्मा 5g/किलो',
      mr: 'कार्बेंडाझिम २ ग्रॅम किंवा ट्रायकोडर्मा ५ ग्रॅम प्रति किलो बियाणे',
      en: 'Carbendazim 2g + Thiram 2g or Trichoderma 5g per kg seed',
    },
    fertilizerDose: {
      hi: 'DAP: 50 kg (1 बैग) + यूरिया: 65 kg (दो बार में) + MOP पोटाश: 20 kg प्रति एकड़',
      mr: 'डीएपी: ५० किलो + युरिया: ६५ किलो + पोटॅश: २० किलो प्रति एकर',
      en: 'DAP: 50 kg + Urea: 65 kg (split) + MOP: 20 kg per acre',
    },
    irrigationSchedule: {
      hi: [
        '1. पहली सिंचाई (CRI अवस्था): बुआई के 20-22 दिन बाद (सबसे महत्वपूर्ण)',
        '2. दूसरी सिंचाई (कल्ले फूटते समय): 40-45 दिन बाद',
        '3. तीसरी सिंचाई (गांठ बनते समय): 60-65 दिन बाद',
        '4. चौथी सिंचाई (फूल आते समय): 80-85 दिन बाद',
        '5. पांचवी सिंचाई (दूधिया अवस्था): 100-105 दिन बाद',
      ],
      mr: [
        '१. पहिले पाणी (मुकुट मुळे फुटताना): पेरणीनंतर २० ते २२ दिवसांनी (अतिशय महत्त्वाचे)',
        '२. दुसरे पाणी (फुटवे येताना): ४० ते ४५ दिवसांनी',
        '३. तिसरे पाणी (कांडी धरताना): ६० ते ६५ दिवसांनी',
        '४. चौथे पाणी (फुलोऱ्यात असताना): ८० ते ८५ दिवसांनी',
        '५. पाचवे पाणी (दाण्यात चिकाची अवस्था): १०० ते १०५ दिवसांनी',
      ],
      en: [
        '1st Irrigation (CRI Stage): 20-22 days after sowing (Most Critical)',
        '2nd Irrigation (Tillering): 40-45 days after sowing',
        '3rd Irrigation (Jointing): 60-65 days after sowing',
        '4th Irrigation (Flowering): 80-85 days after sowing',
        '5th Irrigation (Milking): 100-105 days after sowing',
      ],
    },
    expectedYield: {
      hi: '20 से 24 क्विंटल प्रति एकड़ (उन्नत किस्में)',
      mr: '२० ते २४ क्विंटल प्रति एकर',
      en: '20 - 24 Quintals per acre',
    },
    topTip: {
      hi: 'पहली सिंचाई के समय खेत में पानी जमा न रहने दें, और पहली सिंचाई के तुरंत बाद 30 किलो यूरिया का छिड़काव करें।',
      mr: 'पहिल्या पाण्याच्या वेळी शेतात पाणी साचणार नाही याची काळजी घ्या व नंतर ३० किलो युरिया द्या.',
      en: 'Do not allow water-logging during CRI stage; apply 30kg Urea immediately after 1st watering.',
    },
  },
  {
    id: 'crop-soybean',
    name: {
      hi: 'सोयाबीन (Soybean)',
      mr: 'सोयाबीन (Soybean)',
      en: 'Soybean',
    },
    season: 'kharif',
    sowingMonths: {
      hi: '15 जून से 15 जुलाई (75-100 mm बारिश होने पर)',
      mr: '१५ जून ते १५ जुलै (७५ ते १०० मिमी पाऊस झाल्यावर)',
      en: '15th June to 15th July',
    },
    seedRate: {
      hi: '25 से 30 किलोग्राम प्रति एकड़ (उचित दूरी 45x5 सेमी)',
      mr: '२५ ते ३० किलो प्रति एकर (४५ × ५ सेमी अंतर)',
      en: '25 - 30 kg per acre',
    },
    seedTreatment: {
      hi: 'राइजोबियम कल्चर (200g) + PSB (200g) प्रति 10 किलो बीज',
      mr: 'रायझोबियम (२०० ग्रॅम) + PSB (२०० ग्रॅम) जिवाणू संवर्धन',
      en: 'Rhizobium Culture (200g) + PSB (200g) per 10kg seed',
    },
    fertilizerDose: {
      hi: 'DAP: 35 kg + MOP पोटाश: 15 kg + सल्फर (बेंटोनाइट): 10 kg बुआई के समय',
      mr: 'डीएपी: ३५ किलो + पोटॅश: १५ किलो + गंधक (सल्फर): १० किलो',
      en: 'DAP: 35 kg + MOP: 15 kg + Sulphur: 10 kg at sowing',
    },
    irrigationSchedule: {
      hi: [
        '1. फूल आने के समय (बुआई के 35-40 दिन बाद) नमी की कमी न होने दें',
        '2. फलियों में दाना भरते समय (65-70 दिन बाद) यदि बारिश न हो तो स्प्रिंकलर से पानी दें',
      ],
      mr: [
        '१. फुलोरा अवस्थेत (पेरणीनंतर ३५-४० दिवस) जमिनीत पुरेसा ओलावा असावा',
        '२. शेंगांमध्ये दाणे भरताना (६५-७० दिवस) पाऊस नसेल तर तुषार सिंचनाने पाणी द्या',
      ],
      en: [
        'Critical flowering phase (35-40 DAS): Ensure adequate soil moisture',
        'Pod-filling phase (65-70 DAS): Give protective irrigation via sprinkler if dry spell',
      ],
    },
    expectedYield: {
      hi: '10 से 14 क्विंटल प्रति एकड़',
      mr: '१० ते १४ क्विंटल प्रति एकर',
      en: '10 - 14 Quintals per acre',
    },
    topTip: {
      hi: 'सोयाबीन को कभी भी 3-4 सेमी से ज्यादा गहरा न बोएं, वरना अंकुरण कम हो जाता है।',
      mr: 'सोयाबीनची पेरणी ३ ते ४ सेंमीपेक्षा जास्त खोल करू नका, अन्यथा उगवण क्षमता घटते.',
      en: 'Never sow soybean deeper than 3-4 cm to ensure maximum seed germination.',
    },
  },
  {
    id: 'crop-onion',
    name: {
      hi: 'प्याज (कांदा / Onion)',
      mr: 'कांदा (Onion)',
      en: 'Onion',
    },
    season: 'rabi',
    sowingMonths: {
      hi: 'रबी प्याज: नवंबर से दिसंबर रोपाई (नर्सरी अक्टूबर)',
      mr: 'रब्बी कांदा: नोव्हेंबर-डिसेंबर पुनर्लागवड (रोपवाटिका ऑक्टोबर)',
      en: 'Nov - Dec Transplanting',
    },
    seedRate: {
      hi: '3 से 4 किलोग्राम प्रति एकड़ (नर्सरी के लिए)',
      mr: '३ ते ४ किलो प्रति एकर (रोप तयार करण्यासाठी)',
      en: '3 - 4 kg per acre',
    },
    seedTreatment: {
      hi: 'कार्बेंडाजिम 2g प्रति किलो बीज, रोपाई से पहले जड़ों को फफूंदनाशक में डुबोएं',
      mr: 'कार्बेंडाझिम २ ग्रॅम/किलो, पुनर्लागवडीवेळी रोपांची मुळे बुडवून घेणे',
      en: 'Carbendazim 2g/kg seed; dip seedling roots in fungicide before planting',
    },
    fertilizerDose: {
      hi: 'यूरिया: 45 kg + DAP: 50 kg + पोटाश: 40 kg + सल्फर: 15 kg प्रति एकड़',
      mr: 'युरिया: ४५ किलो + डीएपी: ५० किलो + पोटॅश: ४० किलो + सल्फर: १५ किलो',
      en: 'Urea: 45 kg + DAP: 50 kg + Potash: 40 kg + Sulphur: 15 kg per acre',
    },
    irrigationSchedule: {
      hi: [
        '1. रोपाई के तुरंत बाद हल्की सिंचाई करें',
        '2. कंद बनने तक 8-10 दिन के अंतर पर पानी दें',
        '3. खुदाई से 15 दिन पहले सिंचाई पूरी तरह बंद कर दें ताकि प्याज सड़े नहीं',
      ],
      mr: [
        '१. लागवडीनंतर लगेच हलके पाणी (आंबवणी) द्या',
        '२. कांदा पोसताना ८ ते १० दिवसांच्या अंतराने नियमित पाणी द्या',
        '३. काढणीपूर्वी १५ दिवस अगोदर पाणी पूर्णपणे बंद करा जेणेकरून कांदा टिकेल',
      ],
      en: [
        '1. Light irrigation immediately upon transplanting',
        '2. Regular irrigation at 8-10 day intervals during bulb enlargement',
        '3. Completely stop watering 15 days before harvest to ensure long storage life',
      ],
    },
    expectedYield: {
      hi: '120 से 150 क्विंटल प्रति एकड़',
      mr: '१२० ते १५० क्विंटल प्रति एकर',
      en: '120 - 150 Quintals per acre',
    },
    topTip: {
      hi: 'प्याज के चमकदार रंग और वजन के लिए कंद बनने की अवस्था में 00:00:50 (पोटाश) का 5 ग्राम/लीटर छिड़काव करें।',
      mr: 'कांद्याचा रंग व आकार वाढवण्यासाठी कांदा पोसताना 00:00:50 खताची ५ ग्रॅम/लिटर फवारणी करा.',
      en: 'Foliar spray of 00:00:50 (Potash) @ 5g/Litre during bulb swelling enhances gloss and shelf life.',
    },
  },
  {
    id: 'crop-cotton',
    name: {
      hi: 'कपास (कापूस / Cotton)',
      mr: 'कापूस (Cotton)',
      en: 'Cotton',
    },
    season: 'kharif',
    sowingMonths: {
      hi: 'मई के अंतिम सप्ताह से जून का तीसरा सप्ताह',
      mr: 'मे अखेर ते जूनचा तिसरा आठवडा',
      en: 'Late May to June 3rd week',
    },
    seedRate: {
      hi: '1.5 से 2 पैकेट (450 ग्राम प्रति पैकेट) प्रति एकड़',
      mr: '१.५ ते २ पाकिटे प्रति एकर (४५० ग्रॅम पाकीट)',
      en: '1.5 - 2 packets per acre',
    },
    seedTreatment: {
      hi: 'इमिडाक्लोप्रिड 70 WS (5g/kg) रस चूसक कीटों से 40 दिन तक बचाव करता है',
      mr: 'इमिडाक्लोप्रिड ७० WS (५ ग्रॅम/किलो) सुरुवातीच्या किडीपासून संरक्षणासाठी',
      en: 'Imidacloprid 70 WS @ 5g/kg seed protects from sucking pests for 40 days',
    },
    fertilizerDose: {
      hi: 'यूरिया: 80 kg (3 बार में) + DAP: 50 kg + MOP: 40 kg + मैग्नीशियम सल्फेट: 10 kg',
      mr: 'युरिया: ८० किलो (३ हप्त्यांत) + डीएपी: ५० किलो + पोटॅश: ४० किलो + मॅग्नेशियम सल्फेट: १० किलो',
      en: 'Urea: 80 kg (in 3 splits) + DAP: 50 kg + MOP: 40 kg + MgSO4: 10 kg',
    },
    irrigationSchedule: {
      hi: [
        '1. चौड़े पाटे / ड्रिप विधि से 12-15 दिन के अंतराल पर सिंचाई',
        '2. फूल व बोंड बनते समय पानी की कमी न होने दें (ड्रॉपिंग रोकें)',
      ],
      mr: [
        '१. ठिबक सिंचनाने किंवा सरी पद्धतीने गरजेनुसार पाणी द्या',
        '२. पात्या व बोंडे धरताना पाण्याचा ताण पडू देऊ नका, अन्यथा पातीगळ होते',
      ],
      en: [
        '1. Drip irrigation or furrow method every 12-15 days based on soil moisture',
        '2. Prevent water stress during squaring and boll bursting to prevent shedding',
      ],
    },
    expectedYield: {
      hi: '10 से 15 क्विंटल प्रति एकड़ (सिंचित)',
      mr: '१० ते १५ क्विंटल प्रति एकर (बागायती)',
      en: '10 - 15 Quintals per acre',
    },
    topTip: {
      hi: 'गुलाबी सुंडी से बचाव के लिए 80 दिन बाद कपास की ऊपरी 1-2 इंच की चोटी (Top nip) तोड़ दें।',
      mr: 'गुलाबी बोंडअळी रोखण्यासाठी ८०-९० दिवसांनी कापसाचे शेंडे (Top shoot) खुडावेत.',
      en: 'Nip top shoots (2 inches) after 80-90 days to suppress bollworm egg laying and induce branching.',
    },
  },
  {
    id: 'crop-gram',
    name: {
      hi: 'चना / हरभरा (Chickpea / Gram)',
      mr: 'हरभरा / चना (Gram)',
      en: 'Gram (Chickpea)',
    },
    season: 'rabi',
    sowingMonths: {
      hi: '10 अक्टूबर से 15 नवंबर',
      mr: '१० ऑक्टोबर ते १५ नोव्हेंबर',
      en: '10th Oct to 15th Nov',
    },
    seedRate: {
      hi: '30 से 35 किलो (देशी चना), 40 से 50 किलो (काबुली/फुले विक्रम)',
      mr: '३० ते ३५ किलो (देशी), ४० ते ५० किलो (फुले विक्रम / काबुली)',
      en: '30 - 35 kg per acre',
    },
    seedTreatment: {
      hi: 'ट्राइकोडर्मा 5g + राइजोबियम 10g प्रति किलो बीज',
      mr: 'ट्रायकोडर्मा ५ ग्रॅम + रायझोबियम जीवाणू संवर्धन',
      en: 'Trichoderma 5g + Rhizobium 10g per kg seed',
    },
    fertilizerDose: {
      hi: 'DAP: 35 kg + पोटाश: 15 kg + सल्फर: 10 kg (यूरिया अलग से न दें)',
      mr: 'डीएपी: ३५ किलो + पोटॅश: १५ किलो + गंधक: १० किलो (युरिया जास्त देऊ नका)',
      en: 'DAP: 35 kg + MOP: 15 kg + Sulphur: 10 kg (Avoid excess Urea)',
    },
    irrigationSchedule: {
      hi: [
        '1. बुआई के 30-35 दिन बाद (शाखाएं निकलते समय)',
        '2. फलियों में दाना भरते समय (60-65 दिन बाद). फूल आते समय कभी पानी न दें!',
      ],
      mr: [
        '१. पेरणीनंतर ३० ते ३५ दिवसांनी (फांद्या फुटताना)',
        '२. घाटे भरताना (६० ते ६५ दिवसांनी). फुलोऱ्यात असताना पाणी देणे टाळा!',
      ],
      en: [
        '1st: 30-35 DAS during branching stage',
        '2nd: 60-65 DAS during pod filling. Never irrigate during full bloom!',
      ],
    },
    expectedYield: {
      hi: '8 से 12 क्विंटल प्रति एकड़',
      mr: '८ ते १२ क्विंटल प्रति एकर',
      en: '8 - 12 Quintals per acre',
    },
    topTip: {
      hi: 'चने में जब 30-35 दिन पर पौधे 6-8 इंच के हों, तो ऊपर की कोमल पत्तियां (खुंटाई) तोड़ लें, इससे शाखाएं दोगुनी हो जाती हैं।',
      mr: 'पेरणीनंतर ३०-३५ दिवसांनी हरभऱ्याचे शेंडे खुडल्यास (खुंटणी) जास्त फुटवे येऊन उत्पादन वाढते.',
      en: 'Nipping the terminal tender shoots at 30-35 days induces heavy branching and increases pod count.',
    },
  },
  {
    id: 'crop-banana',
    name: {
      hi: 'केला (Banana - जी-9)',
      mr: 'केळी (Banana - ग्रँड नैन G-9)',
      en: 'Banana (Grand Naine)',
    },
    season: 'zaid',
    sowingMonths: {
      hi: 'जून से जुलाई (मृग बाग) अथवा अक्टूबर-नवंबर',
      mr: 'जून ते जुलै (मृग बाग) किंवा ऑक्टोबर-नोव्हेंबर',
      en: 'June - July or Oct - Nov',
    },
    seedRate: {
      hi: '1,400 से 1,500 टिश्यू कल्चर पौधे प्रति एकड़ (6x5 फीट दूरी)',
      mr: '१,४०० ते १,५०० टिशू कल्चर रोपे प्रति एकर (६×५ किंवा ५×५ फूट)',
      en: '1,400 - 1,500 tissue plants / acre',
    },
    seedTreatment: {
      hi: 'रोपण पूर्व जड़ों को कार्बेंडाजिम (2g) + क्लोरोपायरीफॉस (2ml/L) घोल में 10 मिनट डुबोएं',
      mr: 'लागवडीपूर्वी रोपांची मुळे कार्बेन्डाझिम २ ग्रॅम + क्लोरपायरीफॉस २ मिली/लिटर द्रावणात बुडवा',
      en: 'Dip plantlets in Carbendazim 2g + Chlorpyrifos 2ml per liter for 10 minutes',
    },
    fertilizerDose: {
      hi: 'प्रति पौधा: यूरिया 200g + DAP 100g + पोटाश 300g (ड्रिप से किस्तों में दें)',
      mr: 'प्रति झाड: युरिया २०० ग्रॅम + डीएपी १०० ग्रॅम + पोटॅश ३०० ग्रॅम (ठिबकमधून विभागून)',
      en: 'Per plant: Urea 200g + DAP 100g + MOP 300g via fertigation',
    },
    irrigationSchedule: {
      hi: [
        '1. ड्रिप से प्रतिदिन मौसम अनुसार 15 से 22 लीटर पानी प्रति पौधा दें',
        '2. घार (Bunch) बाहर आते समय पानी की कमी न होने दें',
      ],
      mr: [
        '१. ठिबक सिंचनाने दररोज १५ ते २० लिटर पाणी प्रति झाड द्या',
        '२. केळीचा घड निसवताना पाण्याचा ताण अजिबात पडू देऊ नका',
      ],
      en: [
        '1. Drip irrigation supplying 15-22 liters/plant daily based on temperature',
        '2. Strictly prevent water stress during bunch emergence',
      ],
    },
    expectedYield: {
      hi: '30 से 35 टन प्रति एकड़ (प्रति घार 25-30 किलो)',
      mr: '३० ते ३५ टन प्रति एकर (प्रति घड २५-३० किलो वजन)',
      en: '30 - 35 Tonnes per acre',
    },
    topTip: {
      hi: 'घार पूरा निकलने के बाद नीचे का नर फूल (कमल) तोड़ दें और नीली पॉलीथिन (Skirting bag) ढकें जिससे केले पर दाग न आएं।',
      mr: 'घड पूर्ण बाहेर आल्यावर खालचे नर फूल (कमळ) तोडा आणि निळी स्कर्टिंग बॅग लावा, केळी चमकदार व डागमुक्त राहते.',
      en: 'Remove terminal male bud (denavelling) and cover with blue skirting bags for export-grade spot-free fruit.',
    },
  },
  {
    id: 'crop-papaya',
    name: {
      hi: 'पपीता (Papaya - रेड लेडी 786)',
      mr: 'पपई (Papaya - तैवान ७८६)',
      en: 'Papaya (Taiwan Red Lady 786)',
    },
    season: 'kharif',
    sowingMonths: {
      hi: 'फरवरी-मार्च अथवा जून-जुलाई रोपाई',
      mr: 'फेब्रुवारी-मार्च किंवा जून-जुलै पुनर्लागवड',
      en: 'Feb - March or June - July',
    },
    seedRate: {
      hi: '900 से 1,000 पौधे प्रति एकड़ (7x7 या 6x6 फीट दूरी)',
      mr: '९०० ते १,००० रोपे प्रति एकर (७×७ किंवा ६×६ फूट अंतर)',
      en: '900 - 1,000 plants per acre',
    },
    seedTreatment: {
      hi: 'ट्राइकोडर्मा 5g/लीटर घोल में रोपों की जड़ों को 15 मिनट भिगोकर लगाएं',
      mr: 'ट्रायकोडर्मा ५ ग्रॅम/लिटर पाण्यात रोपांची मुळे १५ मिनिटे भिजवून लावा',
      en: 'Dip seedling root ball in Trichoderma 5g/Litre water',
    },
    fertilizerDose: {
      hi: 'प्रति पौधा: DAP 100g + यूरिया 150g + पोटाश 200g + बोरोन 5g + मैग्नीशियम 20g',
      mr: 'प्रति झाड: डीएपी १०० ग्रॅम + युरिया १५० ग्रॅम + पोटॅश २०० ग्रॅम + बोरॉन ५ ग्रॅम',
      en: 'Per plant: DAP 100g + Urea 150g + Potash 200g + Boron 5g',
    },
    irrigationSchedule: {
      hi: [
        '1. सदैव बेड (गादी वाफा) पर लगाएं, तने के पास पानी नहीं लगना चाहिए',
        '2. ड्रिप से 2 दिन में एक बार 10-12 लीटर पानी दें',
      ],
      mr: [
        '१. नेहमी उंच गादीवाफ्यावर (Bed) लावा, खोडाला पाणी थेट लागू देऊ नका',
        '२. ठिबक सिंचनाने एक दिवसाआड १०-१२ लिटर पाणी द्या',
      ],
      en: [
        '1. Plant strictly on raised beds; water must never touch the trunk base directly',
        '2. Drip irrigate 10-12 liters every alternate day',
      ],
    },
    expectedYield: {
      hi: '28 से 35 टन प्रति एकड़ (प्रति पौधा 40-50 किलो)',
      mr: '२८ ते ३५ टन प्रति एकर (प्रति झाड ४०-५० किलो फळे)',
      en: '28 - 35 Tonnes per acre',
    },
    topTip: {
      hi: 'पपीता रिंग स्पॉट वायरस से बचाव के लिए खेत के चारों ओर मक्का लगाएं और सफेद मक्खी/माहू के लिए पीला चिपचिपा ट्रैप लगाएं।',
      mr: 'पपईच्या रिंग स्पॉट व्हायरसपासून बचावासाठी शेताभोवती मक्याची बॉर्डर लावा व पिवळे चिकट सापळे लावा.',
      en: 'Plant border rows of maize to prevent PRSV virus transmission by aphids and install yellow sticky traps.',
    },
  },
  {
    id: 'crop-tomato-adv',
    name: {
      hi: 'टमाटर (Tomato - उन्नत संकर)',
      mr: 'टोमॅटो (Tomato - संकरित)',
      en: 'Tomato (Hybrid)',
    },
    season: 'rabi',
    sowingMonths: {
      hi: 'रबी: अक्टूबर-नवंबर | खरीफ: जून-जुलाई | जायद: फरवरी',
      mr: 'रब्बी: ऑक्टोबर-नोव्हेंबर | खरीप: जून-जुलै | उन्हाळी: फेब्रुवारी',
      en: 'Rabi: Oct-Nov | Kharif: June-July | Summer: Feb',
    },
    seedRate: {
      hi: '80 से 100 ग्राम प्रति एकड़ (नर्सरी द्वारा)',
      mr: '८० ते १०० ग्रॅम प्रति एकर (रोपवाटिका)',
      en: '80 - 100g per acre',
    },
    seedTreatment: {
      hi: 'इमिडाक्लोप्रिड 5ml + कार्बेंडाजिम 2g प्रति 100g बीज',
      mr: 'इमिडाक्लोप्रिड ५ मिली + कार्बेन्डाझिम २ ग्रॅम',
      en: 'Imidacloprid 5ml + Carbendazim 2g',
    },
    fertilizerDose: {
      hi: 'DAP 75 kg + यूरिया 65 kg + पोटाश 50 kg + कैल्शियम नाइट्रेट 25 kg प्रति एकड़',
      mr: 'डीएपी ७५ किलो + युरिया ६५ किलो + पोटॅश ५० किलो + कॅल्शियम नायट्रेट २५ किलो',
      en: 'DAP 75 kg + Urea 65 kg + MOP 50 kg + Calcium Nitrate 25 kg',
    },
    irrigationSchedule: {
      hi: [
        '1. ड्रिप से हर दूसरे दिन 2 घंटे सिंचाई करें',
        '2. फल पकते समय अत्यधिक सिंचाई से बचें ताकि फल फटे नहीं',
      ],
      mr: [
        '१. ठिबक सिंचनाने दररोज किंवा एक दिवसाआड २ तास पाणी द्या',
        '२. फळे लाल होताना अति पाणी देणे टाळा, अन्यथा फळे तडकतात',
      ],
      en: [
        '1. Drip irrigate 2 hours every alternate day',
        '2. Avoid flood irrigation during fruit ripening to prevent fruit cracking',
      ],
    },
    expectedYield: {
      hi: '25 से 35 टन प्रति एकड़ (1,200 से 1,500 क्रेट)',
      mr: '२५ ते ३५ टन प्रति एकर (१,२०० ते १,५०० क्रेट्स)',
      en: '25 - 35 Tonnes per acre',
    },
    topTip: {
      hi: 'टमाटर को बांस और सुतली से सहारा (Staking) जरूर दें, इससे फल सड़ते नहीं और पैदावार 40% तक बढ़ जाती है।',
      mr: 'टोमॅटोच्या झाडांना बांबू व तारेचा आधार (स्टेकिंग) नक्की द्या, फळे खराब होत नाहीत व उत्पादन ४०% वाढते.',
      en: 'Trellising with bamboo stakes prevents ground contact and fungal blights, elevating yields by 40%.',
    },
  },
  {
    id: 'crop-sugarcane-adv',
    name: {
      hi: 'गन्ना (Sugarcane - को 86032)',
      mr: 'ऊस (Sugarcane - को ८६०३२)',
      en: 'Sugarcane',
    },
    season: 'kharif',
    sowingMonths: {
      hi: 'अक्टूबर-नवंबर (शरदकालीन) अथवा फरवरी-मार्च (वसंतकालीन)',
      mr: 'ऑक्टोबर-नोव्हेंबर (पूर्वहंगामी) किंवा जानेवारी-फेब्रुवारी (सुरू)',
      en: 'Oct - Nov or Jan - Feb',
    },
    seedRate: {
      hi: '25,000 से 30,000 दो आंख वाले टुकड़े (टिपरी) प्रति एकड़',
      mr: '२५,००० ते ३०,००० दोन डोळ्यांची टिपरी प्रति एकर',
      en: '25,000 - 30,000 two-bud setts per acre',
    },
    seedTreatment: {
      hi: 'कार्बेंडाजिम 100g + क्लोरोपायरीफॉस 250ml को 100 लीटर पानी में घोलकर 10 मिनट बेना उपचार',
      mr: 'कार्बेन्डाझिम १०० ग्रॅम + क्लोरपायरीफॉस २५० मिली १०० लिटर पाण्यात १० मिनिटे बेणे प्रक्रिया',
      en: 'Dip setts in Carbendazim 100g + Chlorpyrifos 250ml in 100L water for 10 minutes',
    },
    fertilizerDose: {
      hi: 'यूरिया 280 kg + DAP 125 kg + पोटाश 90 kg (4 बराबर किस्तों में)',
      mr: 'युरिया २८० किलो + डीएपी १२५ किलो + पोटॅश ९० किलो (४ हप्त्यांत)',
      en: 'Urea 280 kg + DAP 125 kg + MOP 90 kg in 4 split doses',
    },
    irrigationSchedule: {
      hi: [
        '1. कल्ले निकलते समय (60-90 दिन) 8-10 दिन के अंतर पर पानी दें',
        '2. बढ़वार अवस्था में 10-12 दिन के अंतराल पर ड्रिप या नाली से सिंचाई',
      ],
      mr: [
        '१. फुटवे फुटताना (६०-९० दिवस) ८-१० दिवसांच्या अंतराने पाणी द्या',
        '२. कांडी भरताना नियमित पाणी द्यावे, पाण्याचा ताण पडू नये',
      ],
      en: [
        '1. Tillering phase (60-90 days): Irrigate at 8-10 day intervals',
        '2. Grand growth phase: Regular drip irrigation to maintain cane girth',
      ],
    },
    expectedYield: {
      hi: '60 से 80 टन प्रति एकड़',
      mr: '६० ते ८० टन प्रति एकर (उत्तम व्यवस्थापनात १००+ टन)',
      en: '60 - 80 Tonnes per acre',
    },
    topTip: {
      hi: 'बुआई के 120 दिन बाद गन्ने पर बड़ी मिट्टी चढ़ाना (Earthing up) अनिवार्य है, इससे गन्ना आंधी-तूफान में गिरता नहीं है।',
      mr: 'लागवडीनंतर १२० दिवसांनी उसाला मोठी बाळबांधणी (माती लावणे) नक्की करा, जेणेकरून ऊस लोळत नाही.',
      en: 'Perform major earthing-up at 120 days to anchor root clump and prevent crop lodging during high winds.',
    },
  },
];
