import { DiseaseItem } from '../types';

export const DISEASE_DATA: DiseaseItem[] = [
  {
    id: 'onion-thrips',
    crop: {
      hi: 'प्याज (कांदा)',
      mr: 'कांदा (Onion)',
      en: 'Onion',
    },
    name: {
      hi: 'प्याज में थ्रिप्स (फुलकिडे) और बैंगनी धब्बा (Purple Blotch)',
      mr: 'कांद्यावरील थ्रिप्स (फुलकिडे) व जांभळा करपा रोग',
      en: 'Onion Thrips & Purple Blotch Blight',
    },
    sampleImage: 'https://images.unsplash.com/photo-1618160702438-9b02ab6515c9?w=600&auto=format&fit=crop&q=80',
    symptoms: {
      hi: [
        'पत्तियों पर सफेद, चांदी जैसे चमकदार बारीक धब्बे दिखना',
        'पत्तियां ऊपर से सूखकर मुड़ने लगती हैं और पीली पड़ जाती हैं',
        'पत्तियों के बीच में बैंगनी रंग के गहरे धब्बे बनना',
      ],
      mr: [
        'पानांवर पांढुरके, चंदेरी रंगाचे बारीक ओरखडे दिसणे',
        'पानांची टोके पिवळी पडून वाळणे व पाने पिळवटणे',
        'पानांवर अंडाकृती जांभळट करपा रंगाचे डाग पडणे',
      ],
      en: [
        'Whitish-silvery streaks and minute spots on onion foliage',
        'Tips of leaves turn yellow and curl upwards',
        'Elliptical purple blotches developing on leaves and stalks',
      ],
    },
    organicTreatment: {
      hi: [
        '5% नीम का काढ़ा या 10,000 ppm नीम का तेल 2-3 मिली प्रति लीटर पानी में मिलाकर छिड़कें',
        'खेत में प्रति एकड़ 20 नीले और पीले चिपचिपे कार्ड (Sticky Traps) लगाएं',
        'दशपर्णी अर्क या खट्टी छाछ (50 मिली/लीटर) का छिड़काव करें',
      ],
      mr: [
        '५% निंबोळी अर्क किंवा १०००० पीपीएम निंबोळी तेल ३ मिली/लिटर फवारा',
        'एकरमध्ये २० निळे व पिवळे चिकट सापळे (Sticky traps) उभारा',
        'दशपर्णी अर्क किंवा जुने आंबट ताक (५० मिली/लिटर) फवारा',
      ],
      en: [
        'Spray 5% Neem Seed Kernel Extract (NSKE) or 10,000 ppm Neem oil @ 2-3 ml/Litre',
        'Install 20 Blue and Yellow sticky traps per acre to capture flying thrips',
        'Spray sour buttermilk or Dashparni ark for biological suppression',
      ],
    },
    chemicalTreatment: {
      hi: [
        'थ्रिप्स के लिए: फिप्रोनिल 5% SC (1.5 मिली/लीटर) या लैम्ब्डा-साइहलोथ्रिन 5% EC (1 मिली/लीटर)',
        'करपा रोग के लिए: मैंकोजेब 75% WP (2.5 ग्राम/लीटर) या टेबुकोनाज़ोल 25.9% EC (1.5 मिली/लीटर)',
        'दवा के साथ हमेशा 0.5 मिली स्टिकर (चिपकू) अवश्य मिलाएं',
      ],
      mr: [
        'थ्रिप्ससाठी: फिप्रोनिल ५% SC (१.५ मिली/लिटर) किंवा स्पिनोटोरम ११.७% SC (०.९ मिली/लिटर)',
        'करप्यासाठी: मँकोझेब ७५% WP (२.५ ग्रॅम/लिटर) किंवा टेब्युकोनाझोल (१.५ मिली/लिटर)',
        'द्रावणात नेहमी ०.५ मिली स्टिकर (स्प्रेडर) अवश्य मिसळा',
      ],
      en: [
        'For Thrips: Fipronil 5% SC @ 1.5 ml/L or Spinetoram 11.7% SC @ 0.9 ml/L',
        'For Blight: Mancozeb 75% WP @ 2.5 g/L or Tebuconazole 25.9% EC @ 1.5 ml/L',
        'Always blend a non-ionic sticker/spreader (0.5 ml/L) for onion waxy leaves',
      ],
    },
    prevention: {
      hi: [
        'खेत के चारों ओर मक्का या ज्वार की 2 कतारें रक्षात्मक पट्टी (Barrier crop) के रूप में लगाएं',
        'फसल में अत्यधिक यूरिया (नाइट्रोजन) देने से बचें, इससे रस चूसक कीट बढ़ते हैं',
      ],
      mr: [
        'कांदा क्षेत्राच्या कडेने मका किंवा ज्वारीच्या २ ओळी संरक्षक पीक म्हणून लावा',
        'जास्त प्रमाणात रासायनिक युरिया देणे टाळा, त्यामुळे रसशोषक किडी वाढतात',
      ],
      en: [
        'Plant 2 border rows of maize or sorghum as a physical barrier crop',
        'Avoid excessive nitrogenous fertilizer application which promotes succulent growth',
      ],
    },
  },
  {
    id: 'soybean-yellow-mosaic',
    crop: {
      hi: 'सोयाबीन (Soybean)',
      mr: 'सोयाबीन (Soybean)',
      en: 'Soybean',
    },
    name: {
      hi: 'सोयाबीन पीला मोजेक वायरस और चक्री भुंगा (Girdle Beetle)',
      mr: 'सोयाबीन पिवळा मोझॅक आणि खोडकीड / चक्रभुंगा',
      en: 'Soybean Yellow Mosaic Virus & Girdle Beetle',
    },
    sampleImage: 'https://images.unsplash.com/photo-1599839575945-a9e5af0c3fa5?w=600&auto=format&fit=crop&q=80',
    symptoms: {
      hi: [
        'पत्तियों पर चटख पीले और हरे रंग के धब्बे दिखना, पत्तियां कड़ी होकर सिकुड़ना',
        'तने पर दो गोल छल्ले (रिंग) कट जाते हैं और ऊपरी टहनी सूखकर लटक जाती है',
        'शंखियों में दाने नहीं भरते या बहुत बारीक रह जाते हैं',
      ],
      mr: [
        'पानांवर पिवळे आणि हिरवे ठिपके तयार होतात, पाने आखडतात',
        'खोडावर चक्री भुंग्यामुळे दोन चक्राकार खाचा पडून फांदी वाळते',
        'शेंगा पोचट राहतात व दाणे बारीक भरतात',
      ],
      en: [
        'Mosaic pattern of alternating bright yellow and dark green patches on leaves',
        'Two distinct ring girdles cut on stem by beetle, leading to drooping branch above',
        'Stunted pods and poor grain development',
      ],
    },
    organicTreatment: {
      hi: [
        'सफेद मक्खी (जो वायरस फैलाती है) के लिए पीले चिपचिपे ट्रैप प्रति एकड़ 15 लगाएं',
        'रोगग्रस्त पौधों को उखाड़कर तुरंत जमीन में दबा दें या जला दें',
        'नीम अर्क 5% (50 मिली प्रति 10 लीटर) का नियमित छिड़काव करें',
      ],
      mr: [
        'पांढरी माशी रोखण्यासाठी एकरी १५ पिवळे चिकट सापळे लावा',
        'रोगट झाडे त्वरित उपटून शेताबाहेर नष्ट करा',
        '५% निंबोळी अर्काची नियमित फवारणी करा',
      ],
      en: [
        'Place 15 Yellow Sticky Traps per acre to control vector whiteflies',
        'Rogue out and destroy infected viral plants immediately',
        'Spray 5% Neem extract at initial stages',
      ],
    },
    chemicalTreatment: {
      hi: [
        'सफेद मक्खी नियंत्रण: थायामेथोक्सम 25% WG (0.5 ग्राम/लीटर) या एसिटामिप्रिड 20% SP',
        'चक्री भुंगा व सेमीलूपर इल्ली: क्लोरैंट्रानिलिप्रोल 18.5% SC (0.3 मिली/लीटर) या प्रोफेनोफॉस 50% EC (2 मिली/लीटर)',
      ],
      mr: [
        'पांढऱ्या माशीसाठी: थायामेथोक्साम २५% WG (०.५ ग्रॅम/लिटर) किंवा असिटामिप्रिड २०% SP',
        'चक्रीभुंगा व खोडमाशीसाठी: क्लोरँट्रानिलीप्रोल १८.५% SC (०.३ मिली/लिटर) किंवा इमामेक्टिन बेन्झोएट (०.५ ग्रॅम/लिटर)',
      ],
      en: [
        'Vector Whitefly: Thiamethoxam 25% WG @ 0.5 g/L or Acetamiprid 20% SP @ 0.4 g/L',
        'Girdle Beetle: Chlorantraniliprole 18.5% SC @ 0.3 ml/L or Emamectin Benzoate @ 0.5 g/L',
      ],
    },
    prevention: {
      hi: [
        'बुआई से पहले थायामेथोक्सम 30% FS (3 मिली/किलो बीज) से बीज शोधन जरूर करें',
        'रोग प्रतिरोधी किस्में जैसे JS-20-34, JS-20-98 या NRC-86 लगाएं',
      ],
      mr: [
        'पेरणीपूर्वी थायामेथोक्साम ३०% FS ने बीजप्रक्रिया (३ मिली/किलो) अवश्य करा',
        'रोगप्रतिकारक वाण जसे फुले किमया (KDS 726), JS-20-34 निवडा',
      ],
      en: [
        'Mandatory seed treatment with Thiamethoxam 30% FS @ 3 ml per kg seed',
        'Select resistant varieties like Phule Kimaya (KDS 726), JS-2034',
      ],
    },
  },
  {
    id: 'cotton-bollworm',
    crop: {
      hi: 'कपास (कापूस)',
      mr: 'कापूस (Cotton)',
      en: 'Cotton',
    },
    name: {
      hi: 'कपास में गुलाबी सुंडी (Pink Bollworm) और रस चूसक कीट',
      mr: 'कापसावरील गुलाबी बोंडअळी व मावा-तुडतुडे',
      en: 'Cotton Pink Bollworm & Sucking Pests',
    },
    sampleImage: 'https://images.unsplash.com/photo-1594904351111-a072f80b1a71?w=600&auto=format&fit=crop&q=80',
    symptoms: {
      hi: [
        'फूलों का गुलाब की कली की तरह बंद रह जाना (Rosetted Flowers)',
        'छोटे हरे टिंडों में बारीक छेद दिखना और अंदर की रुई खराब होना',
        'पत्तियों का नीचे की ओर मुड़ना और पौधों का विकास रुकना',
      ],
      mr: [
        'फुले न उमलता गुलाबाच्या कळीसारखी चोच बंद राहणे (Rosetted flower)',
        'हिरव्या बोंडांमध्ये बारीक छिद्र पडून आतून सरकी खाल्ली जाणे',
        'पाने वाकडी होणे, पानांच्या कडा पिवळ्या व लालसर पडणे',
      ],
      en: [
        'Rosetted blooms that fail to open into normal flowers',
        'Bored holes on young bolls with damaged stained lint inside',
        'Leaf cupping and crinkling from sucking leafhoppers',
      ],
    },
    organicTreatment: {
      hi: [
        'बुआई के 40 दिन बाद प्रति एकड़ 5-8 फेरोमोन ट्रैप (Pheromone Traps) लगाएं',
        'ट्राइकोग्रामा परजीवी ततैया के कार्ड (50,000 अंडे प्रति एकड़) लगाएं',
        'नीम का तेल (1500 ppm) 5 मिली/लीटर पानी में छिड़कें',
      ],
      mr: [
        'लागवडीनंतर ४० दिवसांनी एकरी ५ ते ८ कामगंध सापळे (Pheromone traps) लावा',
        'ट्रायकोग्रामा परोपजीवी कीटकांचे कार्ड (५०,००० अंडी/एकर) शेतात लावा',
        '५% निंबोळी अर्काची पहिली फवारणी वेळेत करा',
      ],
      en: [
        'Install 5 to 8 Pheromone traps per acre from 40 days after sowing',
        'Release Trichogramma egg parasitoid cards @ 50,000 eggs per acre',
        'Spray Neem Oil (1500 ppm) @ 5 ml/Litre',
      ],
    },
    chemicalTreatment: {
      hi: [
        'फूल अवस्था पर: प्रोफेनोफॉस 50% EC (2 मिली/लीटर) या लैम्ब्डा-साइहलोथ्रिन 5% EC (1.5 मिली/लीटर)',
        'गंभीर प्रकोप होने पर: इमामेक्टिन बेंजोएट 5% SG (0.5 ग्राम/लीटर) या स्पाइनोसेड 45% SC (0.3 मिली/लीटर)',
      ],
      mr: [
        'फुलोरा अवस्थेत: प्रोफेनोफॉस ५०% EC (२ मिली/लिटर) किंवा क्लोरपायरीफॉस',
        'जास्त प्रादुर्भाव असल्यास: इमामेक्टिन बेन्झोएट ५% SG (०.५ ग्रॅम/लिटर) किंवा स्पिनोसॅड (०.३ मिली/लिटर)',
      ],
      en: [
        'Flower stage: Profenofos 50% EC @ 2 ml/L or Lambda Cyhalothrin @ 1.5 ml/L',
        'Severe infestation: Emamectin Benzoate 5% SG @ 0.5 g/L or Spinosad 45% SC @ 0.3 ml/L',
      ],
    },
    prevention: {
      hi: [
        'फसल चक्र अपनाएं, लगातार खेत में कपास की डंठलें न रहने दें',
        'कपास की कटाई के बाद खेत की गहरी जुताई करके बकरियां या भेड़ चराएं',
      ],
      mr: [
        'फर्दड (रॅटून) कापूस घेणे पूर्णपणे टाळा, त्यामुळे बोंडअळीची साखळी तुटते',
        'वेचणी संपल्यावर शेतात शेळ्या मेंढ्या चरवून जमिनीची खोल नांगरट करा',
      ],
      en: [
        'Strictly avoid ratoon cotton (Fardad) cropping to break life cycle',
        'Perform deep summer ploughing after harvest to expose pupae to birds and sun',
      ],
    },
  },
  {
    id: 'wheat-rust',
    crop: {
      hi: 'गेहूं (गहू)',
      mr: 'गहू (Wheat)',
      en: 'Wheat',
    },
    name: {
      hi: 'गेहूं का पीला रतुआ (Yellow Rust) व दीमक प्रकोप',
      mr: 'गव्हाचा तांबेरा (Rust) व वाळवी',
      en: 'Wheat Yellow / Brown Rust & Termite',
    },
    sampleImage: 'https://images.unsplash.com/photo-1574323347407-f5e1ad6d020b?w=600&auto=format&fit=crop&q=80',
    symptoms: {
      hi: [
        'पत्तियों पर पीले रंग की कतारबद्ध धारियों में पाउडर जैसा फफूंद जमना',
        'उंगली से छूने पर हाथ पर पीला या नारंगी रंग लग जाना',
        'पौधों की पत्तियां सूख जाती हैं और दाना पतला रह जाता है',
      ],
      mr: [
        'पानांवर पिवळ्या रंगाच्या ओळीत बारीक भुकटी (तांबेरा) दिसणे',
        'पानाला बोट लावल्यास बोटाला पिवळा किंवा तांबूस रंग लागणे',
        'झाडे सुकणे व दाण्यांचे वजन खूप घटणे',
      ],
      en: [
        'Yellowish-orange powder arranged in linear stripes on leaf blades',
        'Orange spores rub off readily onto fingers',
        'Premature drying of foliage and shriveled grains',
      ],
    },
    organicTreatment: {
      hi: [
        'ट्राइकोडर्मा विरिडी 5 ग्राम प्रति लीटर पानी में घोलकर जड़ों और पत्तियों पर छिड़कें',
        'गाय का पुराना मूत्र 10% (100 मिली प्रति लीटर) का छिड़काव फफूंद रोकता है',
      ],
      mr: [
        'ट्रायकोडर्मा विरिडी ५ ग्रॅम/लिटर पाणी याप्रमाणे पानांवर फवारा',
        '१०% गोमूत्र द्रावणाची फवारणी बुरशीचा प्रादुर्भाव रोखते',
      ],
      en: [
        'Foliar spray of Trichoderma viride @ 5 g/Litre water',
        '10% aged cow urine foliar application works as natural bio-fungicide',
      ],
    },
    chemicalTreatment: {
      hi: [
        'प्रोपिकोनाज़ोल 25% EC (टिल्ट) 1 मिली प्रति लीटर पानी में मिलाकर तुरंत छिड़काव करें',
        'या टेबुकोनाज़ोल 25.9% EC (1.5 मिली/लीटर) का 15 दिन के अंतराल पर दोहराएं',
      ],
      mr: [
        'प्रोपिकोनाझोल २५% EC (१ मिली/लिटर पाणी) बुरशीनाशकाची त्वरित फवारणी करा',
        'किंवा टेब्युकोनाझोल (१.५ मिली/लिटर) १५ दिवसांच्या अंतराने पुन्हा फवारा',
      ],
      en: [
        'Propiconazole 25% EC @ 1.0 ml/Litre water (immediate curative spray)',
        'Or Tebuconazole 25.9% EC @ 1.5 ml/Litre, repeat after 15 days if cloudy',
      ],
    },
    prevention: {
      hi: [
        'समय पर बुआई करें (15 से 25 नवंबर तक)',
        'रतुआ प्रतिरोधी किस्में जैसे HD-2967, DBW-187, DBW-303, PBW-725 की बुआई करें',
      ],
      mr: [
        'गव्हाची पेरणी १५ नोव्हेंबर ते ३० नोव्हेंबर दरम्यान पूर्ण करा',
        'रोगप्रतिकारक वाण जसे की समाधान, फुले समाधान, DBW-187 निवडा',
      ],
      en: [
        'Timely sowing between 15th to 25th November',
        'Use rust resistant varieties like DBW 187, DBW 303, HD 3226',
      ],
    },
  },
  {
    id: 'tomato-leaf-curl',
    crop: {
      hi: 'टमाटर (Tomato)',
      mr: 'टोमॅटो (Tomato)',
      en: 'Tomato',
    },
    name: {
      hi: 'टमाटर का पर्ण कुंचन (Leaf Curl Virus) और अगेती झुलसा',
      mr: 'टोमॅटोवरील पाने मुरडणे (लीफ कर्ल) व करपा रोग',
      en: 'Tomato Leaf Curl Virus & Early Blight',
    },
    sampleImage: 'https://images.unsplash.com/photo-1592924357228-91a4daadcfea?w=600&auto=format&fit=crop&q=80',
    symptoms: {
      hi: [
        'पत्तियां ऊपर या नीचे की ओर मुड़कर कटोरी जैसी हो जाती हैं',
        'पौधे का कद छोटा रह जाता है और फूल गिर जाते हैं',
        'निचली पत्तियों पर गोल छल्लेदार गहरे कत्थई धब्बे',
      ],
      mr: [
        'पाने वरच्या किंवा खालच्या बाजूला वाटीसारखी मुरडतात (बोकड्या रोग)',
        'रोपांची वाढ खुंटते, फुले गळतात आणि फळे धरत नाहीत',
        'पानांवर गोलाकार काळे तपकिरी ठिपके पडणे',
      ],
      en: [
        'Severe upward curling and puckering of leaves like cups',
        'Plant stunting with severe flower drop and failure of fruit set',
        'Concentric dark rings and bullseye spots on lower leaves',
      ],
    },
    organicTreatment: {
      hi: [
        'सफेद मक्खी पर नियंत्रण के लिए खेत में 25 पीले चिपचिपे कार्ड लगाएं',
        'रोगग्रस्त पौधों को तुरंत खेत से निकालकर उखाड़ दें',
        'खट्टी छाछ में थोड़ी हींग मिलाकर छिड़कने से वायरस का फैलाव धीमा होता है',
      ],
      mr: [
        'पांढरी माशी रोखण्यासाठी २५ पिवळे चिकट सापळे लावा',
        'रोगट झाडे उपटून शेताबाहेर खड्ड्यात गाडून टाका',
        'आंबट ताक (५० मिली/लिटर) फवारा',
      ],
      en: [
        'Install 25 Yellow Sticky Traps per acre to trap transmitting whiteflies',
        'Rogue out and bury severely infected plants immediately',
        'Spray sour buttermilk fermented with asafoetida (hing)',
      ],
    },
    chemicalTreatment: {
      hi: [
        'सफेद मक्खी के लिए: डायफेनथियुरॉन 50% WP (1.2 ग्राम/लीटर) या एसिटामिप्रिड 20% SP',
        'झुलसा के लिए: एज़ोक्सीस्ट्रोबिन + डाइफेनोकोनाज़ोल (1 मिली/लीटर)',
      ],
      mr: [
        'पांढऱ्या माशीसाठी: डायफेन्थियुरॉन ५०% WP (१.२ ग्रॅम/लिटर) किंवा पायरीप्रॉक्सिफेन',
        'करप्यासाठी: अझॉक्सीस्ट्रॉबिन + डायफेनोकोनाझोल (१ मिली/लिटर)',
      ],
      en: [
        'Whitefly vector: Diafenthiuron 50% WP @ 1.2 g/L or Pyriproxyfen 10% EC',
        'Early blight: Azoxystrobin + Difenoconazole @ 1 ml/Litre',
      ],
    },
    prevention: {
      hi: [
        'नर्सरी को 40 मेश की नेट जाली से ढककर पौधे तैयार करें',
        'रोपाई के समय जड़ों को इमिडाक्लोप्रिड घोल में 15 मिनट डुबोकर लगाएं',
      ],
      mr: [
        'रोपवाटिका ४० मेशच्या कीटक प्रतिबंधक जाळीमध्ये तयार करा',
        'पुनर्लागवड करताना रोपांची मुळे इमिडाक्लोप्रिडच्या द्रावणात बुडवा',
      ],
      en: [
        'Grow nursery seedlings under 40-mesh insect-proof netting',
        'Dip seedling roots in Imidacloprid solution for 15 mins prior to transplanting',
      ],
    },
  },
  {
    id: 'banana-sigatoka',
    crop: {
      hi: 'केला (Banana)',
      mr: 'केळी (Banana)',
      en: 'Banana',
    },
    name: {
      hi: 'केले का सिगाटोका पर्ण दाग (Sigatoka Leaf Spot) व कंद घुन',
      mr: 'केळीवरील सिगाटोका करपा व कंदकिडा (Rhizome Weevil)',
      en: 'Banana Sigatoka Leaf Streak & Rhizome Borer',
    },
    sampleImage: 'https://images.unsplash.com/photo-1571771894821-ce9b6c11b08e?w=600&auto=format&fit=crop&q=80',
    symptoms: {
      hi: [
        'पत्तियों पर पहले हल्के पीले-भूरे रंग के बारीक धब्बे पड़ना, जो बाद में गहरे काले होकर पत्ती को सुखा देते हैं',
        'घार का आकार छोटा रह जाता है और केले समय से पहले पीले पड़कर पकने लगते हैं',
        'कंद में घुन द्वारा सुरंगें बनाना, जिससे पौधा तेज हवा में गिर जाता है',
      ],
      mr: [
        'पानांवर सुरुवातीला पिवळसर-तपकिरी रेषा दिसणे, नंतर पाने करपून जळाल्यासारखी दिसतात',
        'केळीचा घड बारीक राहतो आणि अकाली पक्व होऊन गळतो',
        'खोडात किंवा कंदात बारीक छिद्रे पडून झाड वाऱ्याने कोलमडते',
      ],
      en: [
        'Yellowish and reddish-brown streaks that coalesce into large dark brown necrotic patches',
        'Premature ripening and undersized banana fingers',
        'Corm tunneling by weevil larvae leading to plant toppling in winds',
      ],
    },
    organicTreatment: {
      hi: [
        'संक्रमित और सूखी पत्तियों को काटकर खेत से दूर नष्ट करें',
        'ट्राइकोडर्मा विरिडी 5 ग्राम/लीटर घोल बनाकर तने और मिट्टी में ड्रेन्चिंग करें',
        'कंद घुन के लिए बिवेरिया बासियाना (5 ग्राम/लीटर) जड़ों में दें',
      ],
      mr: [
        'रोगट व सुकलेली पाने कापून शेताबाहेर नष्ट करा',
        'ट्रायकोडर्मा विरिडी ५ ग्रॅम/लिटर द्रावण खोडावर व जमिनीत आळवणी करा',
        'कंदकिड्यासाठी बिवेरिया बासियाना किंवा मेटारायझियम जमिनीत द्या',
      ],
      en: [
        'De-leafing of necrotic infected leaves to reduce spore load',
        'Drench root zone with Trichoderma viride @ 5g/Litre water',
        'Apply Beauveria bassiana or Metarhizium @ 2kg/acre for weevil suppression',
      ],
    },
    chemicalTreatment: {
      hi: [
        'सिगाटोका के लिए: प्रोपिकोनाज़ोल 25% EC (टिल्ट) 1ml/लीटर + मिनरल ऑयल (10ml/L), या एमिस्टार टॉप 1ml/लीटर',
        'कंद घुन के लिए: क्लोरोपायरीफॉस 20% EC (2.5 ml/L) कंद के पास मिट्टी में डालें',
      ],
      mr: [
        'सिगाटोकासाठी: प्रोपिकोनाझोल २५% EC (१ मिली/लिटर) + खनिज तेल (१० मिली) किंवा नॅटिव्हो (०.८ ग्रॅम/लिटर)',
        'कंदकिड्यासाठी: क्लोरपायरीफॉस (२.५ मिली/लिटर) खोडाभोवती जमिनीत टाकावे',
      ],
      en: [
        'Sigatoka: Propiconazole 25% EC @ 1 ml/L with mineral oil (10 ml/L) or Amistar Top @ 1 ml/L',
        'Rhizome Weevil: Chlorpyrifos 20% EC @ 2.5 ml/L drenching around pseudostem',
      ],
    },
    prevention: {
      hi: [
        'केले के बाग में जल निकासी (Drainage) की उत्तम व्यवस्था रखें, पानी जमा न होने दें',
        'रोपाई के समय प्रमाणित रोगमुक्त टिश्यू कल्चर (G-9) पौधे ही लगाएं',
      ],
      mr: [
        'बागेमध्ये पाण्याचा निचरा उत्तम ठेवा, वाफ्यात दलदल होऊ देऊ नका',
        'लागवडीसाठी खात्रीशीर रोगमुक्त टिशू कल्चर (G-9) रोपेच वापरा',
      ],
      en: [
        'Ensure proper drainage channels to prevent water stagnation in banana orchards',
        'Use certified disease-free hardened tissue culture plantlets (Grand Naine G-9)',
      ],
    },
  },
  {
    id: 'papaya-mosaic-rot',
    crop: {
      hi: 'पपीता (Papaya)',
      mr: 'पपई (Papaya)',
      en: 'Papaya',
    },
    name: {
      hi: 'पपीते का रिंग स्पॉट वायरस (PRSV) और कॉलर रॉट (जड़ सड़न)',
      mr: 'पपईचा रिंग स्पॉट व्हायरस व खोडकूज (Collar Rot)',
      en: 'Papaya Ring Spot Virus (PRSV) & Collar Rot',
    },
    sampleImage: 'https://images.unsplash.com/photo-1517282009859-f000ec3b26fe?w=600&auto=format&fit=crop&q=80',
    symptoms: {
      hi: [
        'पत्तियों पर गहरे हरे व पीले रंग के छल्ले (Rings) और पत्तियां धागे जैसी बारीक (Shoe string) हो जाना',
        'फलों पर गोल छल्लेदार चकत्ते बनना और फलों का स्वाद फीका पड़ना',
        'बरसात में जमीन की सतह के पास तना गीला होकर सड़ना और पौधा जमीन पर गिर जाना (कॉलर रॉट)',
      ],
      mr: [
        'पानांवर गडद हिरवे व पिवळे कडे (Rings) दिसणे, पाने कातरल्यासारखी बारीक होणे',
        'फळांवर गोलाकार अंगठीसारखे डाग पडतात व फळे बेचव होतात',
        'पावसाळ्यात खोडाच्या बुंध्याशी काळी ओलसर सडण होऊन झाड जागेवर कोलमडते (खोडकूज)',
      ],
      en: [
        'Prominent oily rings on leaves and petioles; leaves reduce to narrow shoe-strings',
        'Concentric ringspot blemishes on green fruit skin',
        'Water-soaked dark lesions at ground level trunk leading to sudden tree toppling (Collar rot)',
      ],
    },
    organicTreatment: {
      hi: [
        'वायरस फैलाने वाले माहू (Aphids) के लिए 5% नीम तेल (3ml/L) नियमित छिड़कें',
        'तना सड़न रोकने के लिए तने के चारों ओर बोर्डो मिश्रण (1% Bordo paste) का लेप लगाएं',
        'खेत के चारों ओर 3 कतारें मक्के की सुरक्षा दीवार के रूप में लगाएं',
      ],
      mr: [
        'व्हायरस पसरवणाऱ्या मावा किडीसाठी निंबोळी अर्क ५% किंवा १०,००० ppm नीम तेल फवारा',
        'खोडकुज रोखण्यासाठी खोडावर १% बोर्डो पेस्टचा (Bordeaux Paste) लेप लावा',
        'शेताभोवती मका किंवा ज्वारीच्या ३ ओळींचे संरक्षक कुंपण लावा',
      ],
      en: [
        'Spray 10,000 ppm Neem Oil @ 3 ml/L against aphid vectors that transmit PRSV',
        'Apply 1% Bordeaux paste paint around trunk base from soil line up to 1.5 feet',
        'Erect 3 border rows of tall fodder maize as a physical barrier for aphids',
      ],
    },
    chemicalTreatment: {
      hi: [
        'माहू/रस चूसक कीट: इमिडाक्लोप्रिड 17.8% SL (0.5 ml/L) या थायामेथोक्सम 25% WG (0.5 g/L)',
        'तना व जड़ सड़न (कॉलर रॉट): रिडोमिल गोल्ड (2.5 g/L) या कॉपर ऑक्सीक्लोराइड (3 g/L) से तने के पास मिट्टी में ड्रेन्चिंग करें',
      ],
      mr: [
        'मावा/रसशोषक किडींसाठी: कॉन्फिडोर (०.५ मिली/लिटर) किंवा थायामेथोक्साम (०.५ ग्रॅम/लिटर)',
        'खोडकुज/मुळकुजसाठी: रिडोमिल गोल्ड (२.५ ग्रॅम/लिटर) किंवा ब्लू कॉपर (३ ग्रॅम/लिटर) खोडाभोवती ड्रेन्चिंग करा',
      ],
      en: [
        'Vector Aphid control: Imidacloprid 17.8% SL @ 0.5 ml/L or Acetamiprid 20% SP @ 0.5 g/L',
        'Collar Rot (Phytophthora): Drench Ridomil Gold @ 2.5 g/L or Metalaxyl around trunk',
      ],
    },
    prevention: {
      hi: [
        'पपीते को हमेशा 1.5 फीट ऊंचे गादी वाफे (Raised beds) पर लगाएं ताकि पानी न ठहरे',
        'वायरस ग्रसित पौधे को तुरंत उखाड़कर गहरे गड्ढे में दबा दें ताकि अन्य पौधों में न फैले',
      ],
      mr: [
        'पपई नेहमी दीड फूट उंच गादीवाफ्यावर लावा, खोडाला पाणी अजिबात स्पर्श करू देऊ नका',
        'व्हायरस झालेली झाडे तात्काळ उपटून खोल खड्ड्यात गाडून टाका',
      ],
      en: [
        'Strictly transplant onto 1.5-foot elevated ridges/raised beds to guarantee zero water stagnation',
        'Rogue out any virus-affected papaya trees immediately to safeguard healthy block',
      ],
    },
  },
];
