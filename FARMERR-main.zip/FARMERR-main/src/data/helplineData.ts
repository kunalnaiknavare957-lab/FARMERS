import { HelplineContact } from '../types';

export const HELPLINE_DATA: HelplineContact[] = [
  {
    id: 'kcc',
    name: {
      hi: 'किसान कॉल सेंटर (Kisan Call Centre)',
      mr: 'किसान कॉल सेंटर (KCC)',
      en: 'Kisan Call Centre (KCC)',
    },
    number: '1800-180-1551',
    timing: {
      hi: 'सुबह 6:00 से रात 10:00 बजे (सभी 7 दिन)',
      mr: 'सकाळी ६:०० ते रात्री १०:०० (सर्व दिवस)',
      en: '6:00 AM to 10:00 PM (All 7 Days)',
    },
    description: {
      hi: 'भारत सरकार का टोल फ्री नंबर। अपनी भाषा (हिंदी/मराठी) में कृषि वैज्ञानिकों से बीमारी, खाद और मौसम पर मुफ्त सलाह लें।',
      mr: 'भारत सरकारचा टोल-फ्री क्रमांक. आपल्या मराठी भाषेत कृषी तज्ज्ञांशी थेट बोलून पीक, खते व रोगांवर मोफत सल्ला घ्या.',
      en: 'Government of India toll-free helpline. Speak directly to agricultural scientists in your local language.',
    },
    type: 'free',
  },
  {
    id: 'pm-kisan-help',
    name: {
      hi: 'पीएम-किसान हेल्पलाइन (PM-KISAN)',
      mr: 'पीएम-किसान हेल्पलाईन (PM-KISAN)',
      en: 'PM-Kisan Scheme Helpline',
    },
    number: '155261',
    timing: {
      hi: 'सुबह 9:30 से शाम 6:00 बजे (कार्यदिवस)',
      mr: 'सकाळी ९:३० ते संध्याकाळी ६:०० (सोम-शनि)',
      en: '9:30 AM to 6:00 PM (Working days)',
    },
    description: {
      hi: 'किस्त न आने, ई-केवाईसी या बैंक खाते में नाम सुधार संबंधी समस्याओं के समाधान के लिए।',
      mr: 'हप्ता जमा न होणे, e-KYC किंवा बँक खात्यातील अडचणी निवारणासाठी अधिकृत नंबर.',
      en: 'Official support for PM-Kisan installment delays, bank rejections, and e-KYC issues.',
    },
    type: 'free',
  },
  {
    id: 'fasal-bima-help',
    name: {
      hi: 'फसल बीमा क्लेम हेल्पलाइन (PMFBY)',
      mr: 'पीक विमा तक्रार निवारण (PMFBY)',
      en: 'PMFBY Crop Insurance Toll-Free',
    },
    number: '1800-180-2117',
    timing: {
      hi: '24 घंटे चालू (24x7 टोल फ्री)',
      mr: '२४ तास सेवा उपलब्ध (Toll-Free)',
      en: '24 Hours / 7 Days Toll-Free',
    },
    description: {
      hi: 'फसल का प्राकृतिक नुकसान होने पर 72 घंटे के भीतर नुकसान की सूचना दर्ज कराने हेतु।',
      mr: 'नैसर्गिक आपत्तीमुळे पिकांचे नुकसान झाल्यास ७२ तासांच्या आत पूर्वसूचना नोंदवण्यासाठी.',
      en: 'Intimate crop damage within 72 hours of unseasonal rains, drought, or floods.',
    },
    type: 'emergency',
  },
  {
    id: 'pashu-help',
    name: {
      hi: 'पशुधन व पशु चिकित्सा एम्बुलेंस (1962)',
      mr: 'पशुवैद्यकीय फिरता दवाखाना व रुग्णवाहिका (1962)',
      en: 'National Animal Health Helpline (1962)',
    },
    number: '1962',
    timing: {
      hi: '24 घंटे आपातकालीन सेवा',
      mr: '२४ तास आपत्कालीन सेवा',
      en: '24x7 Emergency Vet Service',
    },
    description: {
      hi: 'गाय, भैंस, बकरी व मवेशियों के गंभीर बीमार होने पर सीधे डॉक्टर की गाड़ी आपके बाड़े पर पहुंचेगी।',
      mr: 'गाय, म्हैस, शेळी आजारी पडल्यास थेट गोठ्यावर पशुवैद्यकीय रुग्णवाहिका बोलावण्यासाठी टोल-फ्री क्रमांक.',
      en: 'Emergency mobile veterinary clinic van arrival at your cowshed for sick cattle and livestock.',
    },
    type: 'emergency',
  },
  {
    id: 'mahadbt-help',
    name: {
      hi: 'महाराष्ट्र कृषि विभाग (महाडीबीटी शेतकरी)',
      mr: 'महाराष्ट्र कृषी विभाग (महाडीबीटी हेल्पलाईन)',
      en: 'Maharashtra MahaDBT Farmer Desk',
    },
    number: '1800-120-8040',
    timing: {
      hi: 'सुबह 10:00 से शाम 6:00 बजे तक',
      mr: 'सकाळी १०:०० ते संध्याकाळी ६:०० वाजेपर्यंत',
      en: '10:00 AM to 6:00 PM',
    },
    description: {
      hi: 'ट्रैक्टर, ड्रिप, सोलर पंप व अन्य राज्य स्तरीय कृषि सब्सिडी योजनाओं की स्थिति जानने हेतु।',
      mr: 'ठिबक सिंचन, ट्रॅक्टर, शेततळे व इतर शासकीय योजनांच्या लॉटरी व अनुदानाबाबत चौकशी.',
      en: 'Inquiry for state agricultural subsidies, tractor grants, and farm pond schemes.',
    },
    type: 'dept',
  },
  {
    id: 'kvk-help',
    name: {
      hi: 'कृषि विज्ञान केंद्र (KVK Indian Council)',
      mr: 'कृषी विज्ञान केंद्र (KVK)',
      en: 'Krishi Vigyan Kendra Directorate',
    },
    number: '011-25841474',
    timing: {
      hi: 'सुबह 10:00 से शाम 5:00 बजे',
      mr: 'सकाळी १०:०० ते ५:०० वाजेपर्यंत',
      en: '10:00 AM to 5:00 PM',
    },
    description: {
      hi: 'उन्नत बीज, मिट्टी परीक्षण और आधुनिक जैविक खेती के प्रशिक्षण के लिए अपने नजदीकी KVK से जुड़ें।',
      mr: 'सुधारित बियाणे, माती परीक्षण व सेंद्रिय शेतीच्या प्रशिक्षणासाठी जिल्हा KVK केंद्र.',
      en: 'Connect with local district KVK centers for soil health testing and improved certified seeds.',
    },
    type: 'dept',
  },
];
