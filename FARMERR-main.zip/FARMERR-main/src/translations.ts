import { Language } from './types';

export const translations = {
  appName: {
    hi: 'किसान मित्र',
    mr: 'शेतकरी मित्र',
    en: 'Kisan Mitra',
  },
  appTagline: {
    hi: 'भारतीय किसानों का सच्चा साथी',
    mr: 'बळीराजाचा विश्वासू डिजिटल सोबती',
    en: 'Digital companion for Indian farmers',
  },
  nav: {
    mandi: {
      hi: 'मंडी भाव',
      mr: 'बाजार भाव',
      en: 'Mandi Rates',
    },
    weather: {
      hi: 'मौसम',
      mr: 'हवामान',
      en: 'Weather',
    },
    schemes: {
      hi: 'सरकारी योजना',
      mr: 'शासकीय योजना',
      en: 'Govt Schemes',
    },
    doctor: {
      hi: 'फसल डॉक्टर',
      mr: 'पीक डॉक्टर',
      en: 'Crop Doctor',
    },
    advisory: {
      hi: 'फसल सलाह',
      mr: 'पीक सल्ला',
      en: 'Crop Advice',
    },
    market: {
      hi: 'खरीद-बिक्री',
      mr: 'खरेदी-विक्री',
      en: 'Krishi Bazaar',
    },
    tools: {
      hi: 'खाद व मिट्टी',
      mr: 'खत व माती',
      en: 'Soil & Fertilizer',
    },
    helpline: {
      hi: 'हेल्पलाइन',
      mr: 'हेल्पलाईन',
      en: 'Helpline',
    },
    guidance: {
      hi: 'फसल मार्गदर्शन (A-Z गाइड)',
      mr: 'पीक मार्गदर्शन (A-Z गाईड)',
      en: 'Crop Guidance',
    },
  },
  quickActions: {
    callKisanCenter: {
      hi: 'कॉल किसान केंद्र (1800-180-1551)',
      mr: 'कॉल किसान केंद्र (1800-180-1551)',
      en: 'Call Kisan Helpline (1800-180-1551)',
    },
    askAi: {
      hi: 'सवाल पूछें (AI)',
      mr: 'प्रश्न विचारा (AI)',
      en: 'Ask Krishi AI',
    },
    listenAudio: {
      hi: 'सुनें',
      mr: 'ऐका',
      en: 'Listen',
    },
    stopAudio: {
      hi: 'रोकें',
      mr: 'थांबवा',
      en: 'Stop',
    },
    offlineNotice: {
      hi: 'ऑफ़लाइन मोड: पहले सेव किया गया डेटा दिख रहा है',
      mr: 'ऑफलाईन मोड: आधी जतन केलेली माहिती दिसत आहे',
      en: 'Offline Mode: Showing cached data',
    },
  },
  mandi: {
    title: {
      hi: 'आज का लाइव मंडी भाव',
      mr: 'आजचे थेट बाजार भाव',
      en: 'Today’s Live Mandi Rates',
    },
    subtitle: {
      hi: 'अपनी मंडी और फसल के ताजा भाव देखें (प्रति क्विंटल)',
      mr: 'तुमच्या बाजार समितीतील ताजे दर (प्रति क्विंटल)',
      en: 'Latest crop prices by market & district (per quintal)',
    },
    searchPlaceholder: {
      hi: 'फसल या मंडी खोजें (उदा. केला, पपीता, प्याज, गेहूं, नासिक, पुणे)...',
      mr: 'पीक किंवा बाजार शोधा (उदा. केळी, पपई, कांदा, गहू, नाशिक, जळगाव)...',
      en: 'Search crop or market (e.g., Banana, Papaya, Onion, Wheat, Nashik)...',
    },
    allStates: {
      hi: 'सभी राज्य',
      mr: 'सर्व राज्ये',
      en: 'All States',
    },
    allCategories: {
      hi: 'सभी फसलें',
      mr: 'सर्व पिके',
      en: 'All Crops',
    },
    fruits: {
      hi: 'फल (केला, पपीता, अनार)',
      mr: 'फळे (केळी, पपई, डाळिंब)',
      en: 'Fruits (Banana, Papaya)',
    },
    grains: {
      hi: 'अनाज (गेहूं, धान, मक्का)',
      mr: 'धान्य (गहू, भात, मका)',
      en: 'Grains & Cereals',
    },
    pulses: {
      hi: 'दलहन (चना, तुअर, मूंग)',
      mr: 'कडधान्य (हरभरा, तूर, मूग)',
      en: 'Pulses',
    },
    oilseeds: {
      hi: 'तिलहन (सोयाबीन, सरसों)',
      mr: 'गळीत धान्य (सोयाबीन, मोहरी)',
      en: 'Oilseeds',
    },
    vegetables: {
      hi: 'सब्जियां (प्याज, टमाटर, लहसुन)',
      mr: 'भाजीपाला (कांदा, टोमॅटो, लसूण)',
      en: 'Vegetables',
    },
    commercial: {
      hi: 'व्यापारिक (कपास, गन्ना)',
      mr: 'नगदी पिके (कापूस, ऊस)',
      en: 'Cash Crops',
    },
    minPrice: {
      hi: 'न्यूनतम',
      mr: 'किमान',
      en: 'Min Price',
    },
    maxPrice: {
      hi: 'अधिकतम',
      mr: 'कमाल',
      en: 'Max Price',
    },
    modalPrice: {
      hi: 'मॉडल भाव',
      mr: 'सरासरी दर',
      en: 'Modal Rate',
    },
    arrival: {
      hi: 'आवक',
      mr: 'आवक',
      en: 'Arrival',
    },
    updatedOn: {
      hi: 'अपडेट',
      mr: 'अपडेट',
      en: 'Updated',
    },
    noResults: {
      hi: 'कोई मंडी भाव नहीं मिला। कृपया अलग नाम खोजें।',
      mr: 'कोणतेही दर आढळले नाहीत. कृपया वेगळे नाव शोधा.',
      en: 'No mandi rates found. Try another search.',
    },
  },
  weather: {
    title: {
      hi: 'कृषि मौसम और छिड़काव सलाह',
      mr: 'शेती हवामान व फवारणी सल्ला',
      en: 'Agri Weather & Spray Advisory',
    },
    rainChance: {
      hi: 'बारिश की संभावना',
      mr: 'पावसाची शक्यता',
      en: 'Rain Chance',
    },
    humidity: {
      hi: 'नमी',
      mr: 'आर्द्रता',
      en: 'Humidity',
    },
    wind: {
      hi: 'हवा की गति',
      mr: 'वाऱ्याचा वेग',
      en: 'Wind Speed',
    },
    spraySuitable: {
      hi: 'कीटनाशक छिड़काव के लिए उत्तम समय है',
      mr: 'कीटकनाशक फवारणीसाठी अनुकूल हवामान आहे',
      en: 'Favorable conditions for spraying pesticide',
    },
    sprayCaution: {
      hi: 'सावधानी: तेज हवा या हल्की बारिश संभव, संभलकर स्प्रे करें',
      mr: 'काळजी घ्या: जोरदार वारा किंवा पाऊस शक्य, जपून फवारणी करा',
      en: 'Caution: Wind or rain likely, postpone spray if possible',
    },
    sprayDanger: {
      hi: 'छिड़काव न करें: बारिश का भारी अनुमान है, दवा धुल जाएगी',
      mr: 'फवारणी करू नका: पावसाची दाट शक्यता, औषध वाहून जाईल',
      en: 'Avoid spraying: Rain expected, medicine will wash away',
    },
    changeLocation: {
      hi: 'जिला बदलें',
      mr: 'जिल्हा बदला',
      en: 'Change District',
    },
    detectLocation: {
      hi: 'मेरा स्थान पहचानें (GPS)',
      mr: 'माझे स्थान शोधा (GPS)',
      en: 'Use GPS Location',
    },
    fiveDayForecast: {
      hi: 'अगले 5 दिनों का मौसम',
      mr: 'पुढील ५ दिवसांचा अंदाज',
      en: 'Next 5 Days Forecast',
    },
  },
  schemes: {
    title: {
      hi: 'सरकारी योजनाएं और सब्सिडी',
      mr: 'शासकीय योजना व अनुदान',
      en: 'Government Schemes & Subsidies',
    },
    subtitle: {
      hi: 'पीएम-किसान, फसल बीमा, ड्रिप सब्सिडी और आवेदन के तरीके',
      mr: 'पीएम-किसान, पीक विमा, ठिबक अनुदान व अर्ज करण्याची पद्धत',
      en: 'PM-Kisan, Crop Insurance, Subsidies & Application guides',
    },
    benefits: {
      hi: 'मुख्य लाभ / सहायता राशि',
      mr: 'मुख्य लाभ / मिळणारी मदत',
      en: 'Benefits & Grant',
    },
    eligibility: {
      hi: 'पात्रता (किसे मिलेगा)',
      mr: 'पात्रता (कोणाला मिळेल)',
      en: 'Eligibility',
    },
    documents: {
      hi: 'ज़रूरी कागज़ात (दस्तावेज़)',
      mr: 'आवश्यक कागदपत्रे',
      en: 'Required Documents',
    },
    applySteps: {
      hi: 'आवेदन कैसे करें (स्टेप-बाय-स्टेप)',
      mr: 'अर्ज कसा करावा (सविस्तर पायऱ्या)',
      en: 'How to Apply (Steps)',
    },
    applyOnline: {
      hi: 'सरकारी पोर्टल पर जाएं',
      mr: 'शासकीय पोर्टलवर जा',
      en: 'Go to Official Portal',
    },
    helplineNum: {
      hi: 'योजना हेल्पलाइन',
      mr: 'योजना हेल्पलाईन',
      en: 'Scheme Helpline',
    },
  },
  doctor: {
    title: {
      hi: 'फसल डॉक्टर (रोग व कीट पहचान)',
      mr: 'पीक डॉक्टर (रोग व कीड निदान)',
      en: 'Crop Doctor (Disease & Pest Diagnosis)',
    },
    subtitle: {
      hi: 'खराब पत्ती या कीट की फोटो खींचें और तुरंत इलाज पाएं',
      mr: 'किडीचा किंवा रोगाचा फोटो काढा व त्वरित उपाय मिळवा',
      en: 'Take a photo of diseased crop to get instant remedies',
    },
    takePhoto: {
      hi: 'कैमरा से फोटो लें',
      mr: 'कॅमेऱ्याने फोटो काढा',
      en: 'Take Camera Photo',
    },
    uploadPhoto: {
      hi: 'गैलरी से फोटो चुनें',
      mr: 'गॅलरीतून फोटो निवडा',
      en: 'Choose from Gallery',
    },
    selectCropOptional: {
      hi: 'फसल का नाम (वैकल्पिक)',
      mr: 'पिकाचे नाव (ऐच्छिक)',
      en: 'Crop Name (Optional)',
    },
    analyzing: {
      hi: 'कृषि AI फोटो की जांच कर रहा है...',
      mr: 'कृषी AI फोटोची तपासणी करत आहे...',
      en: 'AI is analyzing your crop photo...',
    },
    diagnoseButton: {
      hi: 'बीमारी पहचानें (जांच करें)',
      mr: 'रोग ओळखा व तपासणी करा',
      en: 'Diagnose Disease Now',
    },
    symptomsTitle: {
      hi: 'लक्षण',
      mr: 'लक्षणे',
      en: 'Symptoms',
    },
    organicTitle: {
      hi: 'देसी व जैविक उपचार (कम खर्च)',
      mr: 'सेंद्रिय व घरगुती उपाय (कमी खर्च)',
      en: 'Organic & Home Remedies (Low Cost)',
    },
    chemicalTitle: {
      hi: 'रासायनिक दवा व सही मात्रा',
      mr: 'रासायनिक औषध व अचूक प्रमाण',
      en: 'Chemical Spray & Dosage',
    },
    preventionTitle: {
      hi: 'भविष्य में बचाव के उपाय',
      mr: 'भविष्यात बचावाचे उपाय',
      en: 'Prevention Tips',
    },
    commonDiseasesTitle: {
      hi: 'प्रमुख फसलों के सामान्य रोग (सीधा इलाज देखें)',
      mr: 'प्रमुख पिकांचे नेहमीचे रोग (थेट उपाय पहा)',
      en: 'Common Crop Diseases (Quick Solutions)',
    },
  },
  advisory: {
    title: {
      hi: 'ऋतु अनुसार फसल सलाह',
      mr: 'हंगामनिहाय पीक सल्ला',
      en: 'Seasonal Crop Advice',
    },
    kharif: {
      hi: 'खरीफ (मानसून)',
      mr: 'खरीप (पावसाळा)',
      en: 'Kharif (Monsoon)',
    },
    rabi: {
      hi: 'रबी (सर्दियां)',
      mr: 'रब्बी (हिवाळा)',
      en: 'Rabi (Winter)',
    },
    zaid: {
      hi: 'जायद (गर्मी)',
      mr: 'उन्हाळी (जायद)',
      en: 'Zaid (Summer)',
    },
    sowingTime: {
      hi: 'बुआई का सही समय',
      mr: 'पेरणीची योग्य वेळ',
      en: 'Sowing Window',
    },
    seedRate: {
      hi: 'बीज की मात्रा (प्रति एकड़)',
      mr: 'बियाणांचे प्रमाण (प्रति एकर)',
      en: 'Seed Rate (per acre)',
    },
    seedTreatment: {
      hi: 'बीज शोधन (उपचार)',
      mr: 'बीजप्रक्रिया',
      en: 'Seed Treatment',
    },
    fertilizerDose: {
      hi: 'खाद की मात्रा (NPK)',
      mr: 'खतांचे प्रमाण (NPK)',
      en: 'Fertilizer Dose',
    },
    irrigation: {
      hi: 'सिंचाई के मुख्य चरण',
      mr: 'पाणी देण्याच्या मुख्य वेळा',
      en: 'Irrigation Stages',
    },
    yield: {
      hi: 'अनुमानित उपज',
      mr: 'अपेक्षित उत्पादन',
      en: 'Expected Yield',
    },
  },
  market: {
    title: {
      hi: 'किसान बाजार (सीधा खरीद-बिक्री)',
      mr: 'शेतकरी बाजार (थेट खरेदी-विक्री)',
      en: 'Krishi Bazaar (Buy & Sell)',
    },
    subtitle: {
      hi: 'बिना बिचौलिए के सीधे किसान से बीज, खाद, ट्रैक्टर या फसल खरीदें-बेचें',
      mr: 'मध्यस्थांशिवाय थेट शेतकऱ्यांकडून बी-बियाणे, अवजारे किंवा माल खरेदी-विक्री',
      en: 'Buy or sell seeds, equipment, fertilizer or harvest directly without middlemen',
    },
    postAd: {
      hi: '+ नया विज्ञापन डालें (फ्री)',
      mr: '+ नवीन जाहिरात द्या (मोफत)',
      en: '+ Post New Ad (Free)',
    },
    filterAll: {
      hi: 'सभी सामान',
      mr: 'सर्व वस्तू',
      en: 'All Items',
    },
    filterSeeds: {
      hi: 'बीज (Seeds)',
      mr: 'बियाणे (Seeds)',
      en: 'Seeds',
    },
    filterFertilizer: {
      hi: 'खाद / जैविक (Fertilizer)',
      mr: 'खते / शेणखत (Fertilizer)',
      en: 'Fertilizers',
    },
    filterEquipment: {
      hi: 'ट्रैक्टर / औज़ार (Equipment)',
      mr: 'ट्रॅक्टर / अवजारे (Equipment)',
      en: 'Equipment / Rent',
    },
    filterCrops: {
      hi: 'फसल / अनाज (Harvest)',
      mr: 'धान्य / पीक (Harvest)',
      en: 'Bulk Crops',
    },
    filterCattle: {
      hi: 'पशु / गाय-भैंस (Cattle)',
      mr: 'जनावरे / गुरे (Cattle)',
      en: 'Livestock',
    },
    callSeller: {
      hi: 'कॉल करें',
      mr: 'कॉल करा',
      en: 'Call Farmer',
    },
    whatsappSeller: {
      hi: 'व्हाट्सएप करें',
      mr: 'व्हॉट्सअॅप करा',
      en: 'WhatsApp',
    },
  },
  tools: {
    title: {
      hi: 'खाद व मिट्टी जांच कैलकुलेटर',
      mr: 'खत व माती परीक्षण कॅल्क्युलेटर',
      en: 'Fertilizer & Soil Calculator',
    },
    subtitle: {
      hi: 'जमीन के हिसाब से यूरिया, डीएपी और पोटाश की सही बोरियों का हिसाब लगाएं',
      mr: 'जमिनीच्या क्षेत्रफळानुसार युरिया, डीएपी व पोटॅशच्या अचूक पोत्यांची मोजणी',
      en: 'Calculate exact bags of Urea, DAP, and Potash based on your land size',
    },
    farmArea: {
      hi: 'खेत का क्षेत्रफल दर्ज करें',
      mr: 'शेताचे क्षेत्रफळ टाका',
      en: 'Enter Farm Area',
    },
    unitAcre: {
      hi: 'एकड़ (Acre)',
      mr: 'एकर (Acre)',
      en: 'Acre',
    },
    unitGuntha: {
      hi: 'गुंठा (Guntha)',
      mr: 'गुंठा (Guntha)',
      en: 'Guntha',
    },
    unitBigha: {
      hi: 'बीघा (Bigha)',
      mr: 'बिघा (Bigha)',
      en: 'Bigha',
    },
    selectCrop: {
      hi: 'फसल चुनें',
      mr: 'पीक निवडा',
      en: 'Select Crop',
    },
    calculate: {
      hi: 'खाद की मात्रा निकालें',
      mr: 'खतांचे प्रमाण काढा',
      en: 'Calculate Fertilizer',
    },
    ureaBags: {
      hi: 'यूरिया (Urea - 45kg बैग)',
      mr: 'युरिया (Urea - ४५ किलो पोते)',
      en: 'Urea (45kg Bags)',
    },
    dapBags: {
      hi: 'डीएपी (DAP - 50kg बैग)',
      mr: 'डीएपी (DAP - ५० किलो पोते)',
      en: 'DAP (50kg Bags)',
    },
    mopBags: {
      hi: 'पोटाश (MOP - 50kg बैग)',
      mr: 'पोटॅश (MOP - ५० किलो पोते)',
      en: 'Potash MOP (50kg Bags)',
    },
    soilSamplingGuide: {
      hi: 'मिट्टी की जांच (Soil Test) के 5 आसान नियम',
      mr: 'माती परीक्षण (Soil Test) चे ५ सोपे नियम',
      en: '5 Easy Steps for Soil Testing',
    },
  },
  helpline: {
    title: {
      hi: 'किसान हेल्पलाइन और संपर्क नंबर',
      mr: 'शेतकरी हेल्पलाईन व संपर्क क्रमांक',
      en: 'Kisan Helplines & Direct Contacts',
    },
    subtitle: {
      hi: 'सरकारी कृषि वैज्ञानिक और सहायता केंद्रों से 1-क्लिक में सीधे बात करें',
      mr: 'शासकीय कृषी तज्ज्ञ व मदत केंद्रांशी एका क्लिकमध्ये थेट संवाद साधा',
      en: 'Direct 1-tap call to government scientists and support centers',
    },
  },
  aiChat: {
    modalTitle: {
      hi: 'किसान सहायक AI (बोलकर या लिखकर पूछें)',
      mr: 'शेतकरी सहाय्यक AI (बोलून किंवा लिहून विचारा)',
      en: 'Kisan Sahayak AI (Voice & Text)',
    },
    placeholder: {
      hi: 'अपना सवाल यहाँ लिखें या माइक दबाकर बोलें...',
      mr: 'तुमचा प्रश्न येथे लिहा किंवा माईक दाबून बोला...',
      en: 'Type your farming question or tap mic to speak...',
    },
    askButton: {
      hi: 'पूछें',
      mr: 'विचारा',
      en: 'Ask',
    },
    listening: {
      hi: 'सुन रहे हैं... बोलिए',
      mr: 'ऐकत आहे... बोला',
      en: 'Listening... please speak',
    },
    quickQuestionsTitle: {
      hi: 'किसानों द्वारा अक्सर पूछे जाने वाले सवाल:',
      mr: 'शेतकऱ्यांनी विचारलेले नेहमीचे प्रश्न:',
      en: 'Frequently Asked Farming Questions:',
    },
    sample1: {
      hi: 'सोयाबीन में कौन सी खाद डालें?',
      mr: 'सोयाबीनला कोणती खते द्यावीत?',
      en: 'Which fertilizer for soybean?',
    },
    sample2: {
      hi: 'कांदा पिकावर थ्रिप्स पडले तर काय उपाय?',
      mr: 'कांदा पिकावर थ्रिप्ससाठी काय फवारावे?',
      en: 'How to control thrips in onion?',
    },
    sample3: {
      hi: 'गेहूं में पहला पानी कब देना चाहिए?',
      mr: 'गव्हाला पहिले पाणी कधी द्यावे?',
      en: 'When to give 1st irrigation to wheat?',
    },
    sample4: {
      hi: 'पीएम किसान योजना की अगली किस्त कब आएगी?',
      mr: 'पीएम किसान योजनेचा पुढील हप्ता कधी येईल?',
      en: 'When will next PM-Kisan installment come?',
    },
  },
  pesticides: {
    title: {
      hi: 'कृषि दवा व कीटनाशक डायरेक्टरी',
      mr: 'शेती औषधे व कीटकनाशक माहिती',
      en: 'Agri Pesticides & Medicine Directory',
    },
    subtitle: {
      hi: 'बाजार में मिलने वाले सभी कीटनाशक, फफूंदनाशक, खरपतवारनाशक और सही खुराक (डोज)',
      mr: 'बाजारात मिळणारी सर्व कीटकनाशके, बुरशीनाशके, तणनाशके व अचूक प्रमाण (डोस)',
      en: 'All market insecticides, fungicides, herbicides, bio-inputs & pump dosage',
    },
    searchPlaceholder: {
      hi: 'दवा का नाम, रोग या फसल खोजें (उदा. कोराजन, साफ, केला, पपीता, इल्ली, थ्रिप्स)...',
      mr: 'औषधाचे नाव, रोग किंवा पीक शोधा (उदा. कोराजन, साफ, केळी, पपई, करपा, थ्रिप्स)...',
      en: 'Search pesticide, pest or crop (e.g., Coragen, Saaf, Banana, Papaya, Blight)...',
    },
    allTypes: {
      hi: 'सभी दवाएं',
      mr: 'सर्व औषधे',
      en: 'All Types',
    },
    insecticide: {
      hi: 'कीटनाशक (इल्ली/कीट)',
      mr: 'कीटकनाशक (अळी/किडे)',
      en: 'Insecticides',
    },
    fungicide: {
      hi: 'फफूंदनाशक (करपा/फंगस)',
      mr: 'बुरशीनाशक (करपा/बुरशी)',
      en: 'Fungicides',
    },
    herbicide: {
      hi: 'खरपतवारनाशक (घास/तण)',
      mr: 'तणनाशक (गवत जळणारे)',
      en: 'Herbicides',
    },
    organic: {
      hi: 'जैविक व नीम अर्क',
      mr: 'सेंद्रिय व निंबोळी अर्क',
      en: 'Bio-Pesticides',
    },
    pgr: {
      hi: 'टॉनिक व PGR (फूल/फल)',
      mr: 'टॉनिक व PGR (फूल/फळ)',
      en: 'Tonics & PGR',
    },
    perPumpDose: {
      hi: 'प्रति 15L पंप मात्रा',
      mr: 'प्रति १५L पंप प्रमाण',
      en: 'Dose per 15L Pump',
    },
    waitingPeriod: {
      hi: 'तोड़ाई पूर्व प्रतीक्षा (PHI)',
      mr: 'तोडणीपूर्व कालावधी (PHI)',
      en: 'Pre-harvest Interval (PHI)',
    },
    technicalFormula: {
      hi: 'टेक्निकल फार्मूला',
      mr: 'तांत्रिक घटक',
      en: 'Technical Content',
    },
    targetCrops: {
      hi: 'उपयुक्त फसलें',
      mr: 'उपयुक्त पिके',
      en: 'Recommended Crops',
    },
    targetPests: {
      hi: 'नियंत्रित कीट व रोग',
      mr: 'नियंत्रित होणारे रोग व किडी',
      en: 'Target Pests & Diseases',
    },
  },
};

export function getTranslation(lang: Language) {
  return {
    t: (path: string) => {
      const parts = path.split('.');
      let current: any = translations;
      for (const part of parts) {
        if (!current || current[part] === undefined) return path;
        current = current[part];
      }
      return current[lang] || current['hi'] || path;
    },
  };
}
