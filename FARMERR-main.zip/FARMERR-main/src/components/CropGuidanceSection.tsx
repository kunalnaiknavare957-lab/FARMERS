import React, { useState, useMemo } from 'react';
import {
  Sprout,
  Droplets,
  FlaskConical,
  Wheat,
  Award,
  Volume2,
  Calendar,
  AlertTriangle,
  CheckCircle2,
  Search,
  Sparkles,
  Share2,
  Layers,
  ChevronDown,
  ChevronUp,
  Leaf,
  Info,
} from 'lucide-react';
import { Language } from '../types';
import {
  CROP_GUIDANCE_DATABASE,
  DetailedCropGuidance,
} from '../data/cropGuidanceData';
import { speakText, stopSpeaking } from '../utils/speech';

interface CropGuidanceSectionProps {
  lang: Language;
}

export const CropGuidanceSection: React.FC<CropGuidanceSectionProps> = ({ lang }) => {
  const [selectedCropId, setSelectedCropId] = useState<string>('onion');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [farmSize, setFarmSize] = useState<number>(1); // In Acres
  const [activeGuideTab, setActiveGuideTab] = useState<'water' | 'spray' | 'fertilizer' | 'secrets' | 'overview'>('water');
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [customCropQuery, setCustomCropQuery] = useState('');
  const [aiGenerating, setAiGenerating] = useState(false);
  const [customAiGuide, setCustomAiGuide] = useState<string | null>(null);

  const selectedCrop = useMemo(() => {
    return CROP_GUIDANCE_DATABASE.find((c) => c.id === selectedCropId) || CROP_GUIDANCE_DATABASE[0];
  }, [selectedCropId]);

  const quickCrops = [
    { id: 'onion', emoji: '🧅', name: { hi: 'प्याज (कांदा)', mr: 'कांदा (Onion)', en: 'Onion' } },
    { id: 'tomato', emoji: '🍅', name: { hi: 'टमाटर', mr: 'टोमॅटो (Tomato)', en: 'Tomato' } },
    { id: 'banana', emoji: '🍌', name: { hi: 'केला (G-9)', mr: 'केळी (Banana G-9)', en: 'Banana' } },
    { id: 'papaya', emoji: '🍈', name: { hi: 'पपीता (786)', mr: 'पपई (Papaya)', en: 'Papaya' } },
    { id: 'soybean', emoji: '🌱', name: { hi: 'सोयाबीन', mr: 'सोयाबीन (Soybean)', en: 'Soybean' } },
    { id: 'cotton', emoji: '☁️', name: { hi: 'कपास', mr: 'कापूस (Cotton)', en: 'Cotton' } },
    { id: 'wheat', emoji: '🌾', name: { hi: 'गेहूं', mr: 'गहू (Wheat)', en: 'Wheat' } },
  ];

  // Search filter
  const filteredCrops = useMemo(() => {
    if (!searchTerm.trim()) return CROP_GUIDANCE_DATABASE;
    const q = searchTerm.toLowerCase();
    return CROP_GUIDANCE_DATABASE.filter(
      (c) =>
        c.name.hi.toLowerCase().includes(q) ||
        c.name.mr.toLowerCase().includes(q) ||
        c.name.en.toLowerCase().includes(q)
    );
  }, [searchTerm]);

  const handleSpeakGuidance = () => {
    if (isSpeaking) {
      stopSpeaking();
      setIsSpeaking(false);
      return;
    }

    const c = selectedCrop;
    let textToSpeak = '';
    if (lang === 'mr') {
      textToSpeak = `${c.name.mr} संपूर्ण पीक मार्गदर्शन: अपेक्षित उत्पादन ${c.expectedYieldPerAcre.mr}. पाणी किती वेळा द्यावे: सुरुवातीला ३ ते ४ दिवसांनी आणि कांदा पोसताना दर ४ ते ५ दिवसांनी पाणी द्यावे. काढणीच्या १५ दिवस आधी पाणी बंद करावे. खत व फवारणीमध्ये सल्फर, फिप्रोनिल आणि पोटॅश वेळेवर द्यावे.`;
    } else if (lang === 'hi') {
      textToSpeak = `${c.name.hi} सम्पूर्ण फसल मार्गदर्शन: अनुमानित उत्पादन ${c.expectedYieldPerAcre.hi}. सिंचाई का नियम: कंद बनते समय हर 4-5 दिन में पानी दें और कटाई से 15 दिन पहले पानी बंद करें। समय पर खाद और फवारणी से बंपर पैदावार मिलेगी।`;
    } else {
      textToSpeak = `Crop guidance for ${c.name.en}: Expected yield ${c.expectedYieldPerAcre.en}. Follow scientific irrigation and pesticide schedule for maximum harvest.`;
    }

    setIsSpeaking(true);
    speakText(
      textToSpeak,
      lang,
      () => setIsSpeaking(false),
      () => setIsSpeaking(false)
    );
  };

  const handleAskCustomCropAi = async () => {
    if (!customCropQuery.trim()) return;
    setAiGenerating(true);
    setCustomAiGuide(null);

    try {
      const res = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: `मला ${customCropQuery} या पिकाचे संपूर्ण A to Z शेती मार्गदर्शन हवे आहे. नवीन शेतकऱ्याला समजेल असे सांगा: 1. पाणी किती वेळा आणि कधी द्यावे? 2. कोणती खते कधी द्यावीत? 3. कोणती कीटकनाशके व औषधे कधी फवारावीत? 4. जास्तीत जास्त भरघोस उत्पादन कसे आणावे?`,
          lang: lang,
        }),
      });

      const data = await res.json();
      setCustomAiGuide(data.reply || 'माहिती उपलब्ध नाही.');
    } catch {
      setCustomAiGuide(
        lang === 'mr'
          ? `${customCropQuery} पीक सल्ला: योग्य अंतरावर लागवड करा. ठिबक सिंचनाने पाणी द्या आणि तज्ञांच्या सल्ल्याने खते व फवारणी करा.`
          : `${customCropQuery} फसल सलाह: उचित दूरी पर बुआई करें। ड्रिप से पानी दें और संतुलित खाद का प्रयोग करें।`
      );
    } finally {
      setAiGenerating(false);
    }
  };

  return (
    <div className="space-y-4 pb-8 animate-in fade-in duration-200">
      {/* Hero Header */}
      <div className="bg-gradient-to-r from-emerald-800 via-teal-800 to-emerald-900 rounded-3xl p-5 sm:p-6 text-white shadow-lg relative overflow-hidden border border-emerald-700">
        <div className="absolute right-0 top-0 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-400 text-amber-950 font-black text-xs uppercase tracking-wider shadow-xs">
              <Sprout className="w-4 h-4" />
              <span>
                {lang === 'mr'
                  ? 'नवशिक्या व प्रगतीशील शेतकऱ्यांसाठी A-Z गाईड'
                  : lang === 'hi'
                  ? 'नए व अनुभवी किसानों के लिए सम्पूर्ण फसल गाइड'
                  : 'A to Z Crop Farming Masterclass'}
              </span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white">
              {lang === 'mr'
                ? 'पीक मार्गदर्शन: जास्तीत जास्त भरघोस उत्पादन कसे आणावे?'
                : lang === 'hi'
                ? 'फसल मार्गदर्शन: ज्यादा से ज्यादा बंपर पैदावार कैसे लाएं?'
                : 'Crop Guidance: How to Maximize Your Harvest Yield'}
            </h2>
            <p className="text-xs sm:text-sm text-emerald-100 font-medium max-w-2xl">
              {lang === 'mr'
                ? 'पाणी किती वेळा द्यावे, कोणती औषधे/कीटकनाशके कधी फवारावीत, आणि खतांचे वेळापत्रक — सर्व एकाच ठिकाणी!'
                : lang === 'hi'
                ? 'पानी कितनी बार देना है, कौन से कीटनाशक कब छिड़कने हैं, और खाद का सही शेड्यूल — सब कुछ एक जगह!'
                : 'Irrigation timetable, pesticide spray schedules, fertilizer doses, and yield secrets.'}
            </p>
          </div>

          {/* Audio Listen Button */}
          <div className="shrink-0 flex items-center gap-2">
            <button
              onClick={handleSpeakGuidance}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-extrabold text-xs sm:text-sm shadow-md transition active:scale-95 ${
                isSpeaking
                  ? 'bg-rose-500 text-white animate-pulse'
                  : 'bg-amber-400 hover:bg-amber-300 text-amber-950'
              }`}
            >
              <Volume2 className="w-4 h-4" />
              <span>
                {isSpeaking
                  ? lang === 'mr'
                    ? 'थांबवा'
                    : 'रोकें'
                  : lang === 'mr'
                  ? 'सल्ला ऐका'
                  : 'सलाह सुनें'}
              </span>
            </button>
          </div>
        </div>
      </div>

      {/* Crop Selector & Search Card */}
      <div className="bg-white rounded-2xl p-4 shadow-xs border border-slate-200 space-y-3">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2">
          {/* Search Box */}
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={
                lang === 'mr'
                  ? 'पिकाचे नाव शोधा (उदा. कांदा, टोमॅटो, केळी, पपई, कापूस, सोयाबीन, गहू)...'
                  : lang === 'hi'
                  ? 'फसल का नाम खोजें (उदा. प्याज, टमाटर, केला, पपीता, कपास, सोयाबीन, गेहूं)...'
                  : 'Search crop (e.g. Onion, Tomato, Banana, Papaya, Cotton, Wheat)...'
              }
              className="w-full pl-9 pr-3 py-2 text-xs sm:text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-600 bg-slate-50 font-medium"
            />
          </div>

          {/* Farm Size Multiplier */}
          <div className="flex items-center gap-1.5 bg-emerald-50 px-3 py-1.5 rounded-xl border border-emerald-200 shrink-0">
            <span className="text-xs font-black text-emerald-900">
              {lang === 'mr' ? 'माझी जमीन:' : lang === 'hi' ? 'मेरी जमीन:' : 'My Farm:'}
            </span>
            {[0.5, 1, 2, 5].map((acres) => (
              <button
                key={acres}
                onClick={() => setFarmSize(acres)}
                className={`px-2 py-1 rounded-lg text-xs font-black transition ${
                  farmSize === acres
                    ? 'bg-emerald-700 text-white shadow-xs'
                    : 'bg-white text-emerald-800 hover:bg-emerald-100'
                }`}
              >
                {acres === 0.5 ? (lang === 'mr' ? '२० गुंठे' : '20 गुंठा') : `${acres} ${lang === 'mr' ? 'एकर' : 'एकड़'}`}
              </button>
            ))}
          </div>
        </div>

        {/* 1-Tap Quick Crop Buttons */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pt-1">
          {quickCrops.map((c) => {
            const isSelected = selectedCropId === c.id;
            return (
              <button
                key={c.id}
                onClick={() => {
                  setSelectedCropId(c.id);
                  setCustomAiGuide(null);
                }}
                className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-black whitespace-nowrap transition-all shadow-xs ${
                  isSelected
                    ? 'bg-emerald-800 text-white ring-2 ring-emerald-500 scale-102'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200 hover:text-slate-900'
                }`}
              >
                <span className="text-base">{c.emoji}</span>
                <span>{c.name[lang]}</span>
              </button>
            );
          })}
        </div>

        {/* Custom Crop AI Query Drawer */}
        <div className="bg-amber-50/80 rounded-xl p-3 border border-amber-200 flex flex-col sm:flex-row items-center gap-2 text-xs">
          <span className="font-bold text-amber-950 shrink-0 flex items-center gap-1">
            <Sparkles className="w-4 h-4 text-amber-600" />
            {lang === 'mr' ? 'इतर कोणतेही पीक हवे आहे का?' : 'अन्य कोई फसल है?'}
          </span>
          <input
            type="text"
            value={customCropQuery}
            onChange={(e) => setCustomCropQuery(e.target.value)}
            placeholder={
              lang === 'mr'
                ? 'उदा. हळद, डाळिंब, ऊस, मिरची, लसूण, आले, ड्रॅगन फ्रूट...'
                : 'उदा. हल्दी, अनार, गन्ना, मिर्च, लहसुन, अदरक, ड्रैगन फ्रूट...'
            }
            className="flex-1 bg-white border border-amber-300 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-amber-500"
          />
          <button
            onClick={handleAskCustomCropAi}
            disabled={aiGenerating || !customCropQuery.trim()}
            className="bg-amber-500 hover:bg-amber-600 disabled:opacity-50 text-amber-950 font-black px-3 py-1.5 rounded-lg shrink-0 flex items-center gap-1 shadow-xs transition"
          >
            {aiGenerating ? 'तयार होत आहे...' : lang === 'mr' ? 'AI गाईड मिळवा' : 'AI गाइड पाएं'}
          </button>
        </div>

        {/* AI Custom Result if triggered */}
        {customAiGuide && (
          <div className="bg-white rounded-xl p-4 border-2 border-amber-300 shadow-md space-y-2 animate-in fade-in">
            <div className="flex items-center justify-between pb-2 border-b border-amber-100">
              <h4 className="font-black text-amber-950 text-sm flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-600" />
                {lang === 'mr' ? `विशेष पीक गाईड: ${customCropQuery}` : `विशेष फसल गाइड: ${customCropQuery}`}
              </h4>
              <button
                onClick={() => setCustomAiGuide(null)}
                className="text-slate-400 hover:text-slate-600 font-bold"
              >
                ✕
              </button>
            </div>
            <div className="text-xs sm:text-sm text-slate-700 whitespace-pre-line leading-relaxed font-medium">
              {customAiGuide}
            </div>
          </div>
        )}
      </div>

      {/* Selected Crop Banner */}
      <div className="bg-white rounded-2xl p-4 shadow-xs border border-slate-200">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-2xl">
                {selectedCrop.id === 'onion' ? '🧅' : selectedCrop.id === 'tomato' ? '🍅' : selectedCrop.id === 'banana' ? '🍌' : selectedCrop.id === 'papaya' ? '🍈' : selectedCrop.id === 'soybean' ? '🌱' : selectedCrop.id === 'cotton' ? '☁️' : '🌾'}
              </span>
              <h3 className="text-lg sm:text-xl font-black text-slate-900">
                {selectedCrop.name[lang]}
              </h3>
              <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 text-[11px] font-black">
                {selectedCrop.durationDays}
              </span>
            </div>
            <p className="text-xs sm:text-sm text-emerald-700 font-bold mt-1">
              {selectedCrop.tagline[lang]}
            </p>
          </div>

          <div className="flex items-center gap-3 bg-amber-50 p-3 rounded-xl border border-amber-200/80">
            <Award className="w-6 h-6 text-amber-600 shrink-0" />
            <div>
              <span className="text-[10px] font-black uppercase text-amber-800 tracking-wider block">
                {lang === 'mr' ? 'अपेक्षित भरघोस उत्पादन' : 'अनुमानित बंपर पैदावार'}
              </span>
              <span className="text-xs sm:text-sm font-black text-slate-900">
                {selectedCrop.expectedYieldPerAcre[lang]}
              </span>
            </div>
          </div>
        </div>

        {/* Guide Navigation Tabs */}
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-1.5 pt-3">
          {[
            { id: 'water' as const, label: lang === 'mr' ? '💧 पाणी व्यवस्थापन' : '💧 सिंचाई शेड्यूल', icon: Droplets, color: 'text-blue-600' },
            { id: 'spray' as const, label: lang === 'mr' ? '🧪 औषध व फवारणी' : '🧪 दवा व कीटनाशक', icon: FlaskConical, color: 'text-rose-600' },
            { id: 'fertilizer' as const, label: lang === 'mr' ? '🌾 खत वेळापत्रक' : '🌾 खाद का डोज', icon: Sprout, color: 'text-emerald-600' },
            { id: 'secrets' as const, label: lang === 'mr' ? '🏆 उत्पादन वाढीचे नियम' : '🏆 पैदावार के 5 नियम', icon: Award, color: 'text-amber-600' },
            { id: 'overview' as const, label: lang === 'mr' ? '📋 जमीन व वाण' : '📋 मिट्टी व किस्में', icon: Layers, color: 'text-purple-600' },
          ].map((tab) => {
            const isActive = activeGuideTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveGuideTab(tab.id)}
                className={`py-2 px-2.5 rounded-xl text-xs font-black transition-all flex items-center justify-center gap-1.5 shadow-xs ${
                  isActive
                    ? 'bg-slate-900 text-white shadow-md'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* TAB 1: WATER MANAGEMENT (पाणी किती वेळा आणि कधी द्यावे?) */}
      {activeGuideTab === 'water' && (
        <div className="space-y-3">
          <div className="bg-blue-50 border-l-4 border-blue-600 p-3.5 rounded-2xl text-blue-950 text-xs sm:text-sm font-semibold flex items-start gap-2 shadow-xs">
            <Info className="w-5 h-5 text-blue-700 shrink-0 mt-0.5" />
            <div>
              <span className="font-black text-blue-900 block">
                {lang === 'mr'
                  ? `पाणी व्यवस्थापन नियम (${selectedCrop.name[lang]} - शेतजमीन: ${farmSize} एकर)`
                  : `सिंचाई प्रबंधन नियम (${selectedCrop.name[lang]} - खेत: ${farmSize} एकड़)`}
              </span>
              <p className="text-xs text-blue-800 mt-0.5">
                {lang === 'mr'
                  ? 'पाणी कधीही अंदाजाने देऊ नका. खालील टप्प्यांप्रमाणे दिल्यास पिकाची मुळे सशक्त राहतात आणि वजन २०% जास्त भरते.'
                  : 'सिंचाई हमेशा अवस्था के अनुसार करें। सही समय पर पानी देने से फसल सूखती नहीं और कंद/फल का वजन 20% बढ़ता है।'}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {selectedCrop.irrigationSchedule.map((item, idx) => (
              <div
                key={idx}
                className="bg-white rounded-2xl p-4 shadow-xs border border-blue-200 hover:border-blue-400 transition space-y-2 relative"
              >
                <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-blue-600 text-white font-black text-xs flex items-center justify-center">
                      {idx + 1}
                    </span>
                    <h4 className="font-black text-slate-900 text-sm">
                      {item.stage[lang]}
                    </h4>
                  </div>
                  <span className="px-2 py-0.5 rounded-md bg-blue-100 text-blue-800 font-extrabold text-[11px]">
                    {item.timing}
                  </span>
                </div>

                <div className="space-y-1.5 text-xs text-slate-700">
                  <div>
                    <span className="font-bold text-slate-900 block">
                      {lang === 'mr' ? 'पाण्याची वारंवारता (कधी द्यावे?):' : 'पानी कितनी बार दें?'}
                    </span>
                    <p className="text-blue-900 font-extrabold bg-blue-50/80 p-2 rounded-lg mt-0.5">
                      {item.frequency[lang]}
                    </p>
                  </div>

                  <div>
                    <span className="font-bold text-slate-900 block">
                      {lang === 'mr' ? 'पद्धत व ओलावा:' : 'तरीका व नमी:'}
                    </span>
                    <p className="font-medium text-slate-600">
                      {item.waterDetails[lang]}
                    </p>
                  </div>

                  <div className="pt-1">
                    <span className="inline-flex items-center gap-1 font-black text-rose-700 text-[11px] bg-rose-50 px-2 py-1 rounded-md border border-rose-200">
                      <AlertTriangle className="w-3.5 h-3.5" />
                      {item.criticalWarning[lang]}
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 2: PESTICIDE & SPRAY SCHEDULE (कोणती औषधे कधी फवारावीत?) */}
      {activeGuideTab === 'spray' && (
        <div className="space-y-3">
          <div className="bg-rose-50 border-l-4 border-rose-600 p-3.5 rounded-2xl text-rose-950 text-xs sm:text-sm font-semibold flex items-start gap-2 shadow-xs">
            <FlaskConical className="w-5 h-5 text-rose-700 shrink-0 mt-0.5" />
            <div>
              <span className="font-black text-rose-900 block">
                {lang === 'mr'
                  ? `औषध व कीटकनाशक वेळापत्रक (${selectedCrop.name[lang]})`
                  : `दवा व कीटनाशक स्प्रे शेड्यूल (${selectedCrop.name[lang]})`}
              </span>
              <p className="text-xs text-rose-800 mt-0.5">
                {lang === 'mr'
                  ? 'रोग येण्याआधीच प्रतिबंधात्मक फवारणी करा. प्रत्येक पंपाला ५ मिली सिलिकॉन स्टिकर (स्प्रेडर) अवश्य वापरा.'
                  : 'रोग आने से पहले ही प्रिवेंटिव स्प्रे करें। हर 15 लीटर पंप में 5 मिली सिलिकॉन स्टिकर जरूर मिलाएं।'}
              </p>
            </div>
          </div>

          <div className="space-y-3">
            {selectedCrop.spraySchedule.map((spray, idx) => (
              <div
                key={idx}
                className="bg-white rounded-2xl p-4 shadow-xs border border-rose-200 hover:border-rose-300 transition space-y-3"
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-1.5 pb-2 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-rose-600 text-white font-black text-xs flex items-center justify-center">
                      {idx + 1}
                    </span>
                    <h4 className="font-black text-slate-900 text-sm sm:text-base">
                      {spray.stage[lang]}
                    </h4>
                  </div>
                  <span className="px-2.5 py-0.5 rounded-full bg-rose-100 text-rose-900 font-black text-xs">
                    {spray.timing}
                  </span>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-3 text-xs">
                  <div className="bg-slate-50 p-3 rounded-xl border border-slate-200">
                    <span className="font-black text-slate-500 uppercase tracking-wider text-[10px] block">
                      {lang === 'mr' ? 'लक्षित कीड व रोग' : 'टारगेट कीट व बीमारी'}
                    </span>
                    <p className="font-bold text-slate-900 mt-1">
                      {spray.targetPestOrDisease[lang]}
                    </p>
                  </div>

                  <div className="bg-rose-50/80 p-3 rounded-xl border border-rose-200">
                    <span className="font-black text-rose-800 uppercase tracking-wider text-[10px] block">
                      {lang === 'mr' ? 'रासायनिक औषध व डोस' : 'रासायनिक दवा व डोज'}
                    </span>
                    <p className="font-black text-rose-950 mt-1">
                      {spray.recommendedMedicine[lang]}
                    </p>
                    <span className="text-[11px] font-extrabold text-rose-700 block mt-1">
                      {spray.dosePerPump}
                    </span>
                  </div>

                  <div className="bg-emerald-50/80 p-3 rounded-xl border border-emerald-200">
                    <span className="font-black text-emerald-800 uppercase tracking-wider text-[10px] block">
                      {lang === 'mr' ? 'सेंद्रिय / देशी पर्याय' : 'जैविक / देसी विकल्प'}
                    </span>
                    <p className="font-bold text-emerald-950 mt-1">
                      {spray.organicOption[lang]}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: FERTILIZER SCHEDULE (खतांचे वेळापत्रक) */}
      {activeGuideTab === 'fertilizer' && (
        <div className="space-y-3">
          <div className="bg-emerald-50 border-l-4 border-emerald-600 p-3.5 rounded-2xl text-emerald-950 text-xs sm:text-sm font-semibold flex items-start gap-2 shadow-xs">
            <Sprout className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
            <div>
              <span className="font-black text-emerald-900 block">
                {lang === 'mr'
                  ? `टप्प्याटप्प्याने खत नियोजन (${farmSize} एकर प्रमाणे हिशोब)`
                  : `स्टेज अनुसार खाद का शेड्यूल (${farmSize} एकड़ के अनुसार डोज)`}
              </span>
              <p className="text-xs text-emerald-800 mt-0.5">
                {lang === 'mr'
                  ? 'सर्व खते एकदाच न देता विभागून द्या. पोटॅश आणि सूक्ष्म अन्नद्रव्यांमुळे उत्पादनात भरघोस वाढ होते.'
                  : 'सारा खाद एक साथ न डालें। पोटाश और सूक्ष्म पोषक तत्वों को सही अवस्था पर देने से बंपer साइज मिलता है।'}
              </p>
            </div>
          </div>

          <div className="space-y-3">
            {selectedCrop.fertilizerSchedule.map((fert, idx) => (
              <div
                key={idx}
                className="bg-white rounded-2xl p-4 shadow-xs border border-emerald-200 hover:border-emerald-300 transition space-y-2"
              >
                <div className="flex items-center justify-between pb-2 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <span className="w-6 h-6 rounded-full bg-emerald-700 text-white font-black text-xs flex items-center justify-center">
                      {idx + 1}
                    </span>
                    <h4 className="font-black text-slate-900 text-sm">
                      {fert.stage[lang]}
                    </h4>
                  </div>
                  <span className="px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-900 font-black text-xs">
                    {fert.timing}
                  </span>
                </div>

                <div className="space-y-1.5 text-xs">
                  <div className="bg-emerald-50/60 p-2.5 rounded-xl border border-emerald-200/80">
                    <span className="font-black text-emerald-900 block text-[11px] uppercase">
                      {lang === 'mr' ? 'खताचा डोस:' : 'खाद की मात्रा:'}
                    </span>
                    <p className="font-extrabold text-slate-900 text-xs sm:text-sm mt-0.5">
                      {fert.fertilizerDose[lang]}
                    </p>
                  </div>

                  <div>
                    <span className="font-bold text-slate-700">
                      {lang === 'mr' ? 'कसे द्यावे?' : 'कैसे डालें?'}
                    </span>
                    <p className="text-slate-600 font-medium mt-0.5">
                      {fert.howToApply[lang]}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 4: BUMPER YIELD SECRETS (जास्तीत जास्त भरघोस उत्पादन कसे आणावे?) */}
      {activeGuideTab === 'secrets' && (
        <div className="space-y-3">
          <div className="bg-amber-50 border-l-4 border-amber-600 p-3.5 rounded-2xl text-amber-950 text-xs sm:text-sm font-semibold flex items-start gap-2 shadow-xs">
            <Award className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
            <div>
              <span className="font-black text-amber-900 block">
                {lang === 'mr'
                  ? 'जास्तीत जास्त भरघोस उत्पादन आणण्याचे ५ गुप्त नियम'
                  : 'ज्यादा से ज्यादा बंपर पैदावार लाने के 5 गुप्त नियम'}
              </span>
              <p className="text-xs text-amber-800 mt-0.5">
                {lang === 'mr'
                  ? 'साधारण शेतकरी आणि विक्रमी उत्पादन घेणारा शेतकरी यांच्यात हाच फरक असतो.'
                  : 'साधारण किसान और रिकॉर्ड पैदावार लेने वाले किसान में बस इन्हीं नियमों का फर्क होता है।'}
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3">
            {selectedCrop.bumperYieldSecrets.map((secret, idx) => (
              <div
                key={idx}
                className="bg-white rounded-2xl p-4 shadow-xs border border-amber-200 flex items-start gap-3"
              >
                <div className="w-8 h-8 rounded-xl bg-amber-400 text-amber-950 font-black text-sm flex items-center justify-center shrink-0">
                  #{idx + 1}
                </div>
                <div className="text-xs sm:text-sm text-slate-800 font-semibold leading-relaxed">
                  {secret[lang]}
                </div>
              </div>
            ))}
          </div>

          {/* Harvesting and Grading Card */}
          <div className="bg-gradient-to-r from-emerald-50 to-teal-50 rounded-2xl p-4 border border-emerald-200 space-y-1.5">
            <span className="text-[11px] font-black uppercase text-emerald-800 tracking-wider flex items-center gap-1.5">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              {lang === 'mr' ? 'काढणी व बाजारभाव नियोजन (Grading for 25% Higher Price)' : 'कटाई व मंडी भाव की तैयारी'}
            </span>
            <p className="text-xs sm:text-sm font-bold text-slate-800">
              {selectedCrop.harvestingAndGrading[lang]}
            </p>
          </div>
        </div>
      )}

      {/* TAB 5: OVERVIEW, SOIL & VARIETIES */}
      {activeGuideTab === 'overview' && (
        <div className="bg-white rounded-2xl p-4 shadow-xs border border-slate-200 space-y-4">
          <div>
            <h4 className="font-black text-slate-900 text-sm mb-1">
              {lang === 'mr' ? 'जमीन व हवामान' : 'मिट्टी व जलवायु'}
            </h4>
            <p className="text-xs sm:text-sm text-slate-700 font-medium bg-slate-50 p-3 rounded-xl border border-slate-200">
              {selectedCrop.soilAndClimate[lang]}
            </p>
          </div>

          <div>
            <h4 className="font-black text-slate-900 text-sm mb-1.5">
              {lang === 'mr' ? 'सर्वोत्कृष्ट भरघोस वाण (Top High-Yield Varieties)' : 'सर्वोत्तम किस्में'}
            </h4>
            <div className="flex flex-wrap gap-2">
              {selectedCrop.bestVarieties[lang].map((v, i) => (
                <span
                  key={i}
                  className="px-3 py-1.5 rounded-xl bg-emerald-50 text-emerald-900 font-black text-xs border border-emerald-200"
                >
                  ✓ {v}
                </span>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-black text-slate-900 text-sm mb-1.5">
              {lang === 'mr' ? 'जमीन तयार करणे व बेड तयार करणे' : 'खेत की तैयारी व बेड बनाना'}
            </h4>
            <ul className="space-y-1.5 text-xs sm:text-sm text-slate-700 font-medium">
              {selectedCrop.landPreparation[lang].map((step, i) => (
                <li key={i} className="flex items-start gap-2">
                  <span className="text-emerald-600 font-bold">•</span>
                  <span>{step}</span>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="font-black text-slate-900 text-sm mb-1">
              {lang === 'mr' ? 'लागवड अंतर व बीजप्रक्रिया' : 'बुआई दूरी व बीज शोधन'}
            </h4>
            <p className="text-xs sm:text-sm text-slate-700 font-medium bg-amber-50/80 p-3 rounded-xl border border-amber-200">
              {selectedCrop.spacingAndPlanting[lang]}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
