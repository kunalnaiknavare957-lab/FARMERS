import React from 'react';
import { PhoneCall, Clock, ShieldCheck, Volume2 } from 'lucide-react';
import { Language, HelplineContact } from '../types';
import { HELPLINE_DATA } from '../data/helplineData';
import { translations } from '../translations';
import { speakText } from '../utils/speech';

interface HelplineSectionProps {
  lang: Language;
}

export const HelplineSection: React.FC<HelplineSectionProps> = ({ lang }) => {
  const handleSpeakHelpline = (item: HelplineContact) => {
    const text = `${item.name[lang]}. ${lang === 'mr' ? 'फोन नंबर' : 'फ़ोन नंबर'}: ${item.number}. ${item.description[lang]}.`;
    speakText(text, lang);
  };

  return (
    <section className="space-y-4">
      {/* Title Card */}
      <div className="bg-gradient-to-r from-emerald-800 to-blue-900 text-white rounded-2xl p-4 shadow-md border-l-6 border-amber-400">
        <div>
          <h2 className="text-xl sm:text-2xl font-black flex items-center gap-2">
            <span className="p-1.5 rounded-lg bg-amber-400 text-slate-950">
              <PhoneCall className="w-5 h-5" />
            </span>
            {translations.helpline.title[lang]}
          </h2>
          <p className="text-emerald-100 text-xs sm:text-sm mt-0.5">
            {translations.helpline.subtitle[lang]}
          </p>
        </div>
      </div>

      {/* Primary Mega Kisan Call Centre Box */}
      <div className="bg-gradient-to-br from-amber-400 to-amber-500 rounded-2xl p-4 sm:p-5 text-slate-950 shadow-md border-2 border-amber-300">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <span className="inline-block px-2.5 py-0.5 rounded-full text-xs font-black bg-slate-950 text-amber-300 uppercase tracking-wider">
              {lang === 'mr' ? 'राष्ट्रीय मोफत सेवा' : 'राष्ट्रीय निःशुल्क हेल्पलाइन'}
            </span>
            <h3 className="text-2xl sm:text-3xl font-black mt-1 leading-tight">
              1800-180-1551
            </h3>
            <p className="text-xs sm:text-sm font-bold text-slate-900 mt-1 max-w-md">
              {lang === 'mr'
                ? 'किसान कॉल सेंटर - सकाळी ६ ते रात्री १० पर्यंत मराठीत कृषी शास्त्रज्ञांशी मोफत बोला.'
                : 'किसान कॉल सेंटर - सुबह 6 से रात 10 बजे तक हिंदी में कृषि वैज्ञानिकों से मुफ्त बात करें।'}
            </p>
          </div>

          <a
            href="tel:18001801551"
            className="px-6 py-3.5 bg-slate-950 hover:bg-slate-900 text-white font-black rounded-xl text-sm sm:text-base shadow-lg transition active:scale-95 flex items-center gap-2"
          >
            <PhoneCall className="w-5 h-5 text-amber-400 animate-bounce" />
            <span>{lang === 'mr' ? 'आता कॉल करा (मोफत)' : 'अभी कॉल करें (मुफ्त)'}</span>
          </a>
        </div>
      </div>

      {/* Directory of Helplines */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
        {HELPLINE_DATA.map((item) => (
          <div
            key={item.id}
            className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm flex flex-col justify-between"
          >
            <div>
              <div className="flex items-start justify-between gap-2">
                <span
                  className={`inline-block px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                    item.type === 'emergency'
                      ? 'bg-red-100 text-red-800'
                      : item.type === 'free'
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-blue-100 text-blue-800'
                  }`}
                >
                  {item.type === 'emergency'
                    ? (lang === 'mr' ? '२४ तास आपत्कालीन' : '24x7 आपातकालीन')
                    : (lang === 'mr' ? 'टोल-फ्री नंबर' : 'टोल-फ्री नंबर')}
                </span>

                <button
                  onClick={() => handleSpeakHelpline(item)}
                  className="p-1.5 rounded-lg bg-slate-100 text-slate-600 hover:bg-emerald-100"
                  title="Listen"
                >
                  <Volume2 className="w-4 h-4" />
                </button>
              </div>

              <h4 className="text-base sm:text-lg font-black text-slate-900 mt-2 leading-tight">
                {item.name[lang]}
              </h4>

              <div className="text-xl sm:text-2xl font-black text-emerald-800 mt-1">
                {item.number}
              </div>

              <div className="flex items-center gap-1.5 text-xs text-slate-500 mt-1 font-semibold">
                <Clock className="w-3.5 h-3.5 text-slate-400" />
                <span>{item.timing[lang]}</span>
              </div>

              <p className="mt-2 text-xs text-slate-600 font-medium">
                {item.description[lang]}
              </p>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100">
              <a
                href={`tel:${item.number.replace(/[^0-9]/g, '')}`}
                className="w-full py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-black rounded-xl text-xs sm:text-sm shadow-xs transition active:scale-95 flex items-center justify-center gap-2"
              >
                <PhoneCall className="w-4 h-4 text-amber-300" />
                <span>{lang === 'mr' ? 'कॉल करा' : 'कॉल करें'}</span>
              </a>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
