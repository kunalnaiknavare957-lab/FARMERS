import React, { useState, useMemo } from 'react';
import {
  Search,
  Volume2,
  TrendingUp,
  TrendingDown,
  MapPin,
  Calendar,
  Filter,
  Mic,
  Award,
  BarChart3,
  Globe2,
} from 'lucide-react';
import { MandiItem, Language } from '../types';
import { INITIAL_MANDI_DATA } from '../data/mandiData';
import { translations } from '../translations';
import { speakText, stopSpeaking, VoiceRecognition } from '../utils/speech';

interface MandiSectionProps {
  lang: Language;
}

export const MandiSection: React.FC<MandiSectionProps> = ({ lang }) => {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCropFilter, setSelectedCropFilter] = useState<string>('onion');
  const [selectedRegion, setSelectedRegion] = useState<string>('all');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const [isListeningMic, setIsListeningMic] = useState(false);

  // Quick crop pills for 1-tap view of all regions for that crop
  const popularCrops = [
    { id: 'onion', label: lang === 'mr' ? '🧅 कांदा (सर्व भाग)' : lang === 'hi' ? '🧅 प्याज (सभी मंडियां)' : '🧅 Onion (All Regions)', term: 'कांदा' },
    { id: 'tomato', label: lang === 'mr' ? '🍅 टोमॅटो (सर्व भाग)' : lang === 'hi' ? '🍅 टमाटर (सभी मंडियां)' : '🍅 Tomato (All Regions)', term: 'टोमॅटो' },
    { id: 'banana', label: lang === 'mr' ? '🍌 केळी (सर्व भाग)' : lang === 'hi' ? '🍌 केला (सभी मंडियां)' : '🍌 Banana (All Regions)', term: 'केळी' },
    { id: 'papaya', label: lang === 'mr' ? '🍈 पपई (सर्व भाग)' : lang === 'hi' ? '🍈 पपीता (सभी मंडियां)' : '🍈 Papaya (All Regions)', term: 'पपई' },
    { id: 'soybean', label: lang === 'mr' ? '🌱 सोयाबीन (सर्व भाग)' : lang === 'hi' ? '🌱 सोयाबीन (सभी मंडियां)' : '🌱 Soybean (All Regions)', term: 'सोयाबीन' },
    { id: 'cotton', label: lang === 'mr' ? '☁️ कापूस (सर्व भाग)' : lang === 'hi' ? '☁️ कपास (सभी मंडियां)' : '☁️ Cotton (All Regions)', term: 'कापूस' },
    { id: 'wheat', label: lang === 'mr' ? '🌾 गहू (सर्व भाग)' : lang === 'hi' ? '🌾 गेहूं (सभी मंडियां)' : '🌾 Wheat (All Regions)', term: 'गहू' },
    { id: 'chana', label: lang === 'mr' ? '🪴 हरभरा / चना' : lang === 'hi' ? '🪴 चना / हरभरा' : '🪴 Gram (Chana)', term: 'हरभरा' },
    { id: 'pomegranate', label: lang === 'mr' ? '🍎 डाळिंब (अनार)' : lang === 'hi' ? '🍎 अनार (डाळिंब)' : '🍎 Pomegranate', term: 'डाळिंब' },
    { id: 'grapes', label: lang === 'mr' ? '🍇 द्राक्षे (अंगूर)' : lang === 'hi' ? '🍇 अंगूर (द्राक्ष)' : '🍇 Grapes', term: 'द्राक्षे' },
    { id: 'ginger', label: lang === 'mr' ? '🫚 आले (अदरक)' : lang === 'hi' ? '🫚 अदरक (आले)' : '🫚 Ginger', term: 'आले' },
    { id: 'garlic', label: lang === 'mr' ? '🧄 लसूण (लहसुन)' : lang === 'hi' ? '🧄 लहसुन (लसूण)' : '🧄 Garlic', term: 'लसूण' },
    { id: 'chilli', label: lang === 'mr' ? '🌶️ मिरची (मिर्च)' : lang === 'hi' ? '🌶️ मिर्च (मिरची)' : '🌶️ Chilli', term: 'मिरची' },
    { id: 'potato', label: lang === 'mr' ? '🥔 बटाटा (आलू)' : lang === 'hi' ? '🥔 आलू (बटाटा)' : '🥔 Potato', term: 'बटाटा' },
    { id: 'maize', label: lang === 'mr' ? '🌽 मका (मक्का)' : lang === 'hi' ? '🌽 मक्का (मका)' : '🌽 Maize', term: 'मका' },
  ];

  // Filtered items
  const filteredList = useMemo(() => {
    return INITIAL_MANDI_DATA.filter((item) => {
      // Category filter if active
      if (selectedCategory !== 'all' && item.cropCategory !== selectedCategory) {
        return false;
      }

      // Region filter
      if (selectedRegion !== 'all') {
        if (selectedRegion === 'nashik' && !item.district.includes('नाशिक')) return false;
        if (selectedRegion === 'pune_west' && !['पुणे', 'सोलापूर', 'कोल्हापूर', 'सांगली', 'सातारा'].some((d) => item.district.includes(d))) return false;
        if (selectedRegion === 'marathwada_khandesh' && !['संभाजीनगर', 'लातूर', 'नांदेड', 'हिंगोली', 'धुळे', 'जळगाव', 'नंदुरबार'].some((d) => item.district.includes(d))) return false;
        if (selectedRegion === 'other_states' && item.state === 'Maharashtra') return false;
      }

      // If user typed in search box, search across all fields
      if (searchTerm.trim() !== '') {
        const q = searchTerm.toLowerCase().trim();
        const cropMatch =
          item.crop.hi.toLowerCase().includes(q) ||
          item.crop.mr.toLowerCase().includes(q) ||
          item.crop.en.toLowerCase().includes(q);
        const marketMatch =
          item.market.toLowerCase().includes(q) ||
          item.district.toLowerCase().includes(q) ||
          item.state.toLowerCase().includes(q);
        return cropMatch || marketMatch;
      }

      // If no text typed, use selectedCropFilter pill
      if (selectedCropFilter !== 'all') {
        const cropObj = popularCrops.find((c) => c.id === selectedCropFilter);
        if (cropObj) {
          const t = cropObj.term.toLowerCase();
          const match =
            item.crop.mr.toLowerCase().includes(t) ||
            item.crop.hi.toLowerCase().includes(t) ||
            item.crop.en.toLowerCase().includes(t);
          if (!match) return false;
        }
      }

      return true;
    });
  }, [searchTerm, selectedCropFilter, selectedRegion, selectedCategory]);

  // Regional Comparison Statistics
  const comparisonStats = useMemo(() => {
    if (filteredList.length === 0) return null;

    let highest = filteredList[0];
    let lowest = filteredList[0];
    let sumModal = 0;

    for (const item of filteredList) {
      if (item.modalPrice > highest.modalPrice) highest = item;
      if (item.modalPrice < lowest.modalPrice) lowest = item;
      sumModal += item.modalPrice;
    }

    const avgModal = Math.round(sumModal / filteredList.length);

    return {
      highest,
      lowest,
      avgModal,
      count: filteredList.length,
    };
  }, [filteredList]);

  const handleSpeakItem = (item: MandiItem) => {
    if (speakingId === item.id) {
      stopSpeaking();
      setSpeakingId(null);
      return;
    }

    const cropName = item.crop[lang];
    const text =
      lang === 'mr'
        ? `${item.market} मध्ये आज ${cropName} चा सरासरी भाव ${item.modalPrice} रुपये प्रति क्विंटल आहे. किमान ${item.minPrice} आणि कमाल ${item.maxPrice} रुपये भाव मिळाला.`
        : lang === 'hi'
        ? `${item.market} में आज ${cropName} का मॉडल भाव ${item.modalPrice} रुपये प्रति क्विंटल है। न्यूनतम ${item.minPrice} और अधिकतम ${item.maxPrice} रुपये रहा।`
        : `In ${item.market}, today modal rate for ${cropName} is ${item.modalPrice} rupees per quintal. Min ${item.minPrice} and Max ${item.maxPrice}.`;

    setSpeakingId(item.id);
    speakText(
      text,
      lang,
      () => setSpeakingId(null),
      () => setSpeakingId(null)
    );
  };

  const handleSpeakComparison = () => {
    if (!comparisonStats) return;
    const cropLabel = selectedCropFilter !== 'all'
      ? popularCrops.find((c) => c.id === selectedCropFilter)?.label || 'पिकाचे'
      : 'या पिकाचे';

    const text =
      lang === 'mr'
        ? `${cropLabel} सर्व भागातील तुलना: एकूण ${comparisonStats.count} बाजारांची माहिती. सर्वोच्च भाव ${comparisonStats.highest.market} येथे ${comparisonStats.highest.modalPrice} रुपये आहे. सर्वात कमी भाव ${comparisonStats.lowest.market} येथे ${comparisonStats.lowest.modalPrice} रुपये आहे. सर्व भागातील सरासरी भाव ${comparisonStats.avgModal} रुपये प्रति क्विंटल आहे.`
        : `${cropLabel} सभी मंडियों की तुलना: कुल ${comparisonStats.count} मंडियों की रिपोर्ट। उच्चतम भाव ${comparisonStats.highest.market} में ${comparisonStats.highest.modalPrice} रुपये है। न्यूनतम भाव ${comparisonStats.lowest.market} में ${comparisonStats.lowest.modalPrice} रुपये है। औसत मॉडल भाव ${comparisonStats.avgModal} रुपये प्रति क्विंटल है।`;

    speakText(text, lang);
  };

  const handleMicVoiceSearch = () => {
    if (isListeningMic) return;
    const rec = new VoiceRecognition();
    if (rec.isAvailable()) {
      setIsListeningMic(true);
      rec.start(
        lang,
        (text: string) => {
          setSearchTerm(text);
          setIsListeningMic(false);
        },
        () => setIsListeningMic(false),
        () => setIsListeningMic(false)
      );
    } else {
      alert(
        lang === 'mr'
          ? 'मायक्रोफोन परवानगी उपलब्ध नाही. कृपया टाइप करा.'
          : 'माइक्रोफोन उपलब्ध नहीं है, कृपया लिखकर खोजें।'
      );
    }
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-200">
      {/* Title & Subtitle */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 sm:p-5 rounded-2xl shadow-xs border border-slate-200">
        <div>
          <div className="flex items-center gap-2">
            <span className="p-2 rounded-xl bg-amber-100 text-amber-800">
              <TrendingUp className="w-5 h-5" />
            </span>
            <h2 className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              {lang === 'mr' ? 'सर्व भागातील थेट बाजार भाव' : 'सभी मंडियों के लाइव भाव'}
            </h2>
            <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-extrabold text-[11px] animate-pulse">
              ● Live APMC
            </span>
          </div>
          <p className="text-xs sm:text-sm text-slate-500 font-medium mt-1">
            {lang === 'mr'
              ? 'कांदा, टोमॅटो, केळी, पपई, सोयाबीन इत्यादी पिकांचे सर्व भागांतील दर एकाच ठिकाणी'
              : 'प्याज, टमाटर, केला, पपीता, सोयाबीन आदि फसलों के सभी क्षेत्रों के भाव एक साथ देखें'}
          </p>
        </div>

        {/* Comparison Audio Summary Button */}
        {comparisonStats && (
          <button
            onClick={handleSpeakComparison}
            className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-amber-400 hover:bg-amber-300 text-amber-950 font-black text-xs sm:text-sm shadow-xs transition active:scale-95 shrink-0"
          >
            <Volume2 className="w-4 h-4" />
            <span>{lang === 'mr' ? 'तुलना ऐका (Audio)' : 'तुलना सुनें'}</span>
          </button>
        )}
      </div>

      {/* 1-Tap Crop Selection Horizontal Bar */}
      <div className="bg-white p-3 rounded-2xl shadow-xs border border-slate-200 space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-black text-slate-700 flex items-center gap-1.5">
            <BarChart3 className="w-4 h-4 text-emerald-700" />
            {lang === 'mr' ? 'पीक निवडा व सर्व भागातील दर पहा:' : 'फसल चुनें और सभी मंडियों के भाव देखें:'}
          </span>
          {selectedCropFilter !== 'all' && (
            <button
              onClick={() => {
                setSelectedCropFilter('all');
                setSearchTerm('');
              }}
              className="text-[11px] font-bold text-emerald-800 hover:underline"
            >
              {lang === 'mr' ? 'सर्व पिके पहा' : 'सभी फसलें देखें'}
            </button>
          )}
        </div>

        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
          {popularCrops.map((c) => {
            const isSelected = selectedCropFilter === c.id;
            return (
              <button
                key={c.id}
                onClick={() => {
                  setSelectedCropFilter(c.id);
                  setSearchTerm('');
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-black whitespace-nowrap transition-all shadow-xs flex items-center gap-1 ${
                  isSelected
                    ? 'bg-emerald-800 text-white ring-2 ring-emerald-500 scale-102'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                <span>{c.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Search Bar & Region Filters */}
      <div className="bg-white p-3.5 sm:p-4 rounded-2xl shadow-xs border border-slate-200 space-y-3">
        <div className="flex gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={
                lang === 'mr'
                  ? 'कोणतेही पीक किंवा बाजार समिती शोधा (उदा. कांदा, लासलगाव, पुणे, इंदूर, दिल्ली)...'
                  : 'फसल या मंडी खोजें (उदा. प्याज, लासलगांव, पुणे, इंदौर, आजादपुर)...'
              }
              className="w-full pl-9 pr-10 py-2.5 text-xs sm:text-sm rounded-xl border border-slate-300 focus:outline-none focus:ring-2 focus:ring-emerald-600 bg-slate-50 font-medium"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 text-xs font-bold"
              >
                ✕
              </button>
            )}
          </div>

          {/* Voice Search Button */}
          <button
            onClick={handleMicVoiceSearch}
            className={`p-2.5 rounded-xl border transition flex items-center justify-center shrink-0 ${
              isListeningMic
                ? 'bg-red-500 text-white border-red-600 animate-pulse'
                : 'bg-emerald-50 text-emerald-800 border-emerald-300 hover:bg-emerald-100'
            }`}
            title="बोलकर खोजें"
          >
            <Mic className="w-5 h-5" />
          </button>
        </div>

        {/* Region Filter Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pt-1">
          <span className="text-xs font-black text-slate-500 shrink-0 flex items-center gap-1">
            <Globe2 className="w-3.5 h-3.5 text-slate-400" />
            {lang === 'mr' ? 'विभाग:' : 'क्षेत्र:'}
          </span>
          {[
            { id: 'all', label: lang === 'mr' ? 'सर्व भाग (All Regions)' : 'सभी क्षेत्र' },
            { id: 'nashik', label: lang === 'mr' ? 'नाशिक विभाग' : 'नासिक मंडल' },
            { id: 'pune_west', label: lang === 'mr' ? 'पुणे व प. महाराष्ट्र' : 'पुणे व प. महाराष्ट्र' },
            { id: 'marathwada_khandesh', label: lang === 'mr' ? 'मराठवाडा व खान्देश' : 'मराठवाड़ा व खानदेश' },
            { id: 'other_states', label: lang === 'mr' ? 'इतर राज्ये (MP, Delhi, Guj)' : 'अन्य राज्य (MP, Delhi)' },
          ].map((region) => {
            const isSelected = selectedRegion === region.id;
            return (
              <button
                key={region.id}
                onClick={() => setSelectedRegion(region.id)}
                className={`px-3 py-1 rounded-lg text-xs font-black whitespace-nowrap transition ${
                  isSelected
                    ? 'bg-slate-900 text-white shadow-xs'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                }`}
              >
                {region.label}
              </button>
            );
          })}
        </div>
      </div>

      {/* REGIONAL COMPARISON DASHBOARD BANNER */}
      {comparisonStats && (
        <div className="bg-gradient-to-r from-amber-500 via-amber-600 to-emerald-700 rounded-2xl p-4 sm:p-5 text-white shadow-md space-y-3">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-white/20 pb-2.5">
            <div>
              <span className="text-[11px] font-black uppercase tracking-wider text-amber-200 block">
                {lang === 'mr' ? 'सर्व भागातील बाजारभाव तुलना' : 'अखिल भारतीय मंडी भाव तुलना'}
              </span>
              <h3 className="text-base sm:text-lg font-black text-white">
                {selectedCropFilter !== 'all'
                  ? popularCrops.find((c) => c.id === selectedCropFilter)?.label || 'निवडलेले पीक'
                  : lang === 'mr'
                  ? 'सर्व मंड्यांची स्थिती'
                  : 'सभी मंडियों का विश्लेषण'}
              </h3>
            </div>
            <span className="px-3 py-1 rounded-full bg-black/20 text-white font-extrabold text-xs self-start sm:self-auto">
              {comparisonStats.count} {lang === 'mr' ? 'मंड्यांचे दर' : 'मंडियों की रिपोर्ट'}
            </span>
          </div>

          <div className="grid grid-cols-3 gap-2 text-center">
            {/* Highest Rate */}
            <div className="bg-white/10 backdrop-blur-xs p-2.5 rounded-xl border border-white/20">
              <span className="text-[10px] sm:text-xs font-bold text-amber-200 block">
                🏆 {lang === 'mr' ? 'कमाल भाव (Highest)' : 'कमाल भाव (उच्चतम)'}
              </span>
              <span className="text-base sm:text-xl font-black text-white block mt-0.5">
                ₹{comparisonStats.highest.modalPrice}
              </span>
              <span className="text-[10px] font-medium text-amber-100 block truncate">
                {comparisonStats.highest.market.split('(')[0]}
              </span>
            </div>

            {/* Average Modal Rate */}
            <div className="bg-white/20 backdrop-blur-xs p-2.5 rounded-xl border border-white/30 shadow-xs">
              <span className="text-[10px] sm:text-xs font-bold text-white block">
                📊 {lang === 'mr' ? 'सरासरी दर (Average)' : 'औसत दर (मॉडल)'}
              </span>
              <span className="text-base sm:text-xl font-black text-amber-300 block mt-0.5">
                ₹{comparisonStats.avgModal}
              </span>
              <span className="text-[10px] font-medium text-white/80 block">
                प्रति क्विंटल
              </span>
            </div>

            {/* Lowest Rate */}
            <div className="bg-white/10 backdrop-blur-xs p-2.5 rounded-xl border border-white/20">
              <span className="text-[10px] sm:text-xs font-bold text-amber-200 block">
                📉 {lang === 'mr' ? 'किमान भाव (Lowest)' : 'न्यूनतम भाव'}
              </span>
              <span className="text-base sm:text-xl font-black text-white block mt-0.5">
                ₹{comparisonStats.lowest.modalPrice}
              </span>
              <span className="text-[10px] font-medium text-amber-100 block truncate">
                {comparisonStats.lowest.market.split('(')[0]}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* List of Mandis Across All Regions */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between px-1">
          <span className="text-xs font-black text-slate-700">
            {lang === 'mr'
              ? `उपलब्ध दर (${filteredList.length} बाजार समित्या)`
              : `उपलब्ध मंडियां (${filteredList.length} परिणाम)`}
          </span>
          <span className="text-[11px] text-slate-500 font-bold">
            {lang === 'mr' ? 'दर: रुपये प्रति क्विंटल' : 'दर: ₹ प्रति क्विंटल'}
          </span>
        </div>

        {filteredList.length === 0 ? (
          <div className="bg-white rounded-2xl p-8 text-center text-slate-500 border border-slate-200 space-y-2">
            <p className="font-bold text-sm">
              {lang === 'mr'
                ? 'कोणतेही बाजार भाव आढळले नाहीत.'
                : 'कोई मंडी भाव नहीं मिला।'}
            </p>
            <p className="text-xs">
              {lang === 'mr'
                ? 'कृपया दुसरे पीक किंवा विभाग निवडून पहा.'
                : 'कृपया अन्य फसल या क्षेत्र चुनकर देखें।'}
            </p>
          </div>
        ) : (
          filteredList.map((item) => {
            const isSpeakingThis = speakingId === item.id;
            return (
              <div
                key={item.id}
                className="bg-white rounded-2xl p-4 shadow-xs border border-slate-200 hover:border-emerald-300 transition-all space-y-2"
              >
                {/* Mandi & Crop Header */}
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="font-black text-slate-900 text-sm sm:text-base">
                        {item.crop[lang]}
                      </span>
                      <span className="px-2 py-0.5 rounded-md bg-emerald-100 text-emerald-800 text-[10px] font-black">
                        {item.state}
                      </span>
                    </div>
                    <div className="flex items-center gap-1 text-xs text-slate-600 font-bold mt-0.5">
                      <MapPin className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
                      <span>{item.market}</span>
                      <span className="text-slate-400">•</span>
                      <span>{item.district}</span>
                    </div>
                  </div>

                  {/* Audio Speaker Button */}
                  <button
                    onClick={() => handleSpeakItem(item)}
                    className={`p-2 rounded-xl transition ${
                      isSpeakingThis
                        ? 'bg-rose-500 text-white animate-pulse'
                        : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
                    }`}
                    title="भाव ऐका"
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                </div>

                {/* Price Display Grid */}
                <div className="grid grid-cols-3 gap-2 bg-slate-50 p-2.5 rounded-xl border border-slate-100 text-center">
                  <div>
                    <span className="text-[10px] text-slate-500 font-bold block">
                      {lang === 'mr' ? 'किमान' : 'न्यूनतम'}
                    </span>
                    <span className="text-xs sm:text-sm font-extrabold text-slate-700">
                      ₹{item.minPrice}
                    </span>
                  </div>

                  <div className="bg-white rounded-lg p-1 border border-emerald-200 shadow-2xs">
                    <span className="text-[10px] text-emerald-800 font-black block">
                      {lang === 'mr' ? 'सरासरी भाव' : 'मॉडल भाव'}
                    </span>
                    <span className="text-sm sm:text-base font-black text-emerald-700">
                      ₹{item.modalPrice}
                    </span>
                  </div>

                  <div>
                    <span className="text-[10px] text-slate-500 font-bold block">
                      {lang === 'mr' ? 'कमाल' : 'अधिकतम'}
                    </span>
                    <span className="text-xs sm:text-sm font-extrabold text-slate-700">
                      ₹{item.maxPrice}
                    </span>
                  </div>
                </div>

                {/* Footer with Arrival and Trend */}
                <div className="flex items-center justify-between text-xs text-slate-500 pt-1 font-medium">
                  <div className="flex items-center gap-1">
                    <Calendar className="w-3.5 h-3.5 text-slate-400" />
                    <span>{item.date}</span>
                    <span className="text-slate-400">•</span>
                    <span>{lang === 'mr' ? 'आवक:' : 'आवक:'} {item.arrival}</span>
                  </div>

                  <div className="flex items-center gap-1 font-bold">
                    {item.change >= 0 ? (
                      <span className="flex items-center text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
                        <TrendingUp className="w-3.5 h-3.5 mr-0.5" />
                        +₹{item.change}
                      </span>
                    ) : (
                      <span className="flex items-center text-rose-700 bg-rose-50 px-2 py-0.5 rounded-md">
                        <TrendingDown className="w-3.5 h-3.5 mr-0.5" />
                        ₹{item.change}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
