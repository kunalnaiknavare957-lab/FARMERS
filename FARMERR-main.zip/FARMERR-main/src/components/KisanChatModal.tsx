import React, { useState, useRef, useEffect } from 'react';
import {
  Sparkles,
  Send,
  Mic,
  MicOff,
  Volume2,
  X,
  Bot,
  User,
  Loader2,
} from 'lucide-react';
import { Language } from '../types';
import { translations } from '../translations';
import { speakText, stopSpeaking, VoiceRecognition } from '../utils/speech';

interface Message {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
}

interface KisanChatModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const KisanChatModal: React.FC<KisanChatModalProps> = ({
  isOpen,
  onClose,
  lang,
}) => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'welcome',
      sender: 'bot',
      text:
        lang === 'mr'
          ? 'राम राम शेतकरी दादा! मी तुमचा "किसान मित्र AI" सहाय्यक आहे. खते, औषध फवारणी, रोग किंवा बाजार भावाबाबत काहीही विचारा. तुम्ही माईक दाबून बोलू शकता.'
          : lang === 'hi'
          ? 'राम राम किसान भाई! मैं आपका "किसान मित्र AI" सहायक हूँ। फसल, खाद, दवा, बीमारी या सरकारी योजना के बारे में बोलकर या लिखकर सवाल पूछें।'
          : 'Namaste Farmer friend! I am your Kisan Mitra AI advisor. Ask me anything about fertilizers, crop diseases, spray doses, or schemes.',
      timestamp: 'Just now',
    },
  ]);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [speakingMessageId, setSpeakingMessageId] = useState<string | null>(null);

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const voiceRecRef = useRef<VoiceRecognition | null>(null);

  useEffect(() => {
    voiceRecRef.current = new VoiceRecognition();
    return () => {
      stopSpeaking();
      voiceRecRef.current?.stop();
    };
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isLoading]);

  if (!isOpen) return null;

  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend || inputText).trim();
    if (!text || isLoading) return;

    const userMsg: Message = {
      id: `u-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');
    setIsLoading(true);

    try {
      const res = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          lang,
        }),
      });

      const data = await res.json();
      const botReply =
        data.reply ||
        (lang === 'mr'
          ? 'माफ करा, तांत्रिक अडचणीमुळे उत्तर देता आले नाही. कृपया किसान कॉल सेंटर 1800-180-1551 वर कॉल करा.'
          : 'क्षमा करें, उत्तर देने में असमर्थ रहा। कृपया किसान कॉल सेंटर 1800-180-1551 पर कॉल करें।');

      const botMsg: Message = {
        id: `b-${Date.now()}`,
        sender: 'bot',
        text: botReply,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, botMsg]);

      // Auto-read bot response for illiterate farmers
      speakText(botReply, lang);
    } catch (err) {
      console.error('Chat error:', err);
      const fallbackMsg: Message = {
        id: `b-${Date.now()}`,
        sender: 'bot',
        text:
          lang === 'mr'
            ? 'पिकाच्या योग्य पोषणासाठी माती परीक्षण करून NPK व निंबोळी अर्क फवारा. अधिक माहितीसाठी 1800-180-1551 वर कॉल करा.'
            : 'फसल की अच्छी पैदावार के लिए संतुलित खाद दें और कीट दिखने पर तुरंत 5% नीम तेल का छिड़काव करें। हेल्पलाइन: 1800-180-1551।',
        timestamp: 'Just now',
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const toggleVoiceInput = () => {
    if (isListening) {
      voiceRecRef.current?.stop();
      setIsListening(false);
      return;
    }

    if (!voiceRecRef.current) return;

    setIsListening(true);
    voiceRecRef.current.start(
      lang,
      (transcript) => {
        setIsListening(false);
        setInputText(transcript);
        handleSendMessage(transcript);
      },
      () => {
        setIsListening(false);
      },
      () => {
        setIsListening(false);
      }
    );
  };

  const handleSpeak = (msg: Message) => {
    if (speakingMessageId === msg.id) {
      stopSpeaking();
      setSpeakingMessageId(null);
      return;
    }

    setSpeakingMessageId(msg.id);
    speakText(
      msg.text,
      lang,
      () => setSpeakingMessageId(null),
      () => setSpeakingMessageId(null)
    );
  };

  const quickQuestions = [
    translations.aiChat.sample1[lang],
    translations.aiChat.sample2[lang],
    translations.aiChat.sample3[lang],
    translations.aiChat.sample4[lang],
  ];

  return (
    <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-2 sm:p-4 backdrop-blur-xs">
      <div className="bg-white w-full max-w-xl h-[88vh] max-h-[700px] rounded-2xl shadow-2xl border-2 border-emerald-600 flex flex-col overflow-hidden animate-in zoom-in-95 duration-200">
        {/* Chat Header */}
        <div className="bg-emerald-800 text-white p-3.5 flex items-center justify-between shadow-md">
          <div className="flex items-center gap-2.5">
            <div className="w-9 h-9 rounded-xl bg-amber-400 text-slate-950 flex items-center justify-center font-bold">
              <Bot className="w-5 h-5 text-emerald-950" />
            </div>
            <div>
              <h3 className="font-black text-sm sm:text-base leading-tight">
                {translations.aiChat.modalTitle[lang]}
              </h3>
              <span className="text-[11px] text-emerald-200 font-medium">
                Gemini AI • {lang === 'mr' ? 'कृषी सल्लागार' : 'कृषि सलाहकार'}
              </span>
            </div>
          </div>

          <button
            onClick={() => {
              stopSpeaking();
              onClose();
            }}
            className="p-1.5 text-white hover:text-amber-300 font-bold rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Quick Questions Chips */}
        <div className="bg-emerald-50/80 px-3 py-2 border-b border-emerald-100 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          <span className="text-[11px] font-bold text-emerald-900 shrink-0">
            {lang === 'mr' ? 'सुचवलेले प्रश्न:' : 'पूछें:'}
          </span>
          {quickQuestions.map((q, idx) => (
            <button
              key={idx}
              onClick={() => handleSendMessage(q)}
              className="whitespace-nowrap px-2.5 py-1 bg-white hover:bg-emerald-100 text-emerald-900 text-xs font-semibold rounded-full border border-emerald-300 transition"
            >
              {q}
            </button>
          ))}
        </div>

        {/* Messages Scroll Area */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3.5 bg-slate-50/50">
          {messages.map((msg) => {
            const isBot = msg.sender === 'bot';
            const isSpeaking = speakingMessageId === msg.id;

            return (
              <div
                key={msg.id}
                className={`flex gap-2.5 ${isBot ? 'items-start' : 'items-end justify-end'}`}
              >
                {isBot && (
                  <div className="w-8 h-8 rounded-lg bg-emerald-700 text-white flex items-center justify-center shrink-0 text-xs font-bold mt-1">
                    🌾
                  </div>
                )}

                <div
                  className={`max-w-[85%] rounded-2xl p-3 text-xs sm:text-sm leading-relaxed ${
                    isBot
                      ? 'bg-white text-slate-800 border border-slate-200 shadow-xs'
                      : 'bg-emerald-700 text-white font-medium rounded-br-xs'
                  }`}
                >
                  <div className="whitespace-pre-line">{msg.text}</div>

                  <div className="flex items-center justify-between gap-2 mt-2 pt-1 border-t border-slate-100/30 text-[10px] text-slate-400">
                    <span>{msg.timestamp}</span>

                    {isBot && (
                      <button
                        onClick={() => handleSpeak(msg)}
                        className={`p-1 rounded-md transition ${
                          isSpeaking
                            ? 'bg-red-500 text-white'
                            : 'text-emerald-700 hover:bg-emerald-50'
                        }`}
                        title="Listen"
                      >
                        <Volume2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                {!isBot && (
                  <div className="w-8 h-8 rounded-lg bg-slate-700 text-white flex items-center justify-center shrink-0 text-xs font-bold">
                    <User className="w-4 h-4" />
                  </div>
                )}
              </div>
            );
          })}

          {isLoading && (
            <div className="flex items-center gap-2 text-slate-500 text-xs font-semibold p-2">
              <Loader2 className="w-4 h-4 animate-spin text-emerald-700" />
              <span>
                {lang === 'mr' ? 'कृषी AI उत्तर लिहीत आहे...' : 'कृषि AI उत्तर लिख रहा है...'}
              </span>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Bar with Mic & Send */}
        <div className="p-3 bg-white border-t border-slate-200">
          {isListening && (
            <div className="text-center text-xs font-bold text-red-600 mb-2 animate-pulse">
              🎙️ {translations.aiChat.listening[lang]}
            </div>
          )}

          <div className="flex items-center gap-2">
            <button
              onClick={toggleVoiceInput}
              className={`p-3 rounded-xl transition shadow-xs flex items-center justify-center ${
                isListening
                  ? 'bg-red-600 text-white animate-pulse'
                  : 'bg-amber-400 hover:bg-amber-500 text-slate-950 font-bold'
              }`}
              title="माइक दबाकर बोलें (Voice input)"
            >
              {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
            </button>

            <input
              type="text"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') handleSendMessage();
              }}
              placeholder={translations.aiChat.placeholder[lang]}
              className="flex-1 px-4 py-3 bg-slate-50 border-2 border-emerald-300 rounded-xl text-xs sm:text-sm font-medium focus:outline-hidden focus:border-emerald-600"
            />

            <button
              onClick={() => handleSendMessage()}
              disabled={!inputText.trim() || isLoading}
              className="p-3 bg-emerald-700 hover:bg-emerald-800 disabled:bg-slate-300 text-white rounded-xl shadow-xs transition active:scale-95"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
