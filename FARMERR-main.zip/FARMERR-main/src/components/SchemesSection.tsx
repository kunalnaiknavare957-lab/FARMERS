import React, { useState } from 'react';
import {
  FileText,
  CheckCircle,
  ExternalLink,
  PhoneCall,
  Volume2,
  ChevronDown,
  ChevronUp,
  Award,
} from 'lucide-react';
import { Language, SchemeItem } from '../types';
import { SCHEMES_DATA } from '../data/schemesData';
import { translations } from '../translations';
import { speakText, stopSpeaking } from '../utils/speech';

interface SchemesSectionProps {
  lang: Language;
}

export const SchemesSection: React.FC<SchemesSectionProps> = ({ lang }) => {
  const [expandedId, setExpandedId] = useState<string>('pm-kisan');
  const [activeTabMap, setActiveTabMap] = useState<Record<string, 'benefits' | 'eligibility' | 'docs' | 'apply'>>({
    'pm-kisan': 'benefits',
  });
  const [speakingId, setSpeakingId] = useState<string | null>(null);

  const handleToggleExpand = (id: string) => {
    setExpandedId(expandedId === id ? '' : id);
  };

  const handleTabChange = (schemeId: string, tab: 'benefits' | 'eligibility' | 'docs' | 'apply') => {
    setActiveTabMap((prev) => ({ ...prev, [schemeId]: tab }));
  };

  const handleSpeakScheme = (item: SchemeItem, e: React.MouseEvent) => {
    e.stopPropagation();
    if (speakingId === item.id) {
      stopSpeaking();
      setSpeakingId(null);
      return;
    }

    const title = item.title[lang];
    const benefit = item.benefit[lang];
    const text = `${title}. ${benefit}.`;

    setSpeakingId(item.id);
    speakText(
      text,
      lang,
      () => setSpeakingId(null),
      () => setSpeakingId(null)
    );
  };

  return (
    <section className="space-y-4">
      {/* Title Card */}
      <div className="bg-gradient-to-r from-emerald-800 to-teal-900 text-white rounded-2xl p-4 shadow-md border-l-6 border-amber-400">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl sm:text-2xl font-black flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-amber-400 text-emerald-950">
                <FileText className="w-5 h-5" />
              </span>
              {translations.schemes.title[lang]}
            </h2>
            <p className="text-emerald-100 text-xs sm:text-sm mt-0.5">
              {translations.schemes.subtitle[lang]}
            </p>
          </div>
        </div>
      </div>

      {/* Schemes Accordion List */}
      <div className="space-y-3">
        {SCHEMES_DATA.map((scheme) => {
          const isExpanded = expandedId === scheme.id;
          const currentTab = activeTabMap[scheme.id] || 'benefits';
          const isSpeaking = speakingId === scheme.id;

          return (
            <div
              key={scheme.id}
              className="bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden transition-all"
            >
              {/* Scheme Card Header (Click to expand) */}
              <div
                onClick={() => handleToggleExpand(scheme.id)}
                className="p-4 flex items-start justify-between gap-3 cursor-pointer hover:bg-slate-50 transition"
              >
                <div className="flex-1">
                  <div className="flex flex-wrap items-center gap-2 mb-1.5">
                    <span className="inline-flex items-center gap-1 bg-amber-100 text-amber-900 font-extrabold text-xs px-2.5 py-0.5 rounded-full border border-amber-300">
                      <Award className="w-3.5 h-3.5 text-amber-700" />
                      {scheme.badge[lang]}
                    </span>
                  </div>

                  <h3 className="text-base sm:text-lg font-black text-slate-900 leading-tight">
                    {scheme.title[lang]}
                  </h3>
                  <p className="text-xs sm:text-sm text-slate-600 line-clamp-1 mt-1 font-medium">
                    {scheme.benefit[lang]}
                  </p>
                </div>

                <div className="flex items-center gap-1.5 shrink-0">
                  <button
                    onClick={(e) => handleSpeakScheme(scheme, e)}
                    className={`p-2 rounded-xl transition ${
                      isSpeaking
                        ? 'bg-red-500 text-white animate-pulse'
                        : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
                    }`}
                    title="Listen to Scheme Details"
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>

                  <div className="p-2 text-slate-400">
                    {isExpanded ? (
                      <ChevronUp className="w-5 h-5" />
                    ) : (
                      <ChevronDown className="w-5 h-5" />
                    )}
                  </div>
                </div>
              </div>

              {/* Expanded Details Body */}
              {isExpanded && (
                <div className="px-4 pb-4 border-t border-slate-100 pt-3">
                  {/* Internal Tabs */}
                  <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-2.5">
                    <button
                      onClick={() => handleTabChange(scheme.id, 'benefits')}
                      className={`whitespace-nowrap px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                        currentTab === 'benefits'
                          ? 'bg-emerald-800 text-white shadow-xs'
                          : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                      }`}
                    >
                      {translations.schemes.benefits[lang]}
                    </button>

                    <button
                      onClick={() => handleTabChange(scheme.id, 'eligibility')}
                      className={`whitespace-nowrap px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                        currentTab === 'eligibility'
                          ? 'bg-emerald-800 text-white shadow-xs'
                          : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                      }`}
                    >
                      {translations.schemes.eligibility[lang]}
                    </button>

                    <button
                      onClick={() => handleTabChange(scheme.id, 'docs')}
                      className={`whitespace-nowrap px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                        currentTab === 'docs'
                          ? 'bg-emerald-800 text-white shadow-xs'
                          : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                      }`}
                    >
                      {translations.schemes.documents[lang]}
                    </button>

                    <button
                      onClick={() => handleTabChange(scheme.id, 'apply')}
                      className={`whitespace-nowrap px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                        currentTab === 'apply'
                          ? 'bg-emerald-800 text-white shadow-xs'
                          : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                      }`}
                    >
                      {translations.schemes.applySteps[lang]}
                    </button>
                  </div>

                  {/* Tab Content Box */}
                  <div className="bg-slate-50 rounded-xl p-3.5 border border-slate-200 text-sm">
                    {currentTab === 'benefits' && (
                      <div className="space-y-2">
                        <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wider">
                          {translations.schemes.benefits[lang]}
                        </h4>
                        <p className="text-slate-700 leading-relaxed font-medium">
                          {scheme.benefit[lang]}
                        </p>
                      </div>
                    )}

                    {currentTab === 'eligibility' && (
                      <div className="space-y-2">
                        <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wider">
                          {translations.schemes.eligibility[lang]}
                        </h4>
                        <ul className="space-y-1.5">
                          {scheme.eligibility[lang].map((rule, idx) => (
                            <li key={idx} className="flex items-start gap-2 text-slate-700">
                              <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                              <span className="font-medium">{rule}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {currentTab === 'docs' && (
                      <div className="space-y-2">
                        <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wider">
                          {translations.schemes.documents[lang]}
                        </h4>
                        <ul className="space-y-1.5">
                          {scheme.documents[lang].map((doc, idx) => (
                            <li key={idx} className="flex items-start gap-2 text-slate-700">
                              <div className="w-2 h-2 rounded-full bg-emerald-600 mt-2 shrink-0" />
                              <span className="font-semibold">{doc}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}

                    {currentTab === 'apply' && (
                      <div className="space-y-2">
                        <h4 className="font-bold text-slate-900 text-xs uppercase tracking-wider">
                          {translations.schemes.applySteps[lang]}
                        </h4>
                        <ul className="space-y-2">
                          {scheme.howToApply[lang].map((step, idx) => (
                            <li key={idx} className="bg-white p-2.5 rounded-lg border border-slate-200 text-slate-700 font-medium">
                              {step}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </div>

                  {/* Actions: Portal Link & Scheme Helpline */}
                  <div className="flex flex-wrap items-center justify-between gap-2 mt-3 pt-2">
                    <a
                      href={scheme.portalUrl}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs shadow-xs transition active:scale-95"
                    >
                      <ExternalLink className="w-4 h-4" />
                      <span>{translations.schemes.applyOnline[lang]}</span>
                    </a>

                    <a
                      href={`tel:${scheme.helpline.replace(/[^0-9]/g, '')}`}
                      className="inline-flex items-center gap-1.5 px-3 py-2 bg-blue-50 hover:bg-blue-100 text-blue-900 border border-blue-200 rounded-xl font-bold text-xs transition"
                    >
                      <PhoneCall className="w-3.5 h-3.5 text-blue-700" />
                      <span>{scheme.helpline}</span>
                    </a>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
};
