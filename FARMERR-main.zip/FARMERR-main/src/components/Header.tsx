import React, { useState } from 'react';
import { PhoneCall, Volume2, Globe, Wifi, WifiOff, Download, Smartphone } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../translations';
import { speakText, stopSpeaking } from '../utils/speech';

interface HeaderProps {
  lang: Language;
  onLanguageChange: (lang: Language) => void;
  isOffline: boolean;
  onOpenHelpline: () => void;
  onOpenDownloadModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  lang,
  onLanguageChange,
  isOffline,
  onOpenHelpline,
  onOpenDownloadModal,
}) => {
  const [isPlayingAudio, setIsPlayingAudio] = React.useState(false);

  const handleAudioSummary = () => {
    if (isPlayingAudio) {
      stopSpeaking();
      setIsPlayingAudio(false);
      return;
    }

    const welcomeText =
      lang === 'mr'
        ? 'शेतकरी मित्र पोर्टलवर आपले स्वागत आहे. येथे तुम्हाला रोजचे बाजार भाव, हवामान अंदाज, पीक सल्ला आणि सरकारी योजनांची माहिती मिळेल.'
        : lang === 'hi'
        ? 'किसान मित्र पोर्टल पर आपका स्वागत है। यहाँ आपको दैनिक मंडी भाव, मौसम की ताजा जानकारी, फसल डॉक्टर और सरकारी योजनाओं की पूरी जानकारी मिलेगी।'
        : 'Welcome to Kisan Mitra Portal. Access daily mandi rates, agricultural weather, crop doctor and government schemes.';

    setIsPlayingAudio(true);
    speakText(
      welcomeText,
      lang,
      () => setIsPlayingAudio(false),
      () => setIsPlayingAudio(false)
    );
  };

  return (
    <header className="sticky top-0 z-40 bg-emerald-800 text-white shadow-md border-b-4 border-emerald-600">
      {/* Top Banner with Helpline & Language switch */}
      <div className="max-w-6xl mx-auto px-3 py-2 flex flex-wrap items-center justify-between gap-2 border-b border-emerald-700/60 text-xs sm:text-sm">
        {/* Kisan Call Centre Quick Dial */}
        <a
          href="tel:18001801551"
          className="inline-flex items-center gap-1.5 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold px-3 py-1.5 rounded-full shadow transition-transform active:scale-95"
          title="Kisan Call Centre Toll Free"
        >
          <PhoneCall className="w-3.5 h-3.5 animate-pulse" />
          <span>कॉल सेंटर: 1800-180-1551 (टोल-फ्री)</span>
        </a>

        {/* Offline indicator & Language Switcher */}
        <div className="flex items-center gap-2">
          {isOffline && (
            <span className="inline-flex items-center gap-1 bg-red-600 text-white px-2 py-0.5 rounded text-xs font-semibold">
              <WifiOff className="w-3 h-3" />
              ऑफ़लाइन
            </span>
          )}

          {/* Audio helper button */}
          <button
            onClick={handleAudioSummary}
            className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-semibold transition ${
              isPlayingAudio
                ? 'bg-red-500 text-white animate-pulse'
                : 'bg-emerald-700 hover:bg-emerald-600 text-emerald-100'
            }`}
            title="Read Summary Aloud"
          >
            <Volume2 className="w-3.5 h-3.5" />
            <span>{isPlayingAudio ? (lang === 'mr' ? 'थांबवा' : 'रोकें') : (lang === 'mr' ? 'ऐका' : 'सुनें')}</span>
          </button>

          {/* Language selector pills */}
          <div className="inline-flex items-center bg-emerald-900/80 p-0.5 rounded-full border border-emerald-600">
            <button
              onClick={() => onLanguageChange('hi')}
              className={`px-2.5 py-1 rounded-full font-bold text-xs transition ${
                lang === 'hi'
                  ? 'bg-white text-emerald-900 shadow'
                  : 'text-emerald-200 hover:text-white'
              }`}
            >
              हिंदी
            </button>
            <button
              onClick={() => onLanguageChange('mr')}
              className={`px-2.5 py-1 rounded-full font-bold text-xs transition ${
                lang === 'mr'
                  ? 'bg-white text-emerald-900 shadow'
                  : 'text-emerald-200 hover:text-white'
              }`}
            >
              मराठी
            </button>
            <button
              onClick={() => onLanguageChange('en')}
              className={`px-2.5 py-1 rounded-full font-bold text-xs transition ${
                lang === 'en'
                  ? 'bg-white text-emerald-900 shadow'
                  : 'text-emerald-200 hover:text-white'
              }`}
            >
              ENG
            </button>
          </div>
        </div>
      </div>

      {/* Main Header Bar */}
      <div className="max-w-6xl mx-auto px-4 py-2.5 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <div className="w-10 h-10 rounded-xl bg-amber-400 flex items-center justify-center text-emerald-950 font-black text-xl shadow-inner border border-amber-300">
            🌾
          </div>
          <div>
            <h1 className="text-xl sm:text-2xl font-black tracking-tight leading-none text-white">
              {translations.appName[lang]}
            </h1>
            <p className="text-xs sm:text-sm text-emerald-200 font-medium">
              {translations.appTagline[lang]}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {/* Download / Install App Button */}
          <button
            onClick={onOpenDownloadModal}
            className="inline-flex items-center gap-1.5 bg-gradient-to-r from-amber-400 to-amber-500 hover:from-amber-300 hover:to-amber-400 text-amber-950 font-black text-xs px-3.5 py-2 rounded-xl shadow-md transition-transform active:scale-95"
            title="Download / Install Mobile App"
          >
            <Download className="w-4 h-4" />
            <span>{lang === 'mr' ? 'ॲप डाऊनलोड' : lang === 'hi' ? 'ऐप डाउनलोड' : 'Download App'}</span>
          </button>

          <button
            onClick={onOpenHelpline}
            className="hidden sm:inline-flex items-center gap-1.5 bg-emerald-700 hover:bg-emerald-600 text-white font-semibold text-xs px-3 py-2 rounded-xl border border-emerald-500 transition shadow"
          >
            <PhoneCall className="w-3.5 h-3.5 text-amber-300" />
            <span>{translations.nav.helpline[lang]}</span>
          </button>
        </div>
      </div>
    </header>
  );
};
