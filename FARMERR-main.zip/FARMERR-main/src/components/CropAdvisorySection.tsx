import React, { useState } from 'react';
import { Wheat, Volume2, Calendar, Sprout, Droplets, Sparkles } from 'lucide-react';
import { Language, CropGuide } from '../types';
import { CROP_ADVISORY_DATA } from '../data/cropAdvisoryData';
import { translations } from '../translations';
import { speakText, stopSpeaking } from '../utils/speech';

interface CropAdvisorySectionProps {
  lang: Language;
}

export const CropAdvisorySection: React.FC<CropAdvisorySectionProps> = ({ lang }) => {
  const [selectedSeason, setSelectedSeason] = useState<'all' | 'kharif' | 'rabi' | 'zaid'>('all');
  const [speakingId, setSpeakingId] = useState<string | null>(null);

  const filteredCrops = CROP_ADVISORY_DATA.filter((c) => {
    if (selectedSeason === 'all') return true;
    return c.season === selectedSeason;
  });

  const handleSpeakCrop = (crop: CropGuide) => {
    if (speakingId === crop.id) {
      stopSpeaking();
      setSpeakingId(null);
      return;
    }

    const title = crop.name[lang];
    const sowing = crop.sowingMonths[lang];
    const fert = crop.fertilizerDose[lang];
    const tip = crop.topTip[lang];
    const text = `${title}. ${translations.advisory.sowingTime[lang]}: ${sowing}. ${translations.advisory.fertilizerDose[lang]}: ${fert}. ${tip}.`;

    setSpeakingId(crop.id);
    speakText(
      text,
      lang,
      () => setSpeakingId(null),
      () => setSpeakingId(null)
    );
  };

  return (
    <section className="space-y-4">
      {/* Title Card */}
      <div className="bg-gradient-to-r from-lime-800 to-emerald-900 text-white rounded-2xl p-4 shadow-md border-l-6 border-lime-400">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl sm:text-2xl font-black flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-lime-400 text-lime-950">
                <Wheat className="w-5 h-5" />
              </span>
              {translations.advisory.title[lang]}
            </h2>
            <p className="text-lime-100 text-xs sm:text-sm mt-0.5">
              {lang === 'mr'
                ? 'पेरणीची योग्य वेळ, खतांचे प्रमाण, पाणी देण्याचे टप्पे व अपेक्षित उत्पादन'
                : lang === 'hi'
                ? 'बुआई का सही समय, खाद की मात्रा, सिंचाई के चरण और उपज'
                : 'Sowing calendar, fertilizer dosages, critical irrigation stages and yields'}
            </p>
          </div>
        </div>
      </div>

      {/* Season Filter Chips */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
        <button
          onClick={() => setSelectedSeason('all')}
          className={`whitespace-nowrap px-4 py-2 rounded-xl text-xs font-bold transition ${
            selectedSeason === 'all'
              ? 'bg-emerald-800 text-white shadow-xs'
              : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-300'
          }`}
        >
          {lang === 'mr' ? 'सर्व पिके' : 'सभी फसलें'}
        </button>

        <button
          onClick={() => setSelectedSeason('rabi')}
          className={`whitespace-nowrap px-4 py-2 rounded-xl text-xs font-bold transition ${
            selectedSeason === 'rabi'
              ? 'bg-amber-500 text-slate-950 shadow-xs'
              : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-300'
          }`}
        >
          {translations.advisory.rabi[lang]}
        </button>

        <button
          onClick={() => setSelectedSeason('kharif')}
          className={`whitespace-nowrap px-4 py-2 rounded-xl text-xs font-bold transition ${
            selectedSeason === 'kharif'
              ? 'bg-emerald-600 text-white shadow-xs'
              : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-300'
          }`}
        >
          {translations.advisory.kharif[lang]}
        </button>

        <button
          onClick={() => setSelectedSeason('zaid')}
          className={`whitespace-nowrap px-4 py-2 rounded-xl text-xs font-bold transition ${
            selectedSeason === 'zaid'
              ? 'bg-blue-600 text-white shadow-xs'
              : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-300'
          }`}
        >
          {translations.advisory.zaid[lang]}
        </button>
      </div>

      {/* Crop Guides Accordion / Card List */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {filteredCrops.map((crop) => {
          const isSpeaking = speakingId === crop.id;

          return (
            <div
              key={crop.id}
              className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-sm flex flex-col justify-between"
            >
              <div>
                {/* Header */}
                <div className="flex items-start justify-between gap-2 border-b border-slate-100 pb-3">
                  <div>
                    <span className="inline-block px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-amber-100 text-amber-900 mb-1">
                      {crop.season === 'rabi'
                        ? translations.advisory.rabi[lang]
                        : translations.advisory.kharif[lang]}
                    </span>
                    <h3 className="text-xl font-black text-slate-900">
                      {crop.name[lang]}
                    </h3>
                  </div>

                  <button
                    onClick={() => handleSpeakCrop(crop)}
                    className={`p-2.5 rounded-xl transition ${
                      isSpeaking
                        ? 'bg-red-500 text-white animate-pulse'
                        : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
                    }`}
                    title="Listen Crop Guide"
                  >
                    <Volume2 className="w-5 h-5" />
                  </button>
                </div>

                {/* Sowing & Seed Rate */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mt-3 text-xs">
                  <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                    <span className="text-slate-500 font-bold block">
                      {translations.advisory.sowingTime[lang]}:
                    </span>
                    <span className="font-bold text-slate-800">
                      {crop.sowingMonths[lang]}
                    </span>
                  </div>

                  <div className="bg-slate-50 p-2.5 rounded-xl border border-slate-200">
                    <span className="text-slate-500 font-bold block">
                      {translations.advisory.seedRate[lang]}:
                    </span>
                    <span className="font-bold text-slate-800">
                      {crop.seedRate[lang]}
                    </span>
                  </div>
                </div>

                {/* Seed Treatment */}
                <div className="mt-2.5 p-2.5 bg-amber-50/70 rounded-xl border border-amber-200/80 text-xs">
                  <span className="font-bold text-amber-900 block flex items-center gap-1">
                    <Sprout className="w-3.5 h-3.5 text-amber-700" />
                    {translations.advisory.seedTreatment[lang]}:
                  </span>
                  <span className="text-slate-700 font-medium mt-0.5 block">
                    {crop.seedTreatment[lang]}
                  </span>
                </div>

                {/* Fertilizer Dose */}
                <div className="mt-2.5 p-2.5 bg-emerald-50/70 rounded-xl border border-emerald-200/80 text-xs">
                  <span className="font-bold text-emerald-900 block">
                    {translations.advisory.fertilizerDose[lang]}:
                  </span>
                  <span className="text-slate-800 font-bold mt-0.5 block">
                    {crop.fertilizerDose[lang]}
                  </span>
                </div>

                {/* Irrigation Stages */}
                <div className="mt-2.5 text-xs">
                  <span className="font-bold text-blue-900 block mb-1 flex items-center gap-1">
                    <Droplets className="w-3.5 h-3.5 text-blue-600" />
                    {translations.advisory.irrigation[lang]}:
                  </span>
                  <ul className="space-y-1 text-slate-700 font-medium pl-1">
                    {crop.irrigationSchedule[lang].map((stage, idx) => (
                      <li key={idx} className="flex items-start gap-1.5">
                        <span className="text-blue-500">•</span>
                        <span>{stage}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Bottom Tip & Yield */}
              <div className="mt-3 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2 text-xs">
                <div className="text-emerald-900 font-bold">
                  {translations.advisory.yield[lang]}:{' '}
                  <span className="text-slate-900 font-black">{crop.expectedYield[lang]}</span>
                </div>
                <div className="w-full text-[11px] text-slate-600 bg-amber-50/60 p-2 rounded-lg border border-amber-200/50">
                  <span className="font-bold text-amber-900">💡 खास सल्ला: </span>
                  {crop.topTip[lang]}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
};
