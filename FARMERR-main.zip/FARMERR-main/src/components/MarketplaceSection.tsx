import React, { useState, useEffect } from 'react';
import {
  ShoppingBag,
  PlusCircle,
  PhoneCall,
  MessageCircle,
  MapPin,
  Calendar,
  X,
  CheckCircle2,
} from 'lucide-react';
import { Language, MarketListing } from '../types';
import { INITIAL_MARKETPLACE_DATA } from '../data/marketplaceData';
import { translations } from '../translations';

interface MarketplaceSectionProps {
  lang: Language;
}

export const MarketplaceSection: React.FC<MarketplaceSectionProps> = ({ lang }) => {
  const [listings, setListings] = useState<MarketListing[]>(() => {
    const saved = localStorage.getItem('kisan_mitra_marketplace');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch {
        return INITIAL_MARKETPLACE_DATA;
      }
    }
    return INITIAL_MARKETPLACE_DATA;
  });

  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [showPostModal, setShowPostModal] = useState<boolean>(false);
  const [postSuccess, setPostSuccess] = useState<boolean>(false);

  // New ad form state
  const [title, setTitle] = useState('');
  const [category, setCategory] = useState<MarketListing['category']>('seeds');
  const [price, setPrice] = useState('');
  const [unit, setUnit] = useState('प्रति किलो');
  const [quantity, setQuantity] = useState('');
  const [sellerName, setSellerName] = useState('');
  const [phone, setPhone] = useState('');
  const [village, setVillage] = useState('');
  const [district, setDistrict] = useState('');
  const [description, setDescription] = useState('');

  // Persist to local storage
  useEffect(() => {
    localStorage.setItem('kisan_mitra_marketplace', JSON.stringify(listings));
  }, [listings]);

  const handlePostAd = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !phone || !price) return;

    const newAd: MarketListing = {
      id: `mkt-custom-${Date.now()}`,
      title,
      category,
      price: Number(price) || 0,
      unit: unit || 'प्रति नग',
      quantity: quantity || 'उपलब्ध',
      sellerName: sellerName || (lang === 'mr' ? 'शेतकरी बंधू' : 'किसान भाई'),
      phone,
      village: village || 'स्थानिक गाव',
      district: district || 'जिल्हा',
      state: 'Maharashtra',
      date: 'आज (Today)',
      description,
      isUserAdded: true,
    };

    setListings([newAd, ...listings]);
    setPostSuccess(true);
    setTimeout(() => {
      setPostSuccess(false);
      setShowPostModal(false);
      // Reset form
      setTitle('');
      setPrice('');
      setQuantity('');
      setDescription('');
    }, 1500);
  };

  const filteredListings = listings.filter((item) => {
    if (filterCategory === 'all') return true;
    return item.category === filterCategory;
  });

  return (
    <section className="space-y-4">
      {/* Title Card */}
      <div className="bg-gradient-to-r from-emerald-800 to-amber-900 text-white rounded-2xl p-4 shadow-md border-l-6 border-amber-400">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <h2 className="text-xl sm:text-2xl font-black flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-amber-400 text-emerald-950">
                <ShoppingBag className="w-5 h-5" />
              </span>
              {translations.market.title[lang]}
            </h2>
            <p className="text-amber-100 text-xs sm:text-sm mt-0.5">
              {translations.market.subtitle[lang]}
            </p>
          </div>

          <button
            onClick={() => setShowPostModal(true)}
            className="px-4 py-2.5 bg-amber-400 hover:bg-amber-300 text-slate-950 font-black rounded-xl text-xs sm:text-sm shadow-md transition active:scale-95 flex items-center gap-1.5"
          >
            <PlusCircle className="w-4 h-4" />
            <span>{translations.market.postAd[lang]}</span>
          </button>
        </div>
      </div>

      {/* Category Filter Chips */}
      <div className="flex items-center gap-2 overflow-x-auto no-scrollbar py-1">
        {[
          { id: 'all', label: translations.market.filterAll[lang] },
          { id: 'seeds', label: translations.market.filterSeeds[lang] },
          { id: 'fertilizer', label: translations.market.filterFertilizer[lang] },
          { id: 'equipment', label: translations.market.filterEquipment[lang] },
          { id: 'cattle', label: translations.market.filterCattle[lang] },
          { id: 'crops', label: translations.market.filterCrops[lang] },
        ].map((f) => (
          <button
            key={f.id}
            onClick={() => setFilterCategory(f.id)}
            className={`whitespace-nowrap px-3.5 py-1.5 rounded-xl text-xs font-bold transition ${
              filterCategory === f.id
                ? 'bg-emerald-800 text-white shadow-xs'
                : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-300'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Marketplace Listings Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
        {filteredListings.map((item) => (
          <div
            key={item.id}
            className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm hover:shadow-md transition flex flex-col justify-between"
          >
            <div>
              <div className="flex items-start justify-between gap-2">
                <span className="inline-block px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-100 text-emerald-800 uppercase">
                  {item.category}
                </span>
                <span className="text-[11px] text-slate-400 flex items-center gap-1">
                  <Calendar className="w-3 h-3" />
                  {item.date}
                </span>
              </div>

              <h3 className="text-base sm:text-lg font-black text-slate-900 mt-2 leading-tight">
                {item.title}
              </h3>

              <div className="mt-2 text-2xl font-black text-emerald-900">
                ₹{item.price.toLocaleString('en-IN')}
                <span className="text-xs font-semibold text-slate-600 ml-1">
                  / {item.unit}
                </span>
              </div>

              <div className="mt-1 text-xs font-bold text-amber-700">
                {item.quantity}
              </div>

              <p className="mt-2 text-xs text-slate-600 line-clamp-2 font-medium">
                {item.description}
              </p>
            </div>

            {/* Seller Info & Contact Buttons */}
            <div className="mt-4 pt-3 border-t border-slate-100">
              <div className="flex items-center justify-between text-xs text-slate-600 mb-2.5">
                <span className="font-bold text-slate-800">{item.sellerName}</span>
                <span className="flex items-center gap-1">
                  <MapPin className="w-3 h-3 text-emerald-600" />
                  {item.village}, {item.district}
                </span>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <a
                  href={`tel:${item.phone}`}
                  className="flex items-center justify-center gap-1.5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white font-bold rounded-xl text-xs shadow-xs transition active:scale-95"
                >
                  <PhoneCall className="w-4 h-4" />
                  <span>{translations.market.callSeller[lang]}</span>
                </a>

                <a
                  href={`https://wa.me/91${item.phone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                    `Namaste ${item.sellerName}, I saw your ad for "${item.title}" on Kisan Mitra.`
                  )}`}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-1.5 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-white font-bold rounded-xl text-xs shadow-xs transition active:scale-95"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>{translations.market.whatsappSeller[lang]}</span>
                </a>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Post Free Ad Modal */}
      {showPostModal && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-3 backdrop-blur-xs">
          <div className="bg-white w-full max-w-lg rounded-2xl shadow-2xl border-2 border-emerald-600 overflow-hidden max-h-[90vh] flex flex-col animate-in zoom-in-95 duration-200">
            <div className="bg-emerald-800 text-white p-4 flex items-center justify-between">
              <h3 className="font-black text-lg">
                {translations.market.postAd[lang]}
              </h3>
              <button
                onClick={() => setShowPostModal(false)}
                className="text-white hover:text-amber-300 font-bold p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {postSuccess ? (
              <div className="p-8 text-center space-y-2">
                <CheckCircle2 className="w-16 h-16 text-emerald-600 mx-auto" />
                <h4 className="text-xl font-bold text-slate-800">
                  {lang === 'mr' ? 'जाहिरात यशस्वीरित्या प्रसिद्ध झाली!' : 'विज्ञापन सफलतापूर्वक पोस्ट हो गया!'}
                </h4>
              </div>
            ) : (
              <form onSubmit={handlePostAd} className="p-4 overflow-y-auto space-y-3 text-xs sm:text-sm">
                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    {lang === 'mr' ? 'वस्तू / पिकाचे नाव' : 'सामान / फसल का नाम'} *
                  </label>
                  <input
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="उदा. लाल कांदा बियाणे, ट्रॅक्टर भाड्याने"
                    className="w-full px-3 py-2 border rounded-xl font-medium focus:outline-hidden focus:border-emerald-600"
                  />
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      {lang === 'mr' ? 'प्रकार (Category)' : 'श्रेणी (Category)'}
                    </label>
                    <select
                      value={category}
                      onChange={(e) => setCategory(e.target.value as any)}
                      className="w-full px-3 py-2 border rounded-xl font-medium"
                    >
                      <option value="seeds">बियाणे (Seeds)</option>
                      <option value="fertilizer">खते (Fertilizer)</option>
                      <option value="equipment">अवजारे / ट्रॅक्टर (Equipment)</option>
                      <option value="cattle">जनावरे (Cattle)</option>
                      <option value="crops">पीक / धान्य (Crops)</option>
                    </select>
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      {lang === 'mr' ? 'किंमत (रुपये)' : 'कीमत (रुपये)'} *
                    </label>
                    <input
                      type="number"
                      required
                      value={price}
                      onChange={(e) => setPrice(e.target.value)}
                      placeholder="उदा. 1500"
                      className="w-full px-3 py-2 border rounded-xl font-medium"
                    >
                    </input>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      {lang === 'mr' ? 'युनिट' : 'इकाई (Unit)'}
                    </label>
                    <input
                      type="text"
                      value={unit}
                      onChange={(e) => setUnit(e.target.value)}
                      placeholder="प्रति किलो / प्रति बॅग / प्रति तास"
                      className="w-full px-3 py-2 border rounded-xl font-medium"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      {lang === 'mr' ? 'उपलब्ध प्रमाण' : 'उपलब्ध मात्रा'}
                    </label>
                    <input
                      type="text"
                      value={quantity}
                      onChange={(e) => setQuantity(e.target.value)}
                      placeholder="उदा. 20 किलो / 5 गोण्या"
                      className="w-full px-3 py-2 border rounded-xl font-medium"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      {lang === 'mr' ? 'आपले नाव' : 'आपका नाम'} *
                    </label>
                    <input
                      type="text"
                      required
                      value={sellerName}
                      onChange={(e) => setSellerName(e.target.value)}
                      placeholder="नाव"
                      className="w-full px-3 py-2 border rounded-xl font-medium"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      {lang === 'mr' ? 'मोबाईल नंबर' : 'मोबाइल नंबर'} *
                    </label>
                    <input
                      type="tel"
                      required
                      value={phone}
                      onChange={(e) => setPhone(e.target.value)}
                      placeholder="10 अंकी नंबर"
                      className="w-full px-3 py-2 border rounded-xl font-medium"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      {lang === 'mr' ? 'गाव' : 'गांव'}
                    </label>
                    <input
                      type="text"
                      value={village}
                      onChange={(e) => setVillage(e.target.value)}
                      placeholder="गावाचे नाव"
                      className="w-full px-3 py-2 border rounded-xl font-medium"
                    />
                  </div>

                  <div>
                    <label className="block font-bold text-slate-700 mb-1">
                      {lang === 'mr' ? 'जिल्हा' : 'ज़िला'}
                    </label>
                    <input
                      type="text"
                      value={district}
                      onChange={(e) => setDistrict(e.target.value)}
                      placeholder="नाशिक / पुणे / इ."
                      className="w-full px-3 py-2 border rounded-xl font-medium"
                    />
                  </div>
                </div>

                <div>
                  <label className="block font-bold text-slate-700 mb-1">
                    {lang === 'mr' ? 'अधिक माहिती (वर्णन)' : 'अन्य विवरण'}
                  </label>
                  <textarea
                    rows={2}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="सामान बद्दल थोडक्यात सांगा..."
                    className="w-full px-3 py-2 border rounded-xl font-medium"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-black rounded-xl text-sm shadow-md transition"
                >
                  {lang === 'mr' ? 'जाहिरात मोफत प्रसिद्ध करा' : 'विज्ञापन निःशुल्क पोस्ट करें'}
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </section>
  );
};
