import React from 'react';
import {
  TrendingUp,
  CloudSun,
  FileText,
  Stethoscope,
  Wheat,
  Menu,
  ShoppingBag,
  Calculator,
  PhoneCall,
  Sparkles,
  Sprout,
  Compass,
} from 'lucide-react';
import { Language } from '../types';
import { translations } from '../translations';

export type ActiveTab =
  | 'mandi'
  | 'weather'
  | 'guidance'
  | 'doctor'
  | 'schemes'
  | 'advisory'
  | 'market'
  | 'tools'
  | 'helpline';

interface BottomNavProps {
  activeTab: ActiveTab;
  onChangeTab: (tab: ActiveTab) => void;
  lang: Language;
  onOpenAiChat: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  activeTab,
  onChangeTab,
  lang,
  onOpenAiChat,
}) => {
  const [showMoreMenu, setShowMoreMenu] = React.useState(false);

  const navItems = [
    {
      id: 'mandi' as ActiveTab,
      label: translations.nav.mandi[lang],
      icon: TrendingUp,
      color: 'text-amber-600',
    },
    {
      id: 'weather' as ActiveTab,
      label: translations.nav.weather[lang],
      icon: CloudSun,
      color: 'text-blue-600',
    },
    {
      id: 'guidance' as ActiveTab,
      label: translations.nav.guidance[lang],
      icon: Sprout,
      color: 'text-emerald-600',
    },
    {
      id: 'doctor' as ActiveTab,
      label: translations.nav.doctor[lang],
      icon: Stethoscope,
      color: 'text-rose-500',
    },
    {
      id: 'schemes' as ActiveTab,
      label: translations.nav.schemes[lang],
      icon: FileText,
      color: 'text-teal-600',
    },
  ];

  return (
    <>
      {/* Floating More Drawer Backdrop */}
      {showMoreMenu && (
        <div
          className="fixed inset-0 bg-black/50 z-40 backdrop-blur-xs transition-opacity"
          onClick={() => setShowMoreMenu(false)}
        />
      )}

      {/* Floating More Sheet */}
      {showMoreMenu && (
        <div className="fixed bottom-18 left-3 right-3 sm:left-auto sm:right-6 sm:w-80 bg-white rounded-2xl shadow-2xl border-2 border-emerald-600 z-50 p-4 animate-in slide-in-from-bottom duration-200">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <h3 className="font-bold text-slate-800 text-sm">
              {lang === 'mr' ? 'अधिक शेती साधने' : lang === 'hi' ? 'अन्य कृषि सेवाएं' : 'More Farming Services'}
            </h3>
            <button
              onClick={() => setShowMoreMenu(false)}
              className="text-slate-400 hover:text-slate-600 text-lg font-bold p-1"
            >
              ✕
            </button>
          </div>
          <div className="grid grid-cols-2 gap-2.5 pt-3">
            <button
              onClick={() => {
                onChangeTab('guidance');
                setShowMoreMenu(false);
              }}
              className="col-span-2 flex items-center justify-center gap-2 p-3 rounded-xl bg-gradient-to-r from-emerald-700 to-teal-800 text-white font-black text-xs sm:text-sm shadow-md transition active:scale-95"
            >
              <Sprout className="w-5 h-5 text-amber-300" />
              <span>{translations.nav.guidance[lang]} (A to Z गाईड)</span>
            </button>

            <button
              onClick={() => {
                onChangeTab('advisory');
                setShowMoreMenu(false);
              }}
              className="flex flex-col items-center justify-center p-3 rounded-xl bg-lime-50 hover:bg-lime-100 border border-lime-200 transition text-lime-900"
            >
              <Wheat className="w-6 h-6 mb-1 text-lime-700" />
              <span className="text-xs font-bold text-center">
                {translations.nav.advisory[lang]}
              </span>
            </button>

            <button
              onClick={() => {
                onChangeTab('market');
                setShowMoreMenu(false);
              }}
              className="flex flex-col items-center justify-center p-3 rounded-xl bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 transition text-emerald-900"
            >
              <ShoppingBag className="w-6 h-6 mb-1 text-emerald-700" />
              <span className="text-xs font-bold text-center">
                {translations.nav.market[lang]}
              </span>
            </button>

            <button
              onClick={() => {
                onChangeTab('tools');
                setShowMoreMenu(false);
              }}
              className="flex flex-col items-center justify-center p-3 rounded-xl bg-amber-50 hover:bg-amber-100 border border-amber-200 transition text-amber-900"
            >
              <Calculator className="w-6 h-6 mb-1 text-amber-700" />
              <span className="text-xs font-bold text-center">
                {translations.nav.tools[lang]}
              </span>
            </button>

            <button
              onClick={() => {
                onChangeTab('helpline');
                setShowMoreMenu(false);
              }}
              className="flex flex-col items-center justify-center p-3 rounded-xl bg-blue-50 hover:bg-blue-100 border border-blue-200 transition text-blue-900"
            >
              <PhoneCall className="w-6 h-6 mb-1 text-blue-700" />
              <span className="text-xs font-bold text-center">
                {translations.nav.helpline[lang]}
              </span>
            </button>
          </div>
        </div>
      )}

      {/* Main Bottom Nav Bar */}
      <nav className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-md border-t border-slate-200 px-2 py-1.5 z-40 sm:hidden shadow-lg">
        <div className="flex items-center justify-around">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onChangeTab(item.id)}
                className={`flex flex-col items-center justify-center flex-1 py-1 rounded-xl transition-all ${
                  isActive
                    ? 'text-emerald-800 font-extrabold scale-105'
                    : 'text-slate-500 font-semibold hover:text-slate-800'
                }`}
              >
                <div
                  className={`p-1.5 rounded-xl transition-colors ${
                    isActive ? 'bg-emerald-100 text-emerald-800' : ''
                  }`}
                >
                  <Icon className="w-5 h-5" />
                </div>
                <span className="text-[10px] mt-0.5 tracking-tight truncate max-w-[62px]">
                  {item.label}
                </span>
              </button>
            );
          })}

          {/* More Drawer Button */}
          <button
            onClick={() => setShowMoreMenu(!showMoreMenu)}
            className={`flex flex-col items-center justify-center py-1 px-2 rounded-xl transition-all ${
              ['advisory', 'market', 'tools', 'helpline'].includes(activeTab)
                ? 'text-emerald-800 font-extrabold'
                : 'text-slate-500 font-semibold'
            }`}
          >
            <div
              className={`p-1.5 rounded-xl ${
                ['advisory', 'market', 'tools', 'helpline'].includes(activeTab)
                  ? 'bg-emerald-100 text-emerald-800'
                  : ''
              }`}
            >
              <Menu className="w-5 h-5" />
            </div>
            <span className="text-[10px] mt-0.5 tracking-tight">
              {lang === 'mr' ? 'अधिक' : lang === 'hi' ? 'अन्य' : 'More'}
            </span>
          </button>
        </div>
      </nav>
    </>
  );
};
