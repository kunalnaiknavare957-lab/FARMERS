import React, { useState, useEffect } from 'react';
import {
  Download,
  Smartphone,
  Code2,
  X,
  CheckCircle2,
  Copy,
  ExternalLink,
  ShieldCheck,
  Sparkles,
  ArrowDownToLine,
  FileDown,
  Layers,
  HelpCircle,
} from 'lucide-react';
import { Language } from '../types';

interface DownloadModalProps {
  isOpen: boolean;
  onClose: () => void;
  lang: Language;
}

export const DownloadModal: React.FC<DownloadModalProps> = ({
  isOpen,
  onClose,
  lang,
}) => {
  const [activeTab, setActiveTab] = useState<'apk' | 'pwa' | 'code'>('apk');
  const [copiedLink, setCopiedLink] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isDownloading, setIsDownloading] = useState(false);

  useEffect(() => {
    const handleBeforeInstall = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);
    return () => window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
  }, []);

  if (!isOpen) return null;

  const appUrl = window.location.href;
  const apkDownloadUrl = '/api/download-apk';

  const handleCopyLink = () => {
    navigator.clipboard?.writeText(appUrl);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 3000);
  };

  const handleDirectApkDownload = () => {
    setIsDownloading(true);
    const link = document.createElement('a');
    link.href = apkDownloadUrl;
    link.download = 'KisanMitra.apk';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    setTimeout(() => setIsDownloading(false), 3000);
  };

  const handleInstallPwa = async () => {
    if (deferredPrompt) {
      deferredPrompt.prompt();
      await deferredPrompt.userChoice;
      setDeferredPrompt(null);
    } else {
      alert(
        lang === 'mr'
          ? 'तुमच्या मोबाईल ब्राऊझरमध्ये वर ३ ठिपक्यांवर (⋮) क्लिक करा आणि "Install app" किंवा "Add to Home screen" निवडा.'
          : 'अपने मोबाइल ब्राउज़र में ऊपर 3 डॉट्स (⋮) पर क्लिक करें और "Install app" चुनें।'
      );
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 bg-black/70 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-3xl shadow-2xl max-w-lg w-full overflow-hidden border-2 border-emerald-600 animate-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="bg-gradient-to-r from-emerald-800 via-emerald-700 to-teal-800 text-white p-4 sm:p-5 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-2xl bg-amber-400 text-emerald-950 font-black text-xl flex items-center justify-center shadow-md">
              📲
            </div>
            <div>
              <h3 className="font-black text-base sm:text-lg leading-tight">
                {lang === 'mr' ? 'किसान मित्र थेट Android APK' : 'किसान मित्र डायरेक्ट Android APK'}
              </h3>
              <p className="text-xs text-emerald-100 font-medium">
                {lang === 'mr' ? 'मोबाईलमध्ये थेट इन्स्टॉल करा (पूर्ण ऑफलाइन डेटासह - 280 KB)' : 'मोबाइल में सीधा इंस्टॉल करें (फुल ऑफलाइन डेटा सहित - 280 KB)'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-white/80 hover:text-white p-1.5 rounded-xl hover:bg-white/10 transition"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="grid grid-cols-3 p-1.5 bg-slate-100 border-b border-slate-200 gap-1 text-xs">
          <button
            onClick={() => setActiveTab('apk')}
            className={`py-2 px-1 rounded-xl font-black text-center transition flex flex-col items-center gap-1 ${
              activeTab === 'apk'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'text-slate-700 hover:text-slate-900 bg-white/60'
            }`}
          >
            <ArrowDownToLine className="w-4 h-4" />
            <span>{lang === 'mr' ? '1. थेट APK' : '1. सीधा APK'}</span>
          </button>

          <button
            onClick={() => setActiveTab('pwa')}
            className={`py-2 px-1 rounded-xl font-black text-center transition flex flex-col items-center gap-1 ${
              activeTab === 'pwa'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'text-slate-700 hover:text-slate-900 bg-white/60'
            }`}
          >
            <Smartphone className="w-4 h-4" />
            <span>{lang === 'mr' ? '2. Chrome ॲप' : '2. Chrome ऐप'}</span>
          </button>

          <button
            onClick={() => setActiveTab('code')}
            className={`py-2 px-1 rounded-xl font-black text-center transition flex flex-col items-center gap-1 ${
              activeTab === 'code'
                ? 'bg-emerald-700 text-white shadow-xs'
                : 'text-slate-700 hover:text-slate-900 bg-white/60'
            }`}
          >
            <Code2 className="w-4 h-4" />
            <span>{lang === 'mr' ? '3. कोड ZIP' : '3. कोड ZIP'}</span>
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-5 space-y-4 max-h-[75vh] overflow-y-auto">
          {/* TAB 1: DIRECT APK DOWNLOAD (PRIMARY) */}
          {activeTab === 'apk' && (
            <div className="space-y-4">
              {/* Highlight Card */}
              <div className="bg-gradient-to-br from-emerald-50 to-teal-50 border-2 border-emerald-500 rounded-2xl p-4 text-center space-y-3">
                <div className="inline-flex items-center gap-1.5 bg-emerald-600 text-white text-[11px] font-black uppercase px-2.5 py-0.5 rounded-full shadow-xs">
                  <ShieldCheck className="w-3.5 h-3.5" />
                  <span>100% व्हेरिफाईड Android APK तयार आहे</span>
                </div>

                <div>
                  <h4 className="text-lg font-black text-emerald-950">
                    KisanMitra.apk
                  </h4>
                  <p className="text-xs text-slate-600 font-semibold mt-0.5">
                    आकार: 280 KB • Android 5.0+ वरील सर्व फोनसाठी १००% कार्यरत (उघडल्यावर सर्व डेटा लगेच दिसतो)
                  </p>
                </div>

                {/* Big Action Download Button */}
                <button
                  onClick={handleDirectApkDownload}
                  disabled={isDownloading}
                  className="w-full bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 hover:from-emerald-700 hover:to-teal-800 text-white font-black py-3.5 px-4 rounded-2xl shadow-xl flex items-center justify-center gap-2 transition active:scale-98 animate-pulse"
                >
                  <ArrowDownToLine className="w-6 h-6 text-amber-300" />
                  <span className="text-base sm:text-lg">
                    {isDownloading
                      ? (lang === 'mr' ? 'डाऊनलोड होत आहे...' : 'डाउनलोड हो रहा है...')
                      : (lang === 'mr' ? 'थेट APK डाऊनलोड करा (Download APK)' : 'सीधा APK डाउनलोड करें (Download APK)')}
                  </span>
                </button>

                <p className="text-[11px] text-emerald-800 font-bold">
                  ⚡ एका क्लिकमध्ये डाऊनलोड होईल आणि थेट फोनवर इन्स्टॉल करता येईल.
                </p>
              </div>

              {/* 4 Steps Installation Guide in Simple Marathi */}
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-3">
                <div className="flex items-center gap-1.5 text-xs font-black uppercase text-slate-700">
                  <HelpCircle className="w-4 h-4 text-emerald-600" />
                  <span>{lang === 'mr' ? 'मोबाईलमध्ये इन्स्टॉल कसे करावे? (सोप्या ४ पायऱ्या)' : 'मोबाइल में इंस्टॉल कैसे करें? (4 आसान चरण)'}</span>
                </div>

                <div className="space-y-3 text-xs sm:text-sm text-slate-700">
                  <div className="flex items-start gap-2.5">
                    <span className="w-6 h-6 rounded-full bg-emerald-700 text-white font-black text-xs flex items-center justify-center shrink-0 mt-0.5">
                      १
                    </span>
                    <div>
                      <strong className="text-slate-900 block">APK डाऊनलोड करा:</strong>
                      <span>वरील हिरव्या बटनावर क्लिक करा. <strong>KisanMitra.apk</strong> डाऊनलोड होईल.</span>
                    </div>
                  </div>

                  <div className="flex items-start gap-2.5">
                    <span className="w-6 h-6 rounded-full bg-emerald-700 text-white font-black text-xs flex items-center justify-center shrink-0 mt-0.5">
                      २
                    </span>
                    <div>
                      <strong className="text-slate-900 block">फाईल उघडा:</strong>
                      <span>डाऊनलोड झाल्यावर वरच्या नोटिफिकेशनवर क्लिक करा, किंवा मोबाईलमधील <strong>Files / Downloads</strong> फोल्डरमध्ये जाऊन <strong>KisanMitra.apk</strong> वर टॅप करा.</span>
                    </div>
                  </div>

                  <div className="flex items-start gap-2.5">
                    <span className="w-6 h-6 rounded-full bg-emerald-700 text-white font-black text-xs flex items-center justify-center shrink-0 mt-0.5">
                      ३
                    </span>
                    <div>
                      <strong className="text-slate-900 block">परवानगी द्या (फक्त एकदा विचारल्यास):</strong>
                      <span>जर फोनने "Security / Unknown sources" विचारले, तर <strong>"Allow from this source"</strong> (किंवा 'परवानगी द्या') निवडा.</span>
                    </div>
                  </div>

                  <div className="flex items-start gap-2.5">
                    <span className="w-6 h-6 rounded-full bg-emerald-700 text-white font-black text-xs flex items-center justify-center shrink-0 mt-0.5">
                      ४
                    </span>
                    <div>
                      <strong className="text-slate-900 block">इन्स्टॉल (Install) दाबा:</strong>
                      <span><strong>"Install"</strong> बटण दाबा. ॲप तुमच्या मोबाईलमध्ये कायमस्वरूपी इन्स्टॉल होईल आणि इतर ॲप्ससारखे चालू लागेल!</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: PWA ADD TO HOME SCREEN */}
          {activeTab === 'pwa' && (
            <div className="space-y-4">
              <button
                onClick={handleInstallPwa}
                className="w-full bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white font-black py-3 px-4 rounded-2xl shadow-md flex items-center justify-center gap-2 transition active:scale-98"
              >
                <Smartphone className="w-5 h-5 text-amber-300" />
                <span className="text-sm sm:text-base">
                  {lang === 'mr' ? 'Chrome मधून ॲप जोडा (Add to Home Screen)' : 'Chrome से ऐप जोड़ें (Add to Home Screen)'}
                </span>
              </button>

              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 space-y-2 text-xs sm:text-sm text-slate-700">
                <p className="font-bold text-slate-900">ब्राऊझरमधून ॲप सेव्ह करण्याची पद्धत:</p>
                <p>१. वरच्या उजव्या बाजूला असलेल्या ३ ठिपक्यांवर (⋮) क्लिक करा.</p>
                <p>२. <strong>"Install app"</strong> किंवा <strong>"Add to Home screen"</strong> निवडा.</p>
                <p>३. ॲप तुमच्या स्क्रीनवर येईल.</p>
              </div>

              {/* Share & Copy Link */}
              <div className="bg-emerald-50 p-3 rounded-2xl border border-emerald-200 flex items-center justify-between gap-2">
                <span className="text-xs font-bold text-emerald-950 truncate max-w-[240px]">
                  {appUrl}
                </span>
                <button
                  onClick={handleCopyLink}
                  className="flex items-center gap-1 bg-white hover:bg-emerald-100 text-emerald-900 border border-emerald-300 px-3 py-1.5 rounded-xl font-bold text-xs shrink-0 transition"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>{copiedLink ? 'कॉपी झाले!' : 'लिंक कॉपी'}</span>
                </button>
              </div>
            </div>
          )}

          {/* TAB 3: SOURCE CODE ZIP */}
          {activeTab === 'code' && (
            <div className="space-y-4">
              <div className="text-center p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                <div className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-800 flex items-center justify-center mx-auto">
                  <Download className="w-6 h-6" />
                </div>
                <h4 className="font-black text-slate-900 text-sm sm:text-base">
                  {lang === 'mr' ? 'संपूर्ण प्रोजेक्ट कोड (.zip फाईल)' : 'सम्पूर्ण प्रोजेक्ट कोड (.zip फाइल)'}
                </h4>
                <p className="text-xs text-slate-500 font-medium">
                  {lang === 'mr'
                    ? 'या फाईलमध्ये सर्व React, TypeScript, Express, Mandi Data, आणि Weather फाइल्स उपलब्ध आहेत.'
                    : 'इस ज़िप में सभी React, TypeScript, Express, मंडी डेटा और मौसम फाइल्स शामिल हैं।'}
                </p>

                <a
                  href="/api/download-project-zip"
                  download="kisan-mitra-portal.zip"
                  className="w-full mt-2 inline-flex items-center justify-center gap-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-amber-950 font-black py-3 px-4 rounded-xl shadow-md transition active:scale-98"
                >
                  <FileDown className="w-5 h-5" />
                  <span>{lang === 'mr' ? 'प्रोजेक्ट ZIP डाऊनलोड करा (1-Click)' : 'प्रोजेक्ट ZIP डाउनलोड करें (1-Click)'}</span>
                </a>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
