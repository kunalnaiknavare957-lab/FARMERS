import React, { useState, useEffect, useMemo } from 'react';
import {
  CloudSun,
  CloudRain,
  Sun,
  CloudLightning,
  Wind,
  Droplets,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Volume2,
  Navigation,
  RefreshCw,
  Search,
  MapPin,
  ChevronDown,
  Building,
} from 'lucide-react';
import { WeatherData, Language } from '../types';
import {
  MAHARASHTRA_DISTRICTS,
  ALL_VILLAGES_INDEX,
  DEFAULT_WEATHER_DATA,
  fetchLiveWeatherByCoords,
  VillageSearchEntry,
} from '../data/weatherData';
import { translations } from '../translations';
import { speakText, stopSpeaking } from '../utils/speech';

interface WeatherSectionProps {
  lang: Language;
}

export const WeatherSection: React.FC<WeatherSectionProps> = ({ lang }) => {
  // 3-Level hierarchy state
  const [selectedDistrictId, setSelectedDistrictId] = useState<string>('nashik');
  const [selectedTalukaId, setSelectedTalukaId] = useState<string>('niphad');
  const [selectedVillageId, setSelectedVillageId] = useState<string>('lasalgaon');

  // Village search input
  const [searchVillageQuery, setSearchVillageQuery] = useState<string>('');
  const [isSearchingVillage, setIsSearchingVillage] = useState<boolean>(false);

  const [weather, setWeather] = useState<WeatherData>(DEFAULT_WEATHER_DATA);
  const [loading, setLoading] = useState<boolean>(false);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);

  // Current district object
  const currentDistrict = useMemo(() => {
    return (
      MAHARASHTRA_DISTRICTS.find((d) => d.id === selectedDistrictId) ||
      MAHARASHTRA_DISTRICTS[0]
    );
  }, [selectedDistrictId]);

  // Current taluka object
  const currentTaluka = useMemo(() => {
    return (
      currentDistrict.talukas.find((t) => t.id === selectedTalukaId) ||
      currentDistrict.talukas[0]
    );
  }, [currentDistrict, selectedTalukaId]);

  // Current village object
  const currentVillage = useMemo(() => {
    return (
      currentTaluka.villages.find((v) => v.id === selectedVillageId) ||
      currentTaluka.villages[0]
    );
  }, [currentTaluka, selectedVillageId]);

  // Autocomplete search suggestions
  const searchResults = useMemo(() => {
    if (!searchVillageQuery.trim() || searchVillageQuery.length < 2) return [];
    const q = searchVillageQuery.toLowerCase().trim();
    return ALL_VILLAGES_INDEX.filter((item) => {
      return (
        item.villageName.mr.toLowerCase().includes(q) ||
        item.villageName.hi.toLowerCase().includes(q) ||
        item.villageName.en.toLowerCase().includes(q) ||
        item.talukaName.mr.toLowerCase().includes(q) ||
        item.talukaName.en.toLowerCase().includes(q) ||
        item.districtName.mr.toLowerCase().includes(q)
      );
    }).slice(0, 8);
  }, [searchVillageQuery]);

  // Fetch weather whenever current village changes
  const loadWeather = async (lat: number, lon: number, vilName: string, talName: string, distName: string) => {
    setLoading(true);
    try {
      const data = await fetchLiveWeatherByCoords(lat, lon, {
        village: vilName,
        taluka: talName,
        district: distName,
      });
      setWeather(data);
    } catch {
      // Fallback
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (currentVillage && currentTaluka && currentDistrict) {
      loadWeather(
        currentVillage.lat,
        currentVillage.lon,
        currentVillage.name[lang] || currentVillage.name.mr,
        currentTaluka.name[lang] || currentTaluka.name.mr,
        currentDistrict.name[lang] || currentDistrict.name.mr
      );
    }
  }, [selectedVillageId, selectedTalukaId, selectedDistrictId, lang]);

  // Handle District Change
  const handleDistrictChange = (distId: string) => {
    setSelectedDistrictId(distId);
    const dist = MAHARASHTRA_DISTRICTS.find((d) => d.id === distId);
    if (dist && dist.talukas.length > 0) {
      const firstTal = dist.talukas[0];
      setSelectedTalukaId(firstTal.id);
      if (firstTal.villages.length > 0) {
        setSelectedVillageId(firstTal.villages[0].id);
      }
    }
  };

  // Handle Taluka Change
  const handleTalukaChange = (talId: string) => {
    setSelectedTalukaId(talId);
    const tal = currentDistrict.talukas.find((t) => t.id === talId);
    if (tal && tal.villages.length > 0) {
      setSelectedVillageId(tal.villages[0].id);
    }
  };

  // Select village from search autocomplete
  const handleSelectSearchedVillage = (entry: VillageSearchEntry) => {
    setSelectedDistrictId(entry.districtId);
    setSelectedTalukaId(entry.talukaId);
    setSelectedVillageId(entry.villageId);
    setSearchVillageQuery('');
    setIsSearchingVillage(false);
  };

  // Auto-detect GPS Location
  const handleDetectLocation = () => {
    if (!navigator.geolocation) {
      alert(lang === 'mr' ? 'ब्राउझर लोकेशन उपलब्ध नाही' : 'लोकेशन सेवा उपलब्ध नहीं है');
      return;
    }
    setLoading(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude, longitude } = pos.coords;
        // Find closest village in index
        let closest = ALL_VILLAGES_INDEX[0];
        let minDist = 999999;
        for (const v of ALL_VILLAGES_INDEX) {
          const d = Math.hypot(v.lat - latitude, v.lon - longitude);
          if (d < minDist) {
            minDist = d;
            closest = v;
          }
        }
        handleSelectSearchedVillage(closest);
      },
      () => {
        setLoading(false);
        alert(lang === 'mr' ? 'लोकेशन परवानगी नाकारली' : 'लोकेशन की अनुमति नहीं मिली');
      }
    );
  };

  // Voice Readout
  const handleSpeakWeather = () => {
    if (isSpeaking) {
      stopSpeaking();
      setIsSpeaking(false);
      return;
    }

    const sprayTxt = weather.sprayAlert[lang];
    const speechText =
      lang === 'mr'
        ? `${weather.city}, ${weather.district} चे आजचे हवामान: तापमान ${weather.temp} अंश सेल्सिअस, पावसाची शक्यता ${weather.rainProb} टक्के आणि वाऱ्याचा वेग ${weather.windSpeed} किलोमीटर प्रति तास आहे. फवारणी सल्ला: ${sprayTxt}`
        : lang === 'hi'
        ? `${weather.city}, ${weather.district} का आज का मौसम: तापमान ${weather.temp} डिग्री सेल्सियस, बारिश की संभावना ${weather.rainProb} प्रतिशत और हवा की गति ${weather.windSpeed} किमी प्रति घंटा है। छिड़काव सलाह: ${sprayTxt}`
        : `Weather for ${weather.city}: Temperature is ${weather.temp}°C, rain probability ${weather.rainProb}%, and wind speed ${weather.windSpeed} km/h. Spray alert: ${sprayTxt}`;

    setIsSpeaking(true);
    speakText(
      speechText,
      lang,
      () => setIsSpeaking(false),
      () => setIsSpeaking(false)
    );
  };

  const getWeatherIcon = (key: WeatherData['conditionKey'], size = 'w-6 h-6') => {
    switch (key) {
      case 'sunny':
        return <Sun className={`${size} text-amber-500`} />;
      case 'partly_cloudy':
        return <CloudSun className={`${size} text-amber-400`} />;
      case 'cloudy':
        return <CloudSun className={`${size} text-slate-400`} />;
      case 'rainy':
        return <CloudRain className={`${size} text-blue-500`} />;
      case 'thunderstorm':
        return <CloudLightning className={`${size} text-purple-600`} />;
      default:
        return <Sun className={`${size} text-amber-500`} />;
    }
  };

  return (
    <div className="space-y-4 animate-in fade-in duration-200">
      {/* Village Search & Location Hierarchy Selector */}
      <div className="bg-white p-4 sm:p-5 rounded-3xl shadow-xs border border-slate-200 space-y-3.5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-2 border-b border-slate-100">
          <div>
            <div className="flex items-center gap-2">
              <span className="p-1.5 rounded-xl bg-blue-100 text-blue-800">
                <MapPin className="w-5 h-5" />
              </span>
              <h3 className="font-black text-slate-900 text-base sm:text-lg">
                {lang === 'mr'
                  ? 'महाराष्ट्र हवामान: जिल्हा ➔ तालुका ➔ गाव निवडा'
                  : 'महाराष्ट्र मौसम: जिला ➔ तहसील ➔ गांव चुनें'}
              </h3>
            </div>
            <p className="text-xs text-slate-500 font-medium mt-0.5">
              {lang === 'mr'
                ? 'महाराष्ट्रातील सर्व ३६ जिल्हे, उपविभाग व गावांचे थेट स्थानिक हवामान'
                : 'महाराष्ट्र के सभी 36 जिलों, तहसीलों और गांवों का सटीक लाइव मौसम'}
            </p>
          </div>

          {/* GPS Location Button */}
          <button
            onClick={handleDetectLocation}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 font-bold text-xs transition active:scale-95 self-start sm:self-auto shrink-0"
          >
            <Navigation className="w-3.5 h-3.5 text-emerald-600" />
            <span>{lang === 'mr' ? 'माझे गाव शोधा (GPS)' : 'मेरा गांव खोजें'}</span>
          </button>
        </div>

        {/* Quick Search Village Autocomplete Input */}
        <div className="relative">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
            <input
              type="text"
              value={searchVillageQuery}
              onChange={(e) => {
                setSearchVillageQuery(e.target.value);
                setIsSearchingVillage(true);
              }}
              onFocus={() => setIsSearchingVillage(true)}
              placeholder={
                lang === 'mr'
                  ? 'आपले गाव किंवा तालुका थेट शोधा (उदा. लासलगाव, नारायणगाव, शहादा, अकलूज, पंढरपूर, रावेर, तासगाव)...'
                  : 'गांव या तहसील का नाम लिखें (उदा. लासलगांव, नारायणगांव, शहादा, अकलूज, पंढरपुर, रावेर)...'
              }
              className="w-full pl-9 pr-8 py-2.5 text-xs sm:text-sm rounded-xl border border-blue-200 focus:outline-none focus:ring-2 focus:ring-blue-600 bg-blue-50/50 font-medium text-slate-800"
            />
            {searchVillageQuery && (
              <button
                onClick={() => setSearchVillageQuery('')}
                className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 text-xs font-bold"
              >
                ✕
              </button>
            )}
          </div>

          {/* Autocomplete Dropdown List */}
          {isSearchingVillage && searchResults.length > 0 && (
            <div className="absolute left-0 right-0 top-full mt-1 bg-white rounded-2xl shadow-xl border-2 border-blue-300 z-50 overflow-hidden divide-y divide-slate-100 max-h-64 overflow-y-auto">
              {searchResults.map((entry) => (
                <button
                  key={`${entry.districtId}-${entry.talukaId}-${entry.villageId}`}
                  onClick={() => handleSelectSearchedVillage(entry)}
                  className="w-full px-4 py-2.5 text-left hover:bg-blue-50 transition flex items-center justify-between group"
                >
                  <div className="flex items-center gap-2">
                    <MapPin className="w-4 h-4 text-blue-600 group-hover:scale-110 transition-transform" />
                    <div>
                      <span className="font-black text-slate-900 text-xs sm:text-sm block">
                        {entry.villageName[lang] || entry.villageName.mr} (गाव)
                      </span>
                      <span className="text-[11px] text-slate-500 font-semibold">
                        तालुका: {entry.talukaName[lang] || entry.talukaName.mr} • जिल्हा: {entry.districtName[lang] || entry.districtName.mr}
                      </span>
                    </div>
                  </div>
                  <span className="text-[10px] px-2 py-0.5 rounded-full bg-blue-100 text-blue-800 font-bold">
                    {entry.division}
                  </span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* 3-Level Dropdown Hierarchy: District -> Taluka -> Village */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-1">
          {/* 1. DISTRICT SELECTOR */}
          <div>
            <label className="text-[11px] font-black uppercase text-slate-500 tracking-wider block mb-1">
              {lang === 'mr' ? '१. जिल्हा निवडा (36 जिल्हे):' : '1. ज़िला चुनें (36 ज़िले):'}
            </label>
            <div className="relative">
              <select
                value={selectedDistrictId}
                onChange={(e) => handleDistrictChange(e.target.value)}
                className="w-full appearance-none bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 pr-8 text-xs sm:text-sm font-black text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-600"
              >
                <optgroup label="नाशिक विभाग (Nashik Division)">
                  {MAHARASHTRA_DISTRICTS.filter((d) => d.division === 'Nashik').map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name[lang] || d.name.mr}
                    </option>
                  ))}
                </optgroup>
                <optgroup label="पुणे व पश्चिम महाराष्ट्र (Pune Division)">
                  {MAHARASHTRA_DISTRICTS.filter((d) => d.division === 'Pune').map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name[lang] || d.name.mr}
                    </option>
                  ))}
                </optgroup>
                <optgroup label="मराठवाडा (Marathwada Division)">
                  {MAHARASHTRA_DISTRICTS.filter((d) => d.division === 'Marathwada').map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name[lang] || d.name.mr}
                    </option>
                  ))}
                </optgroup>
                <optgroup label="विदर्भ (Vidarbha Division)">
                  {MAHARASHTRA_DISTRICTS.filter((d) => d.division === 'Vidarbha').map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name[lang] || d.name.mr}
                    </option>
                  ))}
                </optgroup>
                <optgroup label="कोकण (Konkan Division)">
                  {MAHARASHTRA_DISTRICTS.filter((d) => d.division === 'Konkan').map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.name[lang] || d.name.mr}
                    </option>
                  ))}
                </optgroup>
              </select>
              <ChevronDown className="w-4 h-4 text-slate-400 absolute right-2.5 top-3 pointer-events-none" />
            </div>
          </div>

          {/* 2. TALUKA / SUBDIVISION SELECTOR */}
          <div>
            <label className="text-[11px] font-black uppercase text-slate-500 tracking-wider block mb-1">
              {lang === 'mr' ? '२. तालुका / उपविभाग:' : '2. तहसील / उपविभाग:'}
            </label>
            <div className="relative">
              <select
                value={selectedTalukaId}
                onChange={(e) => handleTalukaChange(e.target.value)}
                className="w-full appearance-none bg-slate-50 border border-slate-300 rounded-xl px-3 py-2 pr-8 text-xs sm:text-sm font-black text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-600"
              >
                {currentDistrict.talukas.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name[lang] || t.name.mr}
                  </option>
                ))}
              </select>
              <ChevronDown className="w-4 h-4 text-slate-400 absolute right-2.5 top-3 pointer-events-none" />
            </div>
          </div>

          {/* 3. VILLAGE / GAON SELECTOR */}
          <div>
            <label className="text-[11px] font-black uppercase text-slate-500 tracking-wider block mb-1">
              {lang === 'mr' ? '३. गाव निवडा (स्थानिक केंद्र):' : '3. गांव चुनें (लोकल केंद्र):'}
            </label>
            <div className="relative">
              <select
                value={selectedVillageId}
                onChange={(e) => setSelectedVillageId(e.target.value)}
                className="w-full appearance-none bg-emerald-50 border border-emerald-300 rounded-xl px-3 py-2 pr-8 text-xs sm:text-sm font-black text-emerald-950 focus:outline-none focus:ring-2 focus:ring-emerald-600"
              >
                {currentTaluka.villages.map((v) => (
                  <option key={v.id} value={v.id}>
                    {v.name[lang] || v.name.mr}
                  </option>
                ))}
              </select>
              <ChevronDown className="w-4 h-4 text-emerald-600 absolute right-2.5 top-3 pointer-events-none" />
            </div>
          </div>
        </div>

        {/* Current Active Location Pill */}
        <div className="bg-gradient-to-r from-blue-50 to-indigo-50 p-2.5 rounded-xl border border-blue-200 flex items-center justify-between text-xs">
          <div className="flex items-center gap-1.5 font-bold text-blue-950">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-ping"></span>
            <span>
              📍 {lang === 'mr' ? 'स्थान:' : 'स्थान:'} <strong className="text-blue-900">{currentVillage?.name[lang] || currentVillage?.name.mr}</strong> (गाव), {currentTaluka?.name[lang] || currentTaluka?.name.mr} (तालुका), {currentDistrict?.name[lang] || currentDistrict?.name.mr} (जिल्हा)
            </span>
          </div>
          <span className="text-[11px] text-blue-700 font-extrabold hidden sm:inline">
            Open-Meteo GPS Sync
          </span>
        </div>
      </div>

      {/* Main Weather Card */}
      <div className="bg-gradient-to-br from-blue-600 via-sky-600 to-teal-700 rounded-3xl p-5 sm:p-6 text-white shadow-xl relative overflow-hidden">
        <div className="absolute right-0 top-0 w-64 h-64 bg-white/10 rounded-full blur-3xl pointer-events-none"></div>

        {/* Header & Audio Speaker */}
        <div className="flex items-start justify-between relative z-10">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs uppercase tracking-wider font-extrabold text-sky-200 bg-white/20 px-2.5 py-0.5 rounded-full">
                {lang === 'mr' ? 'थेट स्थानिक हवामान' : 'लाइव स्थानीय मौसम'}
              </span>
              {loading && <RefreshCw className="w-3.5 h-3.5 animate-spin text-white" />}
            </div>
            <h3 className="text-xl sm:text-2xl font-black mt-1">
              {weather.city}
            </h3>
            <p className="text-xs sm:text-sm text-sky-100 font-medium">
              {weather.district}
            </p>
          </div>

          <button
            onClick={handleSpeakWeather}
            className={`p-3 rounded-2xl backdrop-blur-md transition-all shadow-md active:scale-95 ${
              isSpeaking
                ? 'bg-rose-500 text-white animate-pulse'
                : 'bg-white/20 hover:bg-white/30 text-white'
            }`}
            title="हवामान ऐका"
          >
            <Volume2 className="w-5 h-5" />
          </button>
        </div>

        {/* Temperature & Condition Centerpiece */}
        <div className="my-5 flex items-center justify-between relative z-10">
          <div className="flex items-baseline gap-1">
            <span className="text-5xl sm:text-6xl font-black tracking-tight">
              {weather.temp}°
            </span>
            <span className="text-2xl sm:text-3xl font-bold text-sky-200">C</span>
          </div>

          <div className="flex flex-col items-end">
            <div className="p-3 bg-white/15 rounded-2xl backdrop-blur-xs mb-1">
              {getWeatherIcon(weather.conditionKey, 'w-10 h-10')}
            </div>
            <span className="text-sm sm:text-base font-extrabold">
              {weather.condition}
            </span>
          </div>
        </div>

        {/* Environmental Indicators Grid */}
        <div className="grid grid-cols-3 gap-2 pt-3 border-t border-white/20 relative z-10 text-xs sm:text-sm">
          {/* Rain Probability */}
          <div className="bg-white/15 p-2.5 rounded-2xl backdrop-blur-xs flex items-center gap-2">
            <Droplets className="w-5 h-5 text-sky-200 shrink-0" />
            <div>
              <span className="text-[10px] text-sky-200 block font-semibold">
                {lang === 'mr' ? 'पावसाची शक्यता' : 'बारिश की संभावना'}
              </span>
              <span className="font-extrabold text-sm sm:text-base">
                {weather.rainProb}%
              </span>
            </div>
          </div>

          {/* Humidity */}
          <div className="bg-white/15 p-2.5 rounded-2xl backdrop-blur-xs flex items-center gap-2">
            <CloudSun className="w-5 h-5 text-amber-200 shrink-0" />
            <div>
              <span className="text-[10px] text-sky-200 block font-semibold">
                {lang === 'mr' ? 'हवेतील आर्द्रता' : 'हवा में नमी'}
              </span>
              <span className="font-extrabold text-sm sm:text-base">
                {weather.humidity}%
              </span>
            </div>
          </div>

          {/* Wind Speed */}
          <div className="bg-white/15 p-2.5 rounded-2xl backdrop-blur-xs flex items-center gap-2">
            <Wind className="w-5 h-5 text-teal-200 shrink-0" />
            <div>
              <span className="text-[10px] text-sky-200 block font-semibold">
                {lang === 'mr' ? 'वाऱ्याचा वेग' : 'हवा की गति'}
              </span>
              <span className="font-extrabold text-sm sm:text-base">
                {weather.windSpeed} km/h
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Agricultural Spray Advisory Badge */}
      <div
        className={`p-4 rounded-2xl shadow-xs border transition-all flex items-start gap-3 ${
          weather.sprayAlert.status === 'good'
            ? 'bg-emerald-50 border-emerald-300 text-emerald-950'
            : weather.sprayAlert.status === 'caution'
            ? 'bg-amber-50 border-amber-300 text-amber-950'
            : 'bg-rose-50 border-rose-300 text-rose-950'
        }`}
      >
        <div className="p-2 rounded-xl bg-white shadow-2xs shrink-0 mt-0.5">
          {weather.sprayAlert.status === 'good' ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-600" />
          ) : weather.sprayAlert.status === 'caution' ? (
            <AlertTriangle className="w-5 h-5 text-amber-600" />
          ) : (
            <XCircle className="w-5 h-5 text-rose-600" />
          )}
        </div>

        <div className="space-y-1">
          <div className="flex items-center gap-2">
            <h4 className="font-black text-sm sm:text-base">
              {lang === 'mr'
                ? 'कृषी फवारणी सल्ला (Spray Recommendation)'
                : 'कृषि छिड़काव परामर्श'}
            </h4>
            <span
              className={`px-2 py-0.5 rounded-md text-[10px] font-black uppercase ${
                weather.sprayAlert.status === 'good'
                  ? 'bg-emerald-600 text-white'
                  : weather.sprayAlert.status === 'caution'
                  ? 'bg-amber-600 text-white'
                  : 'bg-rose-600 text-white'
              }`}
            >
              {weather.sprayAlert.status === 'good'
                ? lang === 'mr' ? 'अनुकूल' : 'उत्तम'
                : weather.sprayAlert.status === 'caution'
                ? lang === 'mr' ? 'सावधगिरी' : 'सावधानी'
                : lang === 'mr' ? 'फवारणी टाळा' : 'छिड़काव न करें'}
            </span>
          </div>
          <p className="text-xs sm:text-sm font-semibold leading-relaxed">
            {weather.sprayAlert[lang]}
          </p>
        </div>
      </div>

      {/* 5-Day Village Forecast */}
      <div className="bg-white p-4 sm:p-5 rounded-3xl shadow-xs border border-slate-200 space-y-3">
        <h4 className="font-black text-slate-900 text-sm sm:text-base flex items-center justify-between">
          <span>{lang === 'mr' ? '५ दिवसांचा स्थानिक अंदाज' : 'अगले 5 दिनों का मौसम'}</span>
          <span className="text-xs font-normal text-slate-500">
            {currentVillage?.name[lang] || currentVillage?.name.mr}
          </span>
        </h4>

        <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 pt-1">
          {weather.forecast.map((fc, i) => (
            <div
              key={i}
              className="bg-slate-50 hover:bg-emerald-50/50 transition p-3 rounded-2xl border border-slate-200 text-center flex flex-col items-center justify-between space-y-2"
            >
              <span className="text-xs font-black text-slate-800">
                {fc.day[lang]}
              </span>
              <span className="text-[10px] text-slate-500 font-bold">
                {fc.date}
              </span>

              <div className="my-1">
                {getWeatherIcon(fc.conditionKey, 'w-8 h-8')}
              </div>

              <div className="space-y-0.5">
                <span className="text-xs font-black text-slate-800 block">
                  {fc.tempMax}° / {fc.tempMin}°
                </span>
                <span className="text-[10px] font-extrabold text-blue-600 block">
                  🌧️ {fc.rainProb}%
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
