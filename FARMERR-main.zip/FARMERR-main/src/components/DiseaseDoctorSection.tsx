import React, { useState, useRef } from 'react';
import {
  Camera,
  Upload,
  Stethoscope,
  Sparkles,
  Volume2,
  CheckCircle2,
  ShieldAlert,
  Leaf,
  FlaskConical,
  RotateCcw,
} from 'lucide-react';
import { Language, DiseaseItem } from '../types';
import { DISEASE_DATA } from '../data/diseaseData';
import { translations } from '../translations';
import { speakText, stopSpeaking } from '../utils/speech';

interface DiseaseDoctorSectionProps {
  lang: Language;
}

interface DiagnosisResult {
  diseaseName: string;
  confidence: string;
  symptoms: string[];
  organicTreatment: string[];
  chemicalTreatment: string[];
  preventiveTips: string[];
}

export const DiseaseDoctorSection: React.FC<DiseaseDoctorSectionProps> = ({ lang }) => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [cropName, setCropName] = useState<string>('');
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [diagnosis, setDiagnosis] = useState<DiagnosisResult | null>(null);
  const [selectedDiseaseGuide, setSelectedDiseaseGuide] = useState<DiseaseItem | null>(null);
  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);

  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      setSelectedImage(reader.result as string);
      setDiagnosis(null);
      setSelectedDiseaseGuide(null);
    };
    reader.readAsDataURL(file);
  };

  const handleDiagnose = async () => {
    if (!selectedImage) return;

    setIsAnalyzing(true);
    setDiagnosis(null);

    try {
      const res = await fetch('/api/gemini/diagnose-crop', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          imageBase64: selectedImage,
          cropName,
          lang,
        }),
      });

      if (!res.ok) throw new Error('Diagnosis failed');
      const data: DiagnosisResult = await res.json();
      setDiagnosis(data);
    } catch (err) {
      console.error('Diagnosis error:', err);
      // Fallback diagnosis
      setDiagnosis({
        diseaseName:
          lang === 'mr'
            ? 'पानावरील करपा व थ्रिप्स किडीचा प्रादुर्भाव'
            : lang === 'hi'
            ? 'पत्ती धब्बा (करपा) एवं रस चूसक कीट प्रकोप'
            : 'Foliar Blight & Sucking Pest Attack',
        confidence: '88%',
        symptoms:
          lang === 'mr'
            ? ['पानांवर तपकिरी व पिवळसर डाग', 'पानांच्या कडा वाळणे', 'झाडाची वाढ खुंटणे']
            : ['पत्तियों पर भूरे व पीले धब्बे', 'पत्तियों के किनारों का सूखना', 'पौधे की बढ़वार धीमी होना'],
        organicTreatment:
          lang === 'mr'
            ? ['५% निंबोळी अर्क (५० मिली/१० लिटर पाणी) फवारा', 'आंबट ताक व हिंगाचे द्रावण फवारा']
            : ['5% नीम तेल (50ml प्रति 10 लीटर) का छिड़काव करें', 'खट्टी छाछ व हींग का घोल छिड़कें'],
        chemicalTreatment:
          lang === 'mr'
            ? ['मँकोझेब ७५% WP (२.५ ग्रॅम/लिटर पाणी)', 'इमिडाक्लोप्रिड १७.८% SL (०.५ मिली/लिटर)']
            : ['मैंकोजेब 75% WP (2.5 ग्राम प्रति लीटर पानी)', 'इमिडाक्लोप्रिड 17.8% SL (0.5 मिली/लीटर)'],
        preventiveTips:
          lang === 'mr'
            ? ['जास्त पाणी साचू देऊ नका', 'रोगट पाने उपटून टाका']
            : ['खेत में पानी का भराव न होने दें', 'संक्रमित पत्तियों को नष्ट करें'],
      });
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleSpeakDiagnosis = () => {
    if (isSpeaking) {
      stopSpeaking();
      setIsSpeaking(false);
      return;
    }

    if (!diagnosis) return;

    const text = `${diagnosis.diseaseName}. ${
      lang === 'mr' ? 'सेंद्रिय उपाय: ' : 'जैविक उपाय: '
    }${diagnosis.organicTreatment.join('. ')}. ${
      lang === 'mr' ? 'रासायनिक उपाय: ' : 'रासायनिक उपाय: '
    }${diagnosis.chemicalTreatment.join('. ')}`;

    setIsSpeaking(true);
    speakText(
      text,
      lang,
      () => setIsSpeaking(false),
      () => setIsSpeaking(false)
    );
  };

  return (
    <section className="space-y-4">
      {/* Title Card */}
      <div className="bg-gradient-to-r from-red-700 to-rose-900 text-white rounded-2xl p-4 shadow-md border-l-6 border-amber-400">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl sm:text-2xl font-black flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-amber-400 text-red-950">
                <Stethoscope className="w-5 h-5" />
              </span>
              {translations.doctor.title[lang]}
            </h2>
            <p className="text-rose-100 text-xs sm:text-sm mt-0.5">
              {translations.doctor.subtitle[lang]}
            </p>
          </div>
        </div>
      </div>

      {/* Upload & Camera Scanner Card */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border-2 border-emerald-300 shadow-sm">
        {/* Hidden inputs */}
        <input
          ref={cameraInputRef}
          type="file"
          accept="image/*"
          capture="environment"
          onChange={handleImageChange}
          className="hidden"
        />
        <input
          ref={fileInputRef}
          type="file"
          accept="image/*"
          onChange={handleImageChange}
          className="hidden"
        />

        {/* Action Buttons: Camera vs Gallery */}
        <div className="grid grid-cols-2 gap-3 mb-4">
          <button
            onClick={() => cameraInputRef.current?.click()}
            className="flex flex-col items-center justify-center p-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold transition shadow-xs active:scale-95 text-center"
          >
            <Camera className="w-7 h-7 mb-1.5 text-amber-300" />
            <span className="text-xs sm:text-sm leading-tight">
              {translations.doctor.takePhoto[lang]}
            </span>
          </button>

          <button
            onClick={() => fileInputRef.current?.click()}
            className="flex flex-col items-center justify-center p-4 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold transition border border-slate-300 active:scale-95 text-center"
          >
            <Upload className="w-7 h-7 mb-1.5 text-slate-600" />
            <span className="text-xs sm:text-sm leading-tight">
              {translations.doctor.uploadPhoto[lang]}
            </span>
          </button>
        </div>

        {/* Image Preview & Crop Name */}
        {selectedImage && (
          <div className="mt-3 p-3 bg-slate-50 rounded-xl border border-slate-200 space-y-3">
            <div className="relative max-h-64 overflow-hidden rounded-lg flex justify-center bg-black/5">
              <img
                src={selectedImage}
                alt="Selected crop leaf"
                className="max-h-64 object-contain rounded-lg"
              />
              <button
                onClick={() => {
                  setSelectedImage(null);
                  setDiagnosis(null);
                }}
                className="absolute top-2 right-2 bg-red-600 text-white p-1.5 rounded-full shadow hover:bg-red-700"
                title="Remove image"
              >
                ✕
              </button>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <input
                type="text"
                value={cropName}
                onChange={(e) => setCropName(e.target.value)}
                placeholder={translations.doctor.selectCropOptional[lang]}
                className="flex-1 px-3 py-2 border rounded-xl text-sm font-medium focus:outline-hidden focus:border-emerald-600"
              />

              <button
                onClick={handleDiagnose}
                disabled={isAnalyzing}
                className="px-5 py-2.5 bg-red-600 hover:bg-red-700 disabled:bg-slate-400 text-white font-black rounded-xl text-xs sm:text-sm shadow-md transition flex items-center gap-2 active:scale-95"
              >
                {isAnalyzing ? (
                  <>
                    <RotateCcw className="w-4 h-4 animate-spin" />
                    <span>{translations.doctor.analyzing[lang]}</span>
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4 text-amber-300" />
                    <span>{translations.doctor.diagnoseButton[lang]}</span>
                  </>
                )}
              </button>
            </div>
          </div>
        )}

        {/* Diagnosis Results Display */}
        {diagnosis && (
          <div className="mt-4 p-4 bg-gradient-to-br from-emerald-50 to-teal-50 rounded-2xl border-2 border-emerald-400 animate-in fade-in duration-300">
            <div className="flex items-start justify-between gap-2 border-b border-emerald-200 pb-3">
              <div>
                <span className="inline-block bg-emerald-700 text-white text-[11px] font-bold px-2.5 py-0.5 rounded-full">
                  {lang === 'mr' ? 'AI रोग निदान' : 'AI रोग निदान'} (विश्वास: {diagnosis.confidence})
                </span>
                <h3 className="text-lg sm:text-xl font-black text-slate-900 mt-1">
                  {diagnosis.diseaseName}
                </h3>
              </div>

              <button
                onClick={handleSpeakDiagnosis}
                className={`p-2.5 rounded-xl transition ${
                  isSpeaking
                    ? 'bg-red-500 text-white animate-pulse'
                    : 'bg-emerald-700 text-white hover:bg-emerald-800'
                }`}
                title="Listen Diagnosis"
              >
                <Volume2 className="w-5 h-5" />
              </button>
            </div>

            {/* Symptoms */}
            <div className="mt-3">
              <h4 className="text-xs font-black text-slate-800 uppercase flex items-center gap-1.5">
                <ShieldAlert className="w-4 h-4 text-red-600" />
                {translations.doctor.symptomsTitle[lang]}
              </h4>
              <ul className="mt-1 space-y-1 text-xs sm:text-sm text-slate-700 font-medium">
                {diagnosis.symptoms.map((s, idx) => (
                  <li key={idx} className="flex items-start gap-1.5">
                    <span className="text-red-500">•</span>
                    <span>{s}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Organic Remedy */}
            <div className="mt-3 p-3 bg-white rounded-xl border border-emerald-200">
              <h4 className="text-xs font-black text-emerald-800 uppercase flex items-center gap-1.5">
                <Leaf className="w-4 h-4 text-emerald-600" />
                {translations.doctor.organicTitle[lang]}
              </h4>
              <ul className="mt-1.5 space-y-1 text-xs sm:text-sm text-slate-800 font-semibold">
                {diagnosis.organicTreatment.map((ot, idx) => (
                  <li key={idx} className="flex items-start gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
                    <span>{ot}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Chemical Treatment */}
            <div className="mt-3 p-3 bg-white rounded-xl border border-blue-200">
              <h4 className="text-xs font-black text-blue-900 uppercase flex items-center gap-1.5">
                <FlaskConical className="w-4 h-4 text-blue-600" />
                {translations.doctor.chemicalTitle[lang]}
              </h4>
              <ul className="mt-1.5 space-y-1 text-xs sm:text-sm text-slate-800 font-semibold">
                {diagnosis.chemicalTreatment.map((ct, idx) => (
                  <li key={idx} className="flex items-start gap-1.5">
                    <div className="w-2 h-2 rounded-full bg-blue-600 mt-1.5 shrink-0" />
                    <span>{ct}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Prevention */}
            <div className="mt-3 text-xs text-slate-600">
              <span className="font-bold text-slate-800">
                {translations.doctor.preventionTitle[lang]}:{' '}
              </span>
              <span>{diagnosis.preventiveTips.join(' • ')}</span>
            </div>
          </div>
        )}
      </div>

      {/* Common Crop Diseases Visual Library */}
      <div>
        <h3 className="text-sm font-black text-slate-900 uppercase tracking-wider mb-2.5">
          {translations.doctor.commonDiseasesTitle[lang]}
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {DISEASE_DATA.map((item) => (
            <div
              key={item.id}
              className="bg-white rounded-2xl p-4 border border-slate-200 shadow-sm hover:border-emerald-400 transition"
            >
              <div className="flex items-start gap-3">
                <img
                  src={item.sampleImage}
                  alt={item.name[lang]}
                  className="w-20 h-20 rounded-xl object-cover shrink-0 border border-slate-200"
                />
                <div className="flex-1">
                  <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-md">
                    {item.crop[lang]}
                  </span>
                  <h4 className="font-black text-slate-900 text-sm mt-1 leading-snug">
                    {item.name[lang]}
                  </h4>
                </div>
              </div>

              {/* Quick solution preview */}
              <div className="mt-3 p-2.5 bg-emerald-50/60 rounded-xl border border-emerald-100 text-xs">
                <span className="font-bold text-emerald-900 block">
                  {lang === 'mr' ? 'तात्काळ उपाय:' : 'त्वरित इलाज:'}
                </span>
                <span className="text-slate-700 font-medium line-clamp-2">
                  {item.organicTreatment[lang][0]}
                </span>
              </div>

              <div className="mt-2.5 flex items-center justify-between">
                <button
                  onClick={() => {
                    setSelectedDiseaseGuide(selectedDiseaseGuide?.id === item.id ? null : item);
                  }}
                  className="text-xs font-bold text-emerald-800 hover:text-emerald-900 underline"
                >
                  {selectedDiseaseGuide?.id === item.id
                    ? (lang === 'mr' ? 'माहिती लपवा' : 'विवरण छुपाएं')
                    : (lang === 'mr' ? 'पूर्ण उपाय पहा' : 'पूरा इलाज देखें')}
                </button>

                <button
                  onClick={() => {
                    speakText(
                      `${item.name[lang]}. ${item.organicTreatment[lang][0]}. ${item.chemicalTreatment[lang][0]}`,
                      lang
                    );
                  }}
                  className="p-1.5 rounded-lg bg-slate-100 text-slate-700 hover:bg-emerald-100"
                  title="Listen"
                >
                  <Volume2 className="w-4 h-4" />
                </button>
              </div>

              {/* Full details expansion */}
              {selectedDiseaseGuide?.id === item.id && (
                <div className="mt-3 pt-3 border-t border-slate-100 text-xs space-y-2">
                  <div>
                    <span className="font-bold text-slate-800">
                      {translations.doctor.symptomsTitle[lang]}:
                    </span>
                    <ul className="list-disc pl-4 text-slate-600 mt-0.5 space-y-0.5">
                      {item.symptoms[lang].map((s, i) => (
                        <li key={i}>{s}</li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <span className="font-bold text-emerald-800">
                      {translations.doctor.organicTitle[lang]}:
                    </span>
                    <p className="text-slate-700 mt-0.5 font-medium">
                      {item.organicTreatment[lang].join(' | ')}
                    </p>
                  </div>

                  <div>
                    <span className="font-bold text-blue-800">
                      {translations.doctor.chemicalTitle[lang]}:
                    </span>
                    <p className="text-slate-700 mt-0.5 font-medium">
                      {item.chemicalTreatment[lang].join(' | ')}
                    </p>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
