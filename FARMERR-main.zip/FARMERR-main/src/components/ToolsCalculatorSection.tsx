import React, { useState } from 'react';
import { Calculator, CheckSquare, Sparkles, Sprout, TestTube2, Info } from 'lucide-react';
import { Language } from '../types';
import { translations } from '../translations';

interface ToolsCalculatorSectionProps {
  lang: Language;
}

export const ToolsCalculatorSection: React.FC<ToolsCalculatorSectionProps> = ({ lang }) => {
  const [landArea, setLandArea] = useState<number>(1);
  const [unit, setUnit] = useState<'acre' | 'guntha' | 'bigha'>('acre');
  const [cropType, setCropType] = useState<string>('wheat');

  // Fertilizer dosage calculation based on crop and area normalized to acres
  // 1 acre = 40 guntha = 1.6 bigha (approx standard north/central India)
  const normalizedAcres =
    unit === 'acre' ? landArea : unit === 'guntha' ? landArea / 40 : landArea / 1.6;

  const cropDoses: Record<string, { name: string; ureaKg: number; dapKg: number; mopKg: number }> = {
    wheat: { name: 'गेहूं (Wheat)', ureaKg: 65, dapKg: 50, mopKg: 20 },
    soybean: { name: 'सोयाबीन (Soybean)', ureaKg: 15, dapKg: 40, mopKg: 15 },
    onion: { name: 'प्याज (Onion)', ureaKg: 45, dapKg: 50, mopKg: 40 },
    cotton: { name: 'कपास (Cotton)', ureaKg: 80, dapKg: 50, mopKg: 40 },
    banana: { name: 'केला (Banana)', ureaKg: 250, dapKg: 100, mopKg: 350 },
    papaya: { name: 'पपीता (Papaya)', ureaKg: 120, dapKg: 80, mopKg: 150 },
    tomato: { name: 'टमाटर (Tomato)', ureaKg: 65, dapKg: 75, mopKg: 50 },
    chilli: { name: 'मिर्च (Chilli)', ureaKg: 70, dapKg: 60, mopKg: 50 },
    gram: { name: 'चना (Gram)', ureaKg: 10, dapKg: 35, mopKg: 15 },
    sugarcane: { name: 'गन्ना (Sugarcane)', ureaKg: 280, dapKg: 125, mopKg: 90 },
  };

  const selectedCropDose = cropDoses[cropType] || cropDoses.wheat;

  // 1 bag of Urea = 45 kg, DAP = 50 kg, MOP = 50 kg
  const ureaBags = ((selectedCropDose.ureaKg * normalizedAcres) / 45).toFixed(1);
  const dapBags = ((selectedCropDose.dapKg * normalizedAcres) / 50).toFixed(1);
  const mopBags = ((selectedCropDose.mopKg * normalizedAcres) / 50).toFixed(1);

  return (
    <section className="space-y-4">
      {/* Title Card */}
      <div className="bg-gradient-to-r from-teal-800 to-emerald-950 text-white rounded-2xl p-4 shadow-md border-l-6 border-teal-400">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-xl sm:text-2xl font-black flex items-center gap-2">
              <span className="p-1.5 rounded-lg bg-teal-300 text-teal-950">
                <Calculator className="w-5 h-5" />
              </span>
              {translations.tools.title[lang]}
            </h2>
            <p className="text-teal-100 text-xs sm:text-sm mt-0.5">
              {translations.tools.subtitle[lang]}
            </p>
          </div>
        </div>
      </div>

      {/* Calculator Interactive Box */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-sm space-y-4">
        <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-emerald-600" />
          {lang === 'mr' ? 'खत कॅल्क्युलेटर (युरिया, डीएपी, पोटॅश)' : 'खाद कैलकुलेटर (यूरिया, डीएपी, पोटाश)'}
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {/* Land Area Input */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {translations.tools.farmArea[lang]}
            </label>
            <input
              type="number"
              min="0.1"
              step="0.5"
              value={landArea}
              onChange={(e) => setLandArea(Math.max(0.1, Number(e.target.value) || 1))}
              className="w-full px-3 py-2 bg-slate-50 border-2 border-emerald-300 rounded-xl font-black text-slate-800 text-base focus:outline-hidden focus:border-emerald-600"
            />
          </div>

          {/* Unit Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {lang === 'mr' ? 'एकक (Unit)' : 'माप की इकाई'}
            </label>
            <select
              value={unit}
              onChange={(e) => setUnit(e.target.value as any)}
              className="w-full px-3 py-2 bg-slate-50 border-2 border-emerald-300 rounded-xl font-bold text-slate-800 text-sm focus:outline-hidden focus:border-emerald-600"
            >
              <option value="acre">{translations.tools.unitAcre[lang]}</option>
              <option value="guntha">{translations.tools.unitGuntha[lang]}</option>
              <option value="bigha">{translations.tools.unitBigha[lang]}</option>
            </select>
          </div>

          {/* Crop Selector */}
          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">
              {translations.tools.selectCrop[lang]}
            </label>
            <select
              value={cropType}
              onChange={(e) => setCropType(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border-2 border-emerald-300 rounded-xl font-bold text-slate-800 text-sm focus:outline-hidden focus:border-emerald-600"
            >
              <option value="wheat">गेहूं (Wheat / गहू)</option>
              <option value="banana">केला (Banana / केळी)</option>
              <option value="papaya">पपीता (Papaya / पपई)</option>
              <option value="tomato">टमाटर (Tomato / टोमॅटो)</option>
              <option value="onion">प्याज (Onion / कांदा)</option>
              <option value="cotton">कपास (Cotton / कापूस)</option>
              <option value="chilli">मिर्च (Chilli / मिरची)</option>
              <option value="soybean">सोयाबीन (Soybean)</option>
              <option value="gram">चना (Gram / हरभरा)</option>
              <option value="sugarcane">गन्ना (Sugarcane / ऊस)</option>
            </select>
          </div>
        </div>

        {/* Calculated Results Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2">
          {/* Urea */}
          <div className="bg-blue-50/80 p-3.5 rounded-xl border border-blue-200">
            <span className="text-xs font-bold text-blue-900 block">
              {translations.tools.ureaBags[lang]}
            </span>
            <div className="text-2xl sm:text-3xl font-black text-blue-950 mt-1">
              {ureaBags} <span className="text-sm font-semibold">{lang === 'mr' ? 'पोती' : 'बैग'}</span>
            </div>
            <span className="text-[11px] text-slate-500 mt-0.5 block font-medium">
              (45 kg પ્રતિ बैग)
            </span>
          </div>

          {/* DAP */}
          <div className="bg-amber-50/80 p-3.5 rounded-xl border border-amber-200">
            <span className="text-xs font-bold text-amber-900 block">
              {translations.tools.dapBags[lang]}
            </span>
            <div className="text-2xl sm:text-3xl font-black text-amber-950 mt-1">
              {dapBags} <span className="text-sm font-semibold">{lang === 'mr' ? 'पोती' : 'बैग'}</span>
            </div>
            <span className="text-[11px] text-slate-500 mt-0.5 block font-medium">
              (50 kg प्रति बैग)
            </span>
          </div>

          {/* MOP Potash */}
          <div className="bg-red-50/80 p-3.5 rounded-xl border border-red-200">
            <span className="text-xs font-bold text-red-900 block">
              {translations.tools.mopBags[lang]}
            </span>
            <div className="text-2xl sm:text-3xl font-black text-red-950 mt-1">
              {mopBags} <span className="text-sm font-semibold">{lang === 'mr' ? 'पोती' : 'बैग'}</span>
            </div>
            <span className="text-[11px] text-slate-500 mt-0.5 block font-medium">
              (50 kg प्रति बैग)
            </span>
          </div>
        </div>

        <p className="text-xs text-slate-500 bg-slate-50 p-2 rounded-lg border border-slate-200">
          ℹ️ <span className="font-bold">{lang === 'mr' ? 'महत्त्वाची सूचना: ' : 'सूचना: '}</span>
          {lang === 'mr'
            ? 'हे प्रमाण सामान्य शिफारसीनुसार आहे. अचूक खत व्यवस्थापनासाठी जमिनीचे माती परीक्षण (Soil Test) करून घ्या.'
            : 'यह मानक सिफारिश अनुसार है। सटीक खाद प्रबंधन के लिए मिट्टी परीक्षण रिपोर्ट के आधार पर मात्रा तय करें।'}
        </p>
      </div>

      {/* Soil Health Card 5-Step Guide */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-sm space-y-3">
        <h3 className="text-base font-black text-slate-900 flex items-center gap-2">
          <TestTube2 className="w-5 h-5 text-emerald-700" />
          {translations.tools.soilSamplingGuide[lang]}
        </h3>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-xs sm:text-sm">
          {[
            {
              step: '1',
              title: lang === 'mr' ? 'V-आकाराचा खड्डा करा' : 'V-आकार का गड्ढा खोदें',
              desc: lang === 'mr' ? 'शेतात ८-१० ठिकाणी १५ सेंमी (६ इंच) खोल इंग्रजी V-आकाराचे खड्डे करा.' : 'खेत में 8-10 अलग-अलग स्थानों पर 15 सेमी (6 इंच) गहरा V-आकार का गड्ढा खोदें।',
            },
            {
              step: '2',
              title: lang === 'mr' ? 'खड्ड्याच्या कडेची माती काढा' : 'किनारे से 1 इंच परत खुरचें',
              desc: lang === 'mr' ? 'खड्ड्याच्या एका बाजूने १ इंच जाडीची वरपासून खालपर्यंतची माती खुरपणीने घमेल्यात गोळा करा.' : 'गड्ढे की एक दीवार से ऊपर से नीचे तक 1 इंच मोटी मिट्टी खुरपी से तगाड़ी में लें।',
            },
            {
              step: '3',
              title: lang === 'mr' ? 'माती एकत्र मिसळा व ४ भाग करा' : 'मिट्टी को मिलाकर 4 भाग करें',
              desc: lang === 'mr' ? 'सर्व खड्ड्यांची माती स्वच्छ ताडपत्रीवर एकत्र मिसळा, गोल ढीग करून त्याचे चार भाग करा.' : 'सभी सैंपल्स को साफ बोरी पर अच्छी तरह मिलाकर गोल ढेरी बनाएं और 4 बराबर हिस्से करें।',
            },
            {
              step: '4',
              title: lang === 'mr' ? 'अर्धा किलो माती शिल्लक ठेवा' : '500 ग्राम मिट्टी बचाएं',
              desc: lang === 'mr' ? 'समोरासमोरील दोन भाग फेकून द्या व उरलेले दोन भाग पुन्हा मिसळा. जोपर्यंत ५०० ग्रॅम माती उरत नाही तोपर्यंत हे करा.' : 'आमने-सामने के दो भाग हटा दें और बाकी मिलाएं, जब तक आधा किलो मिट्टी न बचे।',
            },
            {
              step: '5',
              title: lang === 'mr' ? 'छायादार जागेत वाळवून लॅबमध्ये द्या' : 'छाया में सुखाकर लैब में जमा करें',
              desc: lang === 'mr' ? 'माती सावलीत वाळवा. प्लास्टिक पिशवीत भरून शेतकऱ्याचे नाव, गट नंबर व मोबाइल टाकून KVK किंवा कृषी लॅबमध्ये द्या.' : 'मिट्टी को धूप में न सुखाएं। साफ थैली में नाम, खेत खसरा नंबर लिखकर नजदीकी कृषि विज्ञान केंद्र (KVK) भेजें।',
            },
          ].map((item) => (
            <div key={item.step} className="p-3 bg-slate-50 rounded-xl border border-slate-200 flex items-start gap-3">
              <span className="w-6 h-6 rounded-full bg-emerald-700 text-white font-black text-xs flex items-center justify-center shrink-0">
                {item.step}
              </span>
              <div>
                <h4 className="font-bold text-slate-800">{item.title}</h4>
                <p className="text-slate-600 mt-0.5">{item.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
