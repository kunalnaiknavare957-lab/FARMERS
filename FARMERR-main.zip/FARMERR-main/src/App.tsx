import React, { useState, useEffect } from 'react';
import { Language } from './types';
import { translations } from './translations';
import { Header } from './components/Header';
import { BottomNav, ActiveTab } from './components/BottomNav';
import { MandiSection } from './components/MandiSection';
import { WeatherSection } from './components/WeatherSection';
import { SchemesSection } from './components/SchemesSection';
import { DiseaseDoctorSection } from './components/DiseaseDoctorSection';
import { CropAdvisorySection } from './components/CropAdvisorySection';
import { MarketplaceSection } from './components/MarketplaceSection';
import { ToolsCalculatorSection } from './components/ToolsCalculatorSection';
import { HelplineSection } from './components/HelplineSection';
import { CropGuidanceSection } from './components/CropGuidanceSection';
import { KisanChatModal } from './components/KisanChatModal';
import { DownloadModal } from './components/DownloadModal';
import {
  TrendingUp,
  CloudSun,
  FileText,
  Stethoscope,
  Wheat,
  ShoppingBag,
  Calculator,
  PhoneCall,
  Sparkles,
  Award,
  Mic,
  Share2,
  Sprout,
  Download,
} from 'lucide-react';

export default function App() {
  const [lang, setLang] = useState<Language>(() => {
    const saved = localStorage.getItem('kisan_mitra_lang');
    return (saved as Language) || 'hi';
  });

  const [activeTab, setActiveTab] = useState<ActiveTab>('mandi');
  const [isOffline, setIsOffline] = useState<boolean>(!navigator.onLine);
  const [isAiModalOpen, setIsAiModalOpen] = useState<boolean>(false);
  const [isDownloadModalOpen, setIsDownloadModalOpen] = useState<boolean>(false);

  // Sync language with localStorage
  useEffect(() => {
    localStorage.setItem('kisan_mitra_lang', lang);
    document.documentElement.lang = lang;
  }, [lang]);

  // Online / offline listeners
  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: translations.appName[lang],
        text: translations.appTagline[lang],
        url: window.location.href,
      }).catch(() => {});
    } else {
      navigator.clipboard?.writeText(window.location.href);
      alert(lang === 'mr' ? 'लिंक कॉपी केली!' : 'लिंक कॉपी हो गई!');
    }
  };

  return (
    <div className="min-h-screen bg-[#F8FAF5] flex flex-col font-sans text-slate-800 pb-24 selection:bg-emerald-200">
      {/* Header */}
      <Header
        lang={lang}
        onLanguageChange={setLang}
        isOffline={isOffline}
        onOpenHelpline={() => setActiveTab('helpline')}
        onOpenDownloadModal={() => setIsDownloadModalOpen(true)}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-5xl w-full mx-auto px-3 sm:px-6 pt-3 space-y-4">
        {/* Offline Notification Banner */}
        {isOffline && (
          <div className="bg-amber-100 border-l-4 border-amber-600 p-3 rounded-xl text-amber-950 text-xs sm:text-sm font-semibold flex items-center justify-between shadow-xs">
            <span>{translations.quickActions.offlineNotice[lang]}</span>
            <span className="text-[11px] bg-amber-200 px-2 py-0.5 rounded-md font-bold">
              कॅश्ड डेटा
            </span>
          </div>
        )}

        {/* Android APK Download Quick Banner */}
        <div className="bg-gradient-to-r from-emerald-700 via-teal-700 to-emerald-800 text-white p-3 rounded-2xl shadow-md flex flex-wrap items-center justify-between gap-2.5 border border-emerald-500">
          <div className="flex items-center gap-2.5">
            <span className="w-8 h-8 rounded-xl bg-amber-400 text-emerald-950 font-black text-lg flex items-center justify-center shrink-0">
              📲
            </span>
            <div>
              <div className="font-black text-xs sm:text-sm text-white flex items-center gap-2">
                <span>{lang === 'mr' ? 'किसान मित्र थेट Android APK (पूर्ण ॲपसह)!' : 'किसान मित्र डायरेक्ट Android APK (फुल ऐप सहित)!'}</span>
                <span className="bg-amber-400 text-amber-950 text-[10px] font-extrabold px-1.5 py-0.2 rounded-full">
                  280 KB
                </span>
              </div>
              <p className="text-[11px] text-emerald-100 hidden sm:block">
                {lang === 'mr' ? 'उघडल्यावर सर्व माहिती, बाजारभाव व हवामान लगेच सुरू होते' : 'खुलते ही सभी मंडियों के भाव, मौसम व सलाह तुरंत शुरू होती है'}
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <a
              href="/api/download-apk"
              download="KisanMitra.apk"
              className="inline-flex items-center gap-1.5 bg-amber-400 hover:bg-amber-300 text-amber-950 font-black text-xs px-3 py-1.5 rounded-xl shadow-xs transition active:scale-95"
            >
              <span>{lang === 'mr' ? 'APK डाऊनलोड' : 'APK डाउनलोड'}</span>
            </a>
            <button
              onClick={() => setIsDownloadModalOpen(true)}
              className="text-[11px] underline text-emerald-200 hover:text-white font-semibold"
            >
              {lang === 'mr' ? 'इन्स्टॉल गाईड' : 'गाइड देखें'}
            </button>
          </div>
        </div>

        {/* Desktop / Tablet Navigation Pills */}
        <div className="hidden sm:flex items-center gap-1.5 overflow-x-auto no-scrollbar bg-white p-2 rounded-2xl shadow-xs border border-slate-200">
          {[
            { id: 'mandi' as ActiveTab, label: translations.nav.mandi[lang], icon: TrendingUp },
            { id: 'weather' as ActiveTab, label: translations.nav.weather[lang], icon: CloudSun },
            { id: 'guidance' as ActiveTab, label: translations.nav.guidance[lang], icon: Sprout },
            { id: 'doctor' as ActiveTab, label: translations.nav.doctor[lang], icon: Stethoscope },
            { id: 'schemes' as ActiveTab, label: translations.nav.schemes[lang], icon: FileText },
            { id: 'advisory' as ActiveTab, label: translations.nav.advisory[lang], icon: Wheat },
            { id: 'market' as ActiveTab, label: translations.nav.market[lang], icon: ShoppingBag },
            { id: 'tools' as ActiveTab, label: translations.nav.tools[lang], icon: Calculator },
            { id: 'helpline' as ActiveTab, label: translations.nav.helpline[lang], icon: PhoneCall },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-black transition-all ${
                  isActive
                    ? 'bg-emerald-800 text-white shadow-xs'
                    : 'text-slate-600 hover:text-emerald-900 hover:bg-emerald-50'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>

        {/* Content based on Active Tab */}
        <div className="transition-all">
          {activeTab === 'mandi' && <MandiSection lang={lang} />}
          {activeTab === 'weather' && <WeatherSection lang={lang} />}
          {activeTab === 'guidance' && <CropGuidanceSection lang={lang} />}
          {activeTab === 'schemes' && <SchemesSection lang={lang} />}
          {activeTab === 'doctor' && <DiseaseDoctorSection lang={lang} />}
          {activeTab === 'advisory' && <CropAdvisorySection lang={lang} />}
          {activeTab === 'market' && <MarketplaceSection lang={lang} />}
          {activeTab === 'tools' && <ToolsCalculatorSection lang={lang} />}
          {activeTab === 'helpline' && <HelplineSection lang={lang} />}
        </div>

        {/* Farmer Success & Innovation Card (Kisan Prerna) */}
        <div className="mt-6 bg-gradient-to-r from-amber-50 to-emerald-50 rounded-2xl p-4 border border-amber-200/80 shadow-xs">
          <div className="flex items-start gap-3">
            <div className="p-2.5 rounded-xl bg-amber-400 text-amber-950 font-bold shrink-0">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <span className="text-[11px] font-black text-amber-800 uppercase tracking-wider block">
                {lang === 'mr' ? 'शेतकरी यशोगाथा (Success Story)' : 'किसान प्रेरणा व यशोगाथा'}
              </span>
              <h4 className="font-black text-slate-900 text-sm sm:text-base mt-0.5">
                {lang === 'mr'
                  ? 'नाशिकचे शेतकरी ज्ञानेश्वर बोराडे यांनी ठिबक व मल्चिंगने कांद्याचे एकरी १५० क्विंटल उत्पादन घेतले!'
                  : 'नासिक के किसान ज्ञानेश्वर ने ड्रिप सिंचाई और मल्चिंग से प्याज का रिकॉर्ड 150 क्विंटल प्रति एकड़ उत्पादन लिया!'}
              </h4>
              <p className="text-xs text-slate-600 mt-1 font-medium">
                {lang === 'mr'
                  ? 'पाण्याची ५०% बचत झाली आणि खतांचा खर्च ३०% कमी झाला. तुम्हीही आधुनिक तंत्रज्ञानाचा वापर करा.'
                  : 'पानी की 50% बचत हुई और रासायनिक खाद का खर्च 30% घट गया। आधुनिक कृषि अपनाएं और लाभ बढ़ाएं।'}
              </p>
            </div>
          </div>
        </div>

        {/* Footer info */}
        <footer className="text-center py-6 text-xs text-slate-500 border-t border-slate-200 mt-8 space-y-2">
          <p className="font-bold text-slate-700">
            {translations.appName[lang]} • {translations.appTagline[lang]}
          </p>
          <p>
            {lang === 'mr'
              ? 'हे पोर्टल भारतीय शेतकऱ्यांच्या सुविधेसाठी पूर्णपणे मोफत आहे. बाजार भाव APMC स्रोतांवर आधारित आहेत.'
              : 'यह पोर्टल भारतीय किसानों की सुविधा हेतु निःशुल्क है। मंडी भाव APMC स्रोतों पर आधारित हैं।'}
          </p>
          <div className="flex justify-center gap-4 pt-1 font-semibold text-emerald-800">
            <button onClick={handleShare} className="flex items-center gap-1 hover:underline">
              <Share2 className="w-3.5 h-3.5" />
              <span>{lang === 'mr' ? 'मित्रांना शेअर करा' : 'साथियों को शेयर करें'}</span>
            </button>
            <a href="tel:18001801551" className="hover:underline">
              टोल फ्री: 1800-180-1551
            </a>
          </div>
        </footer>
      </main>

      {/* Floating AI Helper Button */}
      <button
        onClick={() => setIsAiModalOpen(true)}
        className="fixed bottom-18 right-4 sm:bottom-6 sm:right-6 z-40 bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-700 hover:to-teal-800 text-white font-extrabold px-4 py-3 rounded-full shadow-2xl border-2 border-amber-300 flex items-center gap-2 transition-transform active:scale-95 group"
        title="Ask Kisan Mitra AI"
      >
        <span className="relative flex h-3 w-3">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-3 w-3 bg-amber-400"></span>
        </span>
        <Sparkles className="w-5 h-5 text-amber-300 group-hover:rotate-12 transition-transform" />
        <span className="text-xs sm:text-sm">
          {translations.quickActions.askAi[lang]}
        </span>
      </button>

      {/* Mobile Bottom Navigation */}
      <BottomNav
        activeTab={activeTab}
        onChangeTab={setActiveTab}
        lang={lang}
        onOpenAiChat={() => setIsAiModalOpen(true)}
      />

      {/* AI Voice/Text Chat Modal */}
      <KisanChatModal
        isOpen={isAiModalOpen}
        onClose={() => setIsAiModalOpen(false)}
        lang={lang}
      />

      {/* Download / Install App Modal */}
      <DownloadModal
        isOpen={isDownloadModalOpen}
        onClose={() => setIsDownloadModalOpen(false)}
        lang={lang}
      />
    </div>
  );
}
